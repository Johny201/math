import { Injectable } from '@angular/core';
import { AppLocalConfig } from './app.local.config';
import { AppDevConfig } from './app.dev.config';
import { AppProdConfig } from './app.prod.config';
import { IConfig } from './config';
import { OidcSettings } from '../models/index';
import { AppLocalHttpsConfig } from './app.local.https.config';

declare var document;
declare var window;

@Injectable({
  providedIn: 'root'
})
export class AppConfig {

  public static readonly isLocalHttps: boolean = /gk\.gk/gi.test(window.location.host) && window.location.href.indexOf('https') === 0;
  public static readonly isLocal: boolean = !AppConfig.isLocalHttps && /localhost/gi.test(window.location.host);
  public static readonly isDev: boolean = !AppConfig.isLocal && /:8080/gi.test(window.location.host);
  public static readonly isProd: boolean = (!AppConfig.isLocal && !AppConfig.isDev);

  public static readonly config: IConfig = AppConfig.isLocalHttps ? AppLocalHttpsConfig : AppConfig.isLocal ? AppLocalConfig : AppConfig.isDev ? AppDevConfig : AppProdConfig;

  public static readonly testData: boolean = false;
  public static readonly testEmptyState: boolean = false;
  public static readonly testErrorState: boolean = false;
  public static readonly isTest: boolean = AppConfig.isLocal && (AppConfig.testData || AppConfig.testEmptyState || AppConfig.testErrorState);

  public static readonly API_URL: string = AppConfig.config.API_URL;
  public static readonly BASE_URL: string = AppConfig.config.BASE_URL;
  public static readonly CLIENT_ID: string = AppConfig.config.CLIENT_ID;
  public static readonly STS_SERVER: string = AppConfig.config.STS_SERVER;

  public static readonly isIE = /*@cc_on!@*/false || !!document.documentMode;
  public static readonly isEdge = !AppConfig.isIE && !!window.StyleMedia;


  public static readonly endpoints: { [id: string]: string } = {
    'getPatients': AppConfig.API_URL + '/api/patients',
    'getPatient': AppConfig.API_URL + '/api/patient',
    'isAuth': AppConfig.API_URL + '/api/isauth',
    'login': AppConfig.API_URL + '/api/auth/login',
    'logout': AppConfig.API_URL + '/api/auth/logout',
    'files': AppConfig.API_URL + '/api/files',
    'analysisObject': AppConfig.API_URL + '/api/analysis/object',
    'fileObject': AppConfig.API_URL + '/api/files/object',
    'getAnalyzesInfo': AppConfig.API_URL + '/api/analyzes',
    'filesToAnalysisSystem': AppConfig.API_URL + ':8000/analysis',
    'filesListFromAnalysisSystem': AppConfig.API_URL + ':8000/analysisList',
    'MRIListFromAnalysisSystem': AppConfig.API_URL + ':8000/mris',
    'getProfile': AppConfig.API_URL + '/api/profile'
  };




  public static fakeLoadTime(min = 0, max = 1000): any {
    return Math.floor(Math.random() * (max - min)) + min;
  }


  public static readonly oidcSettings: OidcSettings = {
    stsServer: AppConfig.STS_SERVER,
    redirect_url: AppConfig.BASE_URL,
    client_id: AppConfig.CLIENT_ID,
    response_type: 'id_token token',
    scope: 'openid bekhterev-api',
    post_logout_redirect_uri: AppConfig.BASE_URL,
    post_login_route: '/',
    forbidden_route: '/forbidden',
    unauthorized_route: '/unauthorized',
    trigger_authorization_result_event: true,
    log_console_warning_active: true,
    log_console_debug_active: true,
    max_id_token_iat_offset_allowed_in_seconds: 60 * 60 * 24 * 2,
    start_checksession: false
  };

  constructor() { }

}
