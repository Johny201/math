import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppProdConfig {

  public static readonly BASE_URL: string = 'https://math.bekhterev.ru';
  public static readonly API_URL: string = "https://math.bekhterev.ru";
  public static readonly STS_SERVER: string = "https://math.bekhterev.ru/oidc";
  public static readonly CLIENT_ID: string = "bekhterev-client-prod";

  constructor() { }

}
