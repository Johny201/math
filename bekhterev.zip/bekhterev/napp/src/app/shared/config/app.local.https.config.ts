import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class AppLocalHttpsConfig {

  public static readonly BASE_URL: string = 'https://gk.gk:8080';
  public static readonly API_URL: string = "https://gk.gk:8080";
  public static readonly STS_SERVER: string = "https://gk.gk:8080/oidc";
  public static readonly CLIENT_ID: string = "bekhterev-client-local";

  constructor() { }

}
