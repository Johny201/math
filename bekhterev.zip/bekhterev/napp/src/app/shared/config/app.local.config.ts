import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class AppLocalConfig {

  public static readonly BASE_URL: string = 'http://localhost:4201';
  public static readonly API_URL: string = "http://localhost:8080";
  public static readonly STS_SERVER: string = "http://localhost:8080/oidc";
  public static readonly CLIENT_ID: string = "bekhterev-client-local-s";

  constructor() { }

}
