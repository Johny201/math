export interface IConfig {
    API_URL: string;
    BASE_URL: string;
    STS_SERVER: string;
    CLIENT_ID: string;
}