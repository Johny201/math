import { Injectable } from '@angular/core';

@Injectable()
export class Utilities {
    public static baseUrl() {
        let base = '';

        if (window.location.origin)
            base = window.location.origin;
        else
            base = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');

        return base.replace(/\/$/, '');
    }

    public static getParameter(name: string) {
        let params_string = location.search;
        if (params_string === "")
            return null;
        let params = params_string.slice(1).split("&");
        for (let param of params) {
            let split = param.split("=");
            if (split[0] === name) return split.length === 1 ? "" : split[1];
        }
        return null;
    }

    public static onlyPath(url: string): string {
        let splt = url.split("?");
        return splt[0];
    }

    public static Parameter(name: string) {
        let params_string = location.search;
        if (params_string === "")
            return false;
        let params = params_string.slice(1).split("&");
        for (let param of params) {
            let split = param.split("=");
            if (split[0] === name) return true;
        }
        return false;
    }

    public static replacer(url: string): (o: any) => string {
        let r = /\:([a-zA-Z]+)/gi;
        return (o): string => {
            return url.replace(r, (match, v) => o[v]);
        };
    }

    public static Replacer(url: string, rpl: any): string {
        return Utilities.replacer(url)(rpl);
    }
}
