import { Injectable } from '@angular/core';
import { AuthWellKnownEndpoints, OpenIDImplicitFlowConfiguration, OidcSecurityService, OidcConfigService, AuthorizationResult, AuthorizationState } from 'angular-auth-oidc-client';
import { AppConfig } from '../config/app.config';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Utilities } from "./utilities";

@Injectable({
  providedIn: 'root'
})
export class AuthService {


  public isAuth(): Observable<boolean> {
    return this.oidcSecurityService.getIsAuthorized();
  }

  constructor(
    private oidcSecurityService: OidcSecurityService,
    private oidcConfigService: OidcConfigService,
    private router: Router) { }

  public Configurate() {
    this.configurateOidc();
    this.OidcModuleSetupSubscribe();
    this.AuthorizationResultSubscribe();
    this.onSessionChangedSubscribe();
  }

  public static LoadConfig(oidcConfigService: OidcConfigService) {
    console.log(AppConfig.oidcSettings.stsServer);
    return () => oidcConfigService.load_using_stsServer(AppConfig.oidcSettings.stsServer);
  }

  public authMonitor(): Observable<boolean> {
    return new Observable<boolean>((o) => {
      this.oidcSecurityService.onAuthorizationResult.subscribe(
        (authorizationResult: AuthorizationResult) => {
          o.next(authorizationResult.authorizationState === AuthorizationState.authorized);
          o.complete();
        });
      this.oidcSecurityService.getIsAuthorized().subscribe((a) => {
        o.next(a);
        if (a)
          o.complete();
      });
    });
  }

  public configurateOidc() {
    this.oidcConfigService.onConfigurationLoaded.subscribe(() => {


      let openIDImplicitFlowConfiguration = new OpenIDImplicitFlowConfiguration();
      openIDImplicitFlowConfiguration.stsServer = AppConfig.oidcSettings.stsServer;
      openIDImplicitFlowConfiguration.redirect_url = AppConfig.oidcSettings.redirect_url;
      openIDImplicitFlowConfiguration.client_id = AppConfig.oidcSettings.client_id;
      openIDImplicitFlowConfiguration.response_type = AppConfig.oidcSettings.response_type;
      openIDImplicitFlowConfiguration.scope = AppConfig.oidcSettings.scope;
      openIDImplicitFlowConfiguration.post_logout_redirect_uri = AppConfig.oidcSettings.post_logout_redirect_uri;
      openIDImplicitFlowConfiguration.post_login_route = AppConfig.oidcSettings.post_login_route;
      openIDImplicitFlowConfiguration.forbidden_route = AppConfig.oidcSettings.forbidden_route;
      openIDImplicitFlowConfiguration.unauthorized_route = AppConfig.oidcSettings.unauthorized_route;
      openIDImplicitFlowConfiguration.trigger_authorization_result_event = AppConfig.oidcSettings.trigger_authorization_result_event;
      openIDImplicitFlowConfiguration.log_console_warning_active = AppConfig.oidcSettings.log_console_warning_active;
      openIDImplicitFlowConfiguration.log_console_debug_active = AppConfig.oidcSettings.log_console_debug_active;
      openIDImplicitFlowConfiguration.start_checksession = AppConfig.oidcSettings.start_checksession;
      openIDImplicitFlowConfiguration.max_id_token_iat_offset_allowed_in_seconds = AppConfig.oidcSettings.max_id_token_iat_offset_allowed_in_seconds;

      const authWellKnownEndpoints = new AuthWellKnownEndpoints();
      authWellKnownEndpoints.setWellKnownEndpoints(this.oidcConfigService.wellKnownEndpoints);
      this.oidcSecurityService.setupModule(openIDImplicitFlowConfiguration, authWellKnownEndpoints);
    });
  }

  public OidcModuleSetupSubscribe() {

    if (this.oidcSecurityService.moduleSetup) {
      this.onOidcModuleSetup();
    } else {
      this.oidcSecurityService.onModuleSetup.subscribe(() => {
        this.onOidcModuleSetup();
      });
    }
  }

  public AuthorizationResultSubscribe() {
    this.oidcSecurityService.onAuthorizationResult.subscribe(
      (authorizationResult: AuthorizationResult) => {
        this.onAuthorizationResultComplete(authorizationResult);
      });
  }

  public onSessionChangedSubscribe() {
    this.oidcSecurityService.onCheckSessionChanged.subscribe((_) => {
      if (_) {
        this.oidcSecurityService.resetAuthorizationData(false);
        window.location.reload();
      }
    });
  }


  public onOidcModuleSetup() {
    if (Utilities.Parameter("oidcsignout")) {
      this.oidcSecurityService.resetAuthorizationData(false);
      this.router.navigate(["/unauthorized"]);
      return;
    }
    if (window.location.hash) {
      this.oidcSecurityService.authorizedImplicitFlowCallback();
    } else {
      let redirectUrl = AppConfig.isIE || AppConfig.isEdge ? window.location.pathname : this.router.url;
      redirectUrl = Utilities.onlyPath(redirectUrl);
      this.setItem('redirectURL', redirectUrl);
    }
  }

  private onAuthorizationResultComplete(authorizationResult: AuthorizationResult) {
    if (authorizationResult.authorizationState === AuthorizationState.authorized) {
      //<Workaround: restore AEID
      let redirectURL = this.getItem("redirectURL");
      if (!redirectURL)
        redirectURL = "/";
      //>Workaround: restore AEID
      this.router.navigate([redirectURL]);
    } else if (authorizationResult.authorizationState === AuthorizationState.forbidden) {
      this.router.navigate(['/forbidden']);
    } else {
      this.router.navigate(['/unauthorized']);
    }
  }

  private setItem(key: string, value: any) {
    sessionStorage.setItem(key, JSON.stringify(value));
  }

  private getItem(key: string): any {
    let value = sessionStorage.getItem(key);
    if (value) {
      return JSON.parse(value);
    }
    return null;
  }
}
