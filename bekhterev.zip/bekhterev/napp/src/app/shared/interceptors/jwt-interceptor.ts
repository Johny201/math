import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";
import { OidcSecurityService } from "angular-auth-oidc-client";
import { Injector, Injectable } from "@angular/core";

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    private oidcSecurityService: OidcSecurityService;
    constructor(private injector: Injector) { }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (this.oidcSecurityService === undefined) 
            this.oidcSecurityService = this.injector.get(OidcSecurityService);
        
        let token = this.oidcSecurityService.getToken();
        if (token)
            req = req.clone({
                setHeaders: {
                    Authorization: `Bearer ${token}`
                }
            });
        return next.handle(req);
    }
}
