export class Profile {
    username: string;
    name?: string;
    surname?: string;
    patronymic?: string;
    password?: string;
    roles?: string[];
}
