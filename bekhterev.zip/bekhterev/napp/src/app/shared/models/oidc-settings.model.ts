export class OidcSettings {
    stsServer: string;
    redirect_url: string;
    client_id: string;
    response_type: string;
    scope: string;
    post_logout_redirect_uri: string;
    post_login_route: string;
    forbidden_route: string;
    unauthorized_route: string;
    trigger_authorization_result_event: boolean;
    log_console_warning_active: boolean;
    log_console_debug_active: boolean;
    max_id_token_iat_offset_allowed_in_seconds: number;
    start_checksession: boolean;
  }
  