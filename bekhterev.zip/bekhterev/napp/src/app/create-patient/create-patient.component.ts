import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Patient, PersonalInfo } from '../patients/models';
import { PatientsService } from '../patients/patients.service';
import { NavClass } from '../nav/models';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-patient',
  templateUrl: './create-patient.component.html',
  styleUrls: ['./create-patient.component.scss']
})
export class CreatePatientComponent implements OnInit {

  constructor(private router: Router, private patietnsService: PatientsService, private toastr: ToastrService) { }
  model: Patient = new Patient();
  navlist: NavClass[] = [{
    clickable: true,
    routerlink: "/patients",
    title: "Пациенты"
  },{
    clickable: false,
    routerlink: "/patients",
    title: "Создать нового пациента"
  }]
  ngOnInit() {
    this.model.personal = new PersonalInfo();
  }

  createPatient() {
    this.patietnsService.createPatient(this.model).subscribe(_ => {
      this.toastr.success("Новый пациент успешно добавлен!")
      this.router.navigate(['/patients']);
    }, error => {

    })
  }

}
