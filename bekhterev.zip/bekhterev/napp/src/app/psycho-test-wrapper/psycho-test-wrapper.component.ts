import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {PatientsService} from "../patients/patients.service";
import {ToastrService} from "ngx-toastr";
import {Patient} from "../patients/models";
import {ActivatedRoute} from "@angular/router";
import {NavClass} from "../nav/models";

@Component({
  selector: 'app-psycho-test-wrapper',
  templateUrl: './psycho-test-wrapper.component.html',
  styleUrls: ['./psycho-test-wrapper.component.scss']
})
export class PsychoTestWrapperComponent implements OnInit {

  constructor(private patientsService: PatientsService, private toastr: ToastrService, private activatedRoute: ActivatedRoute) { }
  patient: Patient = new Patient();
  navlist: NavClass[] = [];
  pid: string = "";
  ableToAddRes = false;
  checked = 0;
  AnalysysInputVisible: boolean = false;

  ngOnInit() {
    this.activatedRoute.params.subscribe((params: any) => {
      this.navlist = [{
        clickable: true,
        routerlink: "/patients",
        title: "Пациенты"
      }]
      this.initFields();
      console.log(params);
      if (params['pid']) {
        this.pid = params['pid'];
        this.getPatient(this.pid);
      }
    });
  }

  initFields() {
    this.pid = "";
    this.patient = new Patient();
  }

  get isFullView() {
    return true;
  }

  updatePatient(s: any)
  {
    this.patientsService.updatePatient(s).subscribe(x => {
    this.getPatient(this.pid)
    })
  }

  getPatient(id: string) {
    console.log('ID ', id);
    this.patientsService.getPatient(id).subscribe(data => {
      if (this.checked == 0)
        this.checked = 1;
      this.patient = data;

      this.ableToAddRes = true;

      if (this.navlist.length > 1) this.navlist.pop();
      if (this.navlist.length > 1) this.navlist.pop();
      if (this.navlist.length > 1) this.navlist.pop();

      this.navlist.push({
        clickable: true,
        routerlink: "/patient/"+this.patient._id+"/all",
        title: (this.patient.personal ? (this.patient.personal.lastname + ' ' + this.patient.personal.firstname + ' ' + this.patient.personal.patronymic) : ("Пациент #" + this.patient._id))
      })

        this.navlist.push({
          clickable: false,
          routerlink: "/psycho/"+this.patient._id+"/all",
          title: "Психотесты"
        })

    });

  }

}
