import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { UnauthorizedComponent } from "./login-components/unauthorized/unauthorized.component";
import { ForbiddenComponent } from "./login-components/forbidden/forbidden.component";
import { AuthGuard } from "./shared/guards/auth.guard";
import { ProfileComponent } from "./profile/profile.component";
import { PatientsComponent } from "./patients/patients.component";
import { DicomViewComponent } from "./DICOM-view/dicom-view.component";
import { AnalyzesComponent } from "./analyzes/analyzes.component";
import { CreatePatientComponent } from "./create-patient/create-patient.component";
import { ViewPatientComponent } from "./patients/view-patient/view-patient.component";
import {PsychoTestWrapperComponent} from "./psycho-test-wrapper/psycho-test-wrapper.component";

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'psycho/:pid',
    component: PsychoTestWrapperComponent,
  },
  { path: 'home', component: HomeComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: 'forbidden', component: ForbiddenComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
  {
    path: 'patients', component: PatientsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'MRI/:pid/:aid', component: DicomViewComponent, canActivate: [AuthGuard]
  },
  {
    path: 'analyzes', component: AnalyzesComponent, canActivate: [AuthGuard]
  },
  { path: 'createpatient', component: CreatePatientComponent, canActivate: [AuthGuard] },
  {
    path: 'patient/:pid/:aid', 
    component: ViewPatientComponent,
  },
  {
    path: 'auth',
    loadChildren: "src/app/oidc/oidc.module#OidcModule"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule {}
