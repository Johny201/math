import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AuthService } from './shared/services/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader";
import { ProfileService } from "./profile/profile.service";
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { AppConfig } from './shared/config/app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'napp';
  constructor(private ngxService: NgxUiLoaderService, private authService: AuthService, private oidcSecurityService: OidcSecurityService) { }
  public isAuth = this.authService.isAuth();

  logout() {
    this.oidcSecurityService.logoff();
  }
  login() {
    if (this.oidcSecurityService.moduleSetup)
      this.oidcSecurityService.authorize();
    else
      this.oidcSecurityService.onModuleSetup.subscribe(() => {
        this.oidcSecurityService.authorize();
      })
  }

  ngOnInit(): void {

  }

  ngAfterViewInit(): void {
  }
}
