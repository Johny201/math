import { Component, OnInit } from '@angular/core';
import { PatientsService } from '../patients/patients.service';
import { ToastrService } from 'ngx-toastr';
import { AnalysisInfo } from '../patients/models';
import { AnalysisGroupInfo } from '../patients/models/analysisGroupInfo.model';
import {AnalysisTypemap} from "../patients/view-patient/patient-analysis/constants";

@Component({
  selector: 'app-analyzes',
  templateUrl: './analyzes.component.html',
  styleUrls: ['./analyzes.component.scss']
})
export class AnalyzesComponent implements OnInit {

  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }
  public analyzes: AnalysisInfo[] = [];
  public analyzesView: AnalysisGroupInfo[] = [];

  options = {
    sort: 1,
    group: 0,
    ad_sort: 1
  }
  model_options = {
    sort: 1,
    group: 0,
    ad_sort: 1
  }

  AnalysisTypeToTitle(t: string): string {
    return t in AnalysisTypemap ? AnalysisTypemap[t] : t;
  }

  ngOnInit() {
    if ("aw_options" in sessionStorage) {
      this.model_options = JSON.parse(sessionStorage.getItem("aw_options"));
    }
    this.patientsService.getAnalyzesInfo().subscribe(data => {
      this.analyzes = data;
      this.reinitView();
    }, e => {
      this.toastr.error("Ошибка получения списка пациентов");
    })
  }

  reinitView() {
    this.options = JSON.parse(JSON.stringify(this.model_options));
    sessionStorage.setItem("aw_options", JSON.stringify(this.model_options));
    this.analyzesView = this.group(this.sort(this.analyzes));
  }

  apply() {
    this.reinitView();
  }

  group(list: AnalysisInfo[]): AnalysisGroupInfo[] {
    if (this.options.group === 0)
      return [{ analyzes: list, title: "", collapse: true }];
    if (this.options.group === 1)
      return this.groupBy(list, (a) => a.number + "", (a) => "Пациент #" + a)
    if (this.options.group === 2)
      return this.groupBy(list, (a) => "" + a.analyzes.creationDate, (a) => "Дата " + a)
    if (this.options.group === 3)
      return this.groupBy(list, (a) => this.AnalysisTypeToTitle(a.analyzes.contentType), (a) => "Тип анализа: " + a)
    return [{ analyzes: list, title: "", collapse: true }];
  }

  sort(list: AnalysisInfo[]): AnalysisInfo[] {
    if (this.options.ad_sort === 1) {
      if (this.options.sort === 1)
        return list.sort((a, b) => this.compareNumbers(a.number, b.number));
      if (this.options.sort === 2)
        return list.sort((a, b) => this.compareDates(a.analyzes.creationDate, b.analyzes.creationDate));
      if (this.options.sort === 3)
        return list.sort((a, b) => this.compareStrings(this.AnalysisTypeToTitle(a.analyzes.contentType), this.AnalysisTypeToTitle(b.analyzes.contentType)));
    }
    if (this.options.ad_sort === 2) {
      if (this.options.sort === 1)
        return list.sort((a, b) => -this.compareNumbers(a.number, b.number));
      if (this.options.sort === 2)
        return list.sort((a, b) => -this.compareDates(a.analyzes.creationDate, b.analyzes.creationDate));
      if (this.options.sort === 3)
        return list.sort((a, b) => -this.compareStrings(a.analyzes.contentType, b.analyzes.contentType));
    }
    return list.sort((a, b) => this.compareNumbers(a.number, b.number));
  }

  compareDates(a: Date, b: Date): number {
    if (a < b)
      return -1;
    if (a > b)
      return 1;
    return 0;
  }
  compareNumbers(a: number, b: number): number {
    return a - b;
  }
  compareStrings(a: string, b: string): number {
    if (a < b)
      return -1;
    if (a > b)
      return 1;
    return 0;
  }

  groupBy(list: AnalysisInfo[], keyFunc: (item: AnalysisInfo) => string, titleFunc: (items: string) => string): AnalysisGroupInfo[] {
    let ret: {
      [id: string]: AnalysisInfo[]
    } = {};
    for (const item of list) {
      let key = keyFunc(item);
      if (key in ret)
        ret[key].push(item);
      else
        ret[key] = [item];
    }
    let rret: AnalysisGroupInfo[] = [];
    for (const id in ret) {
      if (ret.hasOwnProperty(id)) {
        const item = ret[id];
        rret.push({
          collapse: true,
          title: titleFunc(id),
          analyzes: item
        })
      }
    }
    return rret;
  }
}
