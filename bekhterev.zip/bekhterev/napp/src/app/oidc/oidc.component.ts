import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oidc',
  templateUrl: './oidc.component.html',
  styleUrls: ['./oidc.component.scss']
})
export class OidcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
