import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { OidcComponent } from "./oidc.component";

const routes: Routes = [{
  path: '',
  component: OidcComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class OidcRoutingModule { }