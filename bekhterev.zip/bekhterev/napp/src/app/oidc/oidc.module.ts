import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OidcComponent } from './oidc.component';
import { RegComponent } from './reg/reg.component';
import { ChangePassComponent } from './change-pass/change-pass.component';
import { OidcRoutingModule } from './oidc-routing.module';
import { OauthComponent } from './oauth/oauth.component';

@NgModule({
  imports: [
    CommonModule,
    OidcRoutingModule
  ],
  declarations: [OidcComponent, RegComponent, ChangePassComponent, OauthComponent]
})
export class OidcModule { }
