import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DicomViewComponent } from './dicom-view.component';

describe('DicomViewComponent', () => {
  let component: DicomViewComponent;
  let fixture: ComponentFixture<DicomViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DicomViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DicomViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
