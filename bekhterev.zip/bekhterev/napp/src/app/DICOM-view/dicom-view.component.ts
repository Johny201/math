import { Component, OnInit, Input } from '@angular/core';
import { PatientsService } from '../patients/patients.service';
import { Patient } from '../patients/models';
import { ToastrService } from 'ngx-toastr';
import { NavClass } from '../nav/models';
import {Analysis} from "../patients/models";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-dicom-view',
  templateUrl: './dicom-view.component.html',
  styleUrls: ['./dicom-view.component.scss']
})
export class DicomViewComponent implements OnInit {
  navlist: NavClass[] = [];

  patient: Patient = new Patient();
  pid: string = "";
  aid: string = "";
  analysis :Analysis;


  constructor(private patientsService: PatientsService, private toastr: ToastrService, private activatedRoute: ActivatedRoute) { }

  public patients: Patient[] = [];

  ngOnInit() {
    this.activatedRoute.params.subscribe((params: any) => {
      this.navlist = [{
        clickable: true,
        routerlink: "/patients",
        title: "Пациенты"
      }];

      this.initFields();

      this.pid = params['pid'];
      this.aid = params['aid'];
      this.getPatient(this.pid);

    })
  }

  initFields() {
    this.pid = "";
    this.aid = "";
    this.patient = new Patient();
  }

  createArray(n: number)
  {
    return Array.apply(null, {length: n}).map(Number.call, Number)
  }

  getPatient(id: string) {
    this.patientsService.getPatient(id).subscribe(data => {

      this.patient = data;

      if (this.navlist.length > 1) this.navlist.pop();

      this.navlist.push({
        clickable: true,
        routerlink: "/patient/"+this.patient._id+"/all",
        title: (this.patient.personal ? (this.patient.personal.lastname + ' ' + this.patient.personal.firstname + ' ' + this.patient.personal.patronymic) : ("Пациент #" + this.patient._id))
      })

        this.navlist.push({
          clickable: true,
          routerlink: "/patient/"+this.patient._id+"/"+this.aid,
          title: "Анализ #" + this.aid
        })

      this.navlist.push({
        clickable: false,
        routerlink: "/patient/"+this.patient._id+"/"+this.aid,
        title: "Просмотр снимков"
      })



      this.analysis = this.patient.analyzes.filter((x) => { return (x._id.toString() == this.aid.toString()) })[0];
      console.log(this.analysis);

    });

  }
}
