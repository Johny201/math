import { Analysis } from "./analysis.model";

export interface AnalysisInfo {
    _id: string;
    number: number;
    analyzes: Analysis;
}