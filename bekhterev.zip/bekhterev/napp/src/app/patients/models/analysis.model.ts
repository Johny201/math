import {PatientFile, RemoteFile} from "./file.model";

export class Analysis {
    removed?: boolean;
    contentType: string;
    title?: string;
    description?: string;
    creationDate?: Date;
    hiddenData?: any;
    numOfVisit: Number = 1;
    data?: any;
    date?: Date;
    files?: RemoteFile[];
    _id?: string;
}
