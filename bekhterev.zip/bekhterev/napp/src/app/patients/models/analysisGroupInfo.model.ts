import { AnalysisInfo } from "./analysisInfo.model";

export interface AnalysisGroupInfo {
    title: string;
    analyzes: AnalysisInfo[];
    collapse: boolean;
}