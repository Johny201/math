
export class Anamnez {
    removed?: boolean;
    creationDate?: Date;
    hiddenData?: any;
    data?: any;
    _id?: string;

}
