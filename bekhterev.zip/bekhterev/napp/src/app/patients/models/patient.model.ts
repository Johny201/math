import { Analysis } from "./analysis.model";
import { PersonalInfo } from "./personal-info.model";
import {PatientFile} from "./file.model";
import {Anamnez} from "./anamnez.model";
import {PsyhoTest} from "../../psyhological-test-component/models/psyho-test";

export class Patient {
    analyzes: Analysis[];
    files: PatientFile[];
    removed?: boolean;
    hash?: string;
    creationDate?: Date;
    personal?: PersonalInfo;
    psyhoTest?: PsyhoTest;
    number: number;
    group?: number;
    _id?: string;
    numOfVisits: number = 1;
    anamnez?: Anamnez;
}
