export class PatientFile {
    removed?: boolean;
    contentType: string;
    title?: string;
    description?: string;
    creationDate?: Date;
    hiddenData?: any;
    data?: any;
    _id?: string;
}

export class RemoteFile {
  type?: string;
  description?: string;
  creationDate?: Date;
  name?: any;
  data?: any;
  fileId?: string;
  analysisId: string;
}
