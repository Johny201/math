export * from './patient.model';
export * from './analysis.model';
export * from './file.model';
export * from './analysisInfo.model';
export * from './personal-info.model';
export * from './anamnez.model'
export * from './anamnez.scheme'
