export class PersonalInfo {
    firstname: string;
    lastname: string;
    patronymic: string;
    birthday: Date;
}
