export const lymphocytesForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": "string"
      },
      "description": {
        "type": "string"
      },
      "data": {
        "type": "object",
        "properties": {
          "protein": { "type": "number", "title": "Кол-во белка влимф мг/л" },
          "SOD": { "type": "number", "title": "СОД ЕД/мл" },
          "SOD-lymph": { "type": "number", "title": "СОД ЕД/ мг белка в лимф" },
          "GR": { "type": "number", "title": "ГР Ед/л" },
          "GR-lymph": { "type": "number", "title": "ГР ЕД/мг белка в лимф" },
          "GP": { "type": "number", "title": "ГП Е/л" },
          "GP-lymph": { "type": "number", "title": "ГП ЕД/мг белка в лимф" },
          "BDNF": { "type": "number", "title": "БДНФ в сыв" },
        },
        "required": []
      }
    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата" },
    { "key": "data.protein", "placeholder": "Числовое значение" },
    { "key": "data.SOD", "placeholder": "Числовое значение" },
    { "key": "data.SOD-lymph", "placeholder": "Числовое значение" },
    { "key": "data.GR", "placeholder": "Числовое значение" },
    { "key": "data.GR-lymph", "placeholder": "Числовое значение" },
    { "key": "data.GP", "placeholder": "Числовое значение" },
    { "key": "data.GP-lymph", "placeholder": "Числовое значение" },
    { "key": "data.BDNF", "placeholder": "Числовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": "textarea" },
    { "type": "submit", "title": "Отправить" },
  ]

};