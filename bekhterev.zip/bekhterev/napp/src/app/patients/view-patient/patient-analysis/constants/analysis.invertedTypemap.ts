import { schemas } from "../forms"
let AnalysisInvertedTypemap: { [id: string]: string; } = {
    // "textData": "Текстовые данные",
    // "numberData": "Числовые данные"
}

for (const schema of schemas) {
    if (!(schema.type in AnalysisInvertedTypemap)) {
        AnalysisInvertedTypemap[schema.title] = schema.type;
    }
}

export { AnalysisInvertedTypemap }