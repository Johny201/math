export const biochemistryForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": "string"
      },
      "description": {
        "type": "string"
      },
      "data": {
        "type": "object",
        "properties": {
          "albumen": { "type": "number", "title": "Альбумин" },
          "cholesterol": { "type": "number", "title": "Холестерин" },
          "total-protein": { "type": "number", "title": "Общий белок" },
          "glucose": { "type": "number", "title": "Глюкоза" },
          "LPVP": { "type": "number", "title": "ЛПВП" },
          "LPNP": { "type": "number", "title": "ЛПНП" },
          "triglycerides": { "type": "number", "title": "Триглицериды" },
          "C-reactive-protein": { "type": "number", "title": "С-реактивный белок" },
          "Ka": { "type": "number", "title": "К.а" },
        },
        "required": []
      }

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата" },
    { "key": "data.albumen", "placeholder": "Числовое значение" },
    { "key": "data.cholesterol", "placeholder": "Числовое значение" },
    { "key": "data.total-protein", "placeholder": "Числовое значение" },
    { "key": "data.glucose", "placeholder": "Числовое значение" },
    { "key": "data.LPVP", "placeholder": "Числовое значение" },
    { "key": "data.LPNP", "placeholder": "Числовое значение" },
    { "key": "data.triglycerides", "placeholder": "Числовое значение" },
    { "key": "data.C-reactive-protein", "placeholder": "Числовое значение" },
    { "key": "data.Ka", "placeholder": "Числовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": "textarea" },
    { "type": "submit", "title": "Отправить" },
  ]

};