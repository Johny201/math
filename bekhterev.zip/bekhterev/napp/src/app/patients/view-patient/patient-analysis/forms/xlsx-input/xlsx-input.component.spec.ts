import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XlsxInputComponent } from './xlsx-input.component';

describe('XlsxInputComponent', () => {
  let component: XlsxInputComponent;
  let fixture: ComponentFixture<XlsxInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XlsxInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XlsxInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
