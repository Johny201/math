export const psycho = {
    "schema": {
        "type": "object",
        "properties": {
            "date": {
                "type": 'string'
            },
            "description": {
                "type": 'string'
            },
            "data": {
                "type": "object",
                "properties": {
                    MMSE: { type: "number", "minimum": 0, "maximum": 30, "title": "MMSE"},
                    clock: { type: "number", "minimum": 0, "maximum": 10, "title": "Тест часов"},
                    FAB: { type: "number", "minimum": 0, "maximum": 18, "title": "Батарея лобной дисфункции" }
                },
                "required": []
            }

        },
        "required": []
    },
    "layout": [
        { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
        { "key": "data.MMSE",  "validationMessage": "Неверное значение" },
        { "key": "data.clock",  "placeholder": "", "validationMessage": "Неверное значение" },
        { "key": "data.FAB",  "placeholder": "", "validationMessage": "Неверное значение" },
        { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
        { type: "submit", title: "Отправить" },
    ]

};
