export class Form {
    type: string;
    title: string;
    schema?: object;
    isSchema: boolean;
    component_type?: string;
    color?: string;
    isInResearch: boolean;
    files?: string[];
}
