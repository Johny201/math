export const hormonesForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": "string"
      },
      "description": {
        "type": "string"
      },
      "data": {
        "type": "object",
        "properties": {
          "prolactin": { "type": "number", "title": "Пролактин" },
          "cortisol": { "type": "number", "title": "Кортизол" },
          "dehydroepiandrosterone-sulfate": { "type": "number", "title": "Дегидроэпиандростерона-сульфат" },
          "estradiol": { "type": "number", "title": "Эстрадиол" },
          "insulin": { "type": "number", "title": "Инсулин" },
          "TTG": { "type": "number", "title": "ТТГ" },
          "T3": { "type": "number", "title": "Т3 своб." },
          "T4": { "type": "number", "title": "Т4 своб." },
        },
        "required": []
      }

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата" },
    { "key": "data.prolactin", "placeholder": "Числовое значение" },
    { "key": "data.cortisol", "placeholder": "Числовое значение" },
    { "key": "data.dehydroepiandrosterone-sulfate", "placeholder": "Числовое значение" },
    { "key": "data.estradiol", "placeholder": "Числовое значение" },
    { "key": "data.insulin", "placeholder": "Числовое значение" },
    { "key": "data.TTG", "placeholder": "Числовое значение" },
    { "key": "data.T3", "placeholder": "Числовое значение" },
    { "key": "data.T4", "placeholder": "Числовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": "textarea" },
    { "type": "submit", "title": "Отправить" },
  ]

};
