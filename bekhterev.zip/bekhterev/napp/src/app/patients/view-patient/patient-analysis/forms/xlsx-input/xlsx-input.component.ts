import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import * as XLSX from 'xlsx';
import { ToastrService } from 'ngx-toastr';
import { Patient, Analysis } from 'src/app/patients/models';
import { PatientsService } from 'src/app/patients/patients.service';
type AOA = any[][];

@Component({
  selector: 'app-xlsx-input',
  templateUrl: './xlsx-input.component.html',
  styleUrls: ['./xlsx-input.component.scss']
})
export class XlsxInputComponent implements OnInit {
  @Input() patient: Patient;
  @Output() uploaded = new EventEmitter<Analysis[]>();
  data: AOA = [];

  inputdata: {
    title: string,
    comment: string,
    delnum: number,
    type: string
  } = {
      title: "",
      comment: "",
      delnum: 0,
      type: "many"
    }

  constructor(private toastr: ToastrService, private patientsService: PatientsService) { }

  get viewdata(): AOA {
    let ret: AOA = []
    for (let i = 0; i < this.data.length; i++) {
      const row = this.data[i];
      if (i >= this.inputdata.delnum)
        ret.push(row);
    }
    return ret;
  }


  ngOnInit() {
  }

  inputfile(event: any) {
    this.data = [];
    const target: DataTransfer = <DataTransfer>(event.target);
    if (target.files.length !== 1) {
      this.toastr.error("Поддерживается импорт только по одному xlsx файлу");
      return;
    };
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
    };
    reader.readAsBinaryString(target.files[0]);
  }

  upload() {
    if (this.inputdata.type === "one") {
      let analysis = new Analysis();
      analysis.contentType = "XLSXData";
      analysis.description = this.inputdata.comment;
      analysis.title = this.inputdata.title;
      if (analysis.title === "") {
        this.toastr.error("Поле 'Название' не должно быть пустым!");
        return;
      }
      analysis.data = {
        value: this.data
      }
      this.UploadAnalyzes([analysis]);
    }
    else {
      let analyzes: Analysis[] = [];
      for (const d of this.viewdata) {

        let analysis = new Analysis();
        analysis.description = this.inputdata.comment;
        analysis.title = d[0];
        analysis.data = {
          value: d[1]
        }
        analysis.contentType = typeof analysis.data.value == "number" ? "numberData" : "textData";
        analyzes.push(analysis);
      }
      this.UploadAnalyzes(analyzes);
    }
  }

  UploadAnalyzes(analyzes: Analysis[]) {
    this.uploaded.emit(analyzes);
  }
}
