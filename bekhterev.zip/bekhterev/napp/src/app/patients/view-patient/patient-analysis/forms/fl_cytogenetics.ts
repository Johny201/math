export const cytogeneticsForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": "string"
      },
      "description": {
        "type": "string"
      },
      "data": {
        "type": "object",
        "properties": {
          cytogenetics: { type: "number", "title": "Цитогенетика" },
          "normalized-cytogenic": { type: "number", "title": "Цитоген нормированная" },
          immunology: { type: "number", "title": "Иммунология" },
        },
        "required": []
      }

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата" },
    { "key": "data.cytogenetics", "placeholder": "Числовое значение" },
    { "key": "data.normalized_cytogenic", "placeholder": "Числовое значение" },
    { "key": "data.immunology", "placeholder": "Числовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": "textarea" },
    { "type": "submit", "title": "Отправить" },
  ]

};
