
export const descriptionForm = {
    "schema": {
        "type": "object",
        "properties": {
            "date": {
              "type": 'string'
            },
            "description": {
                "type": 'string'
            },
            "data": {
                "type": "object",
                "properties": {
                  diagnosis: { type: "string", "title": "Клинический диагноз" },
                  syndrome: { type: "string", "title": "Ведущий синдром" },
                  degree: { type: "string", "title": "Тяжесть" },
                  process: { type: "string", "title": "Предполагаемый процесс" }
                },
                "required": []
            }

        },
        "required": []
    },
    "layout": [
        { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
        { "key": "data.diagnosis", "placeholder": "Текстовое значение" },
        { "key": "data.syndrome", "placeholder": "Текстовое значение" },
        { "key": "data.degree", "placeholder": "Текстовое значение" },
        { "key": "data.process", "placeholder": "Текстовое значение" },
        { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
        { type: "submit", title: "Отправить"},
    ]

};

