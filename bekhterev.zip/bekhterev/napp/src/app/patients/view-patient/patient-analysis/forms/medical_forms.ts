

export const bloodForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": 'string'
      },
      "description": {
        "type": 'string'
      },
      "data": {
        "type": "object",
        "properties": {
          sex: { type: "string", "title": "Клинический диагноз" },
          birth: { type: "string", "title": "Ведущий синдром" },
          age: { type: "string" , "title": "Тяжесть"},
          education: { type: "string", "title": "Предполагаемый процесс" },
          work: { type: "string", "title": "Клинический диагноз" },
          family: { type: "string", "title": "Ведущий синдром" },
          home: { type: "string", "title": "Тяжесть" },
          life: { type: "string", "title": "Предполагаемый процесс" }
        },
        "required": []
      }

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
    { "key": "data.sex", "placeholder": "Текстовое значение" },
    { "key": "data.birth", "placeholder": "Текстовое значение" },
    { "key": "data.age", "placeholder": "Текстовое значение" },
    { "key": "data.education", "placeholder": "Текстовое значение" },
    { "key": "data.work", "placeholder": "Текстовое значение" },
    { "key": "data.family", "placeholder": "Текстовое значение" },
    { "key": "data.home", "placeholder": "Текстовое значение" },
    { "key": "data.life", "placeholder": "Текстовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
    { type: "submit", title: "Отправить"},
  ]

};

export const MRIForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": 'string'
      },
      "description": {
        "type": 'string'
      },
      "data": {
        "type": "object",
        "properties": {
          result: { type: "string", "title": "заключение" },
        },
        "required": []
      },

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
    { "key": "data.result", "placeholder": "Текстовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
    { type: "submit", title: "Отправить"},
  ]

};

export const EEGForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": 'string'
      },
      "description": {
        "type": 'string'
      },
      "data": {
        "type": "object",
        "properties": {
          result: { type: "string", "title": "заключение" },
        },
        "required": []
      },

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
    { "key": "data.result", "placeholder": "Текстовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
    { type: "submit", title: "Отправить"},
  ]

};

export const hormonalForm = {
  "schema": {
    "type": "object",
    "properties": {
      "date": {
        "type": 'string'
      },
      "description": {
        "type": 'string'
      },
      "data": {
        "type": "object",
        "properties": {
          sex: { type: "string" },
          birth: { type: "string" },
          age: { type: "string" },
          education: { type: "string" },
          work: { type: "string" },
          family: { type: "string" },
          home: { type: "string" },
          life: { type: "string" }
        },
        "required": []
      }

    },
    "required": []
  },
  "layout": [
    { "key": "date", "title": "Дата проведения анализа", "type": "date", "validationMessage": "Неправильная дата"},
    { "key": "data.sex", "title": "Клинический диагноз", "placeholder": "Текстовое значение" },
    { "key": "data.birth", "title": "Ведущий синдром", "placeholder": "Текстовое значение" },
    { "key": "data.age", "title": "Тяжесть", "placeholder": "Текстовое значение" },
    { "key": "data.education", "title": "Предполагаемый процесс", "placeholder": "Текстовое значение" },
    { "key": "data.work", "title": "Клинический диагноз", "placeholder": "Текстовое значение" },
    { "key": "data.family", "title": "Ведущий синдром", "placeholder": "Текстовое значение" },
    { "key": "data.home", "title": "Тяжесть", "placeholder": "Текстовое значение" },
    { "key": "data.life", "title": "Предполагаемый процесс", "placeholder": "Текстовое значение" },
    { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
    { type: "submit", title: "Отправить"},
  ]

};
