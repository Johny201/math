export const SimpleNumberForm = {
    "schema": {
        "type": "object",
        "properties": {
            "title": {
                "type": 'string'
            },
            "description": {
                "type": 'string'
            },
            "data": {
                "type": "object",
                "properties": {
                    value: { type: "number" }
                },
                "required": ["value"]
            }

        },
        "required": ["title"]
    },
    "layout": [
        { "key": "title", "title": "Название", "placeholder": "Название" },
        { "key": "description", "title": "Комментарий", "placeholder": "Комментарий", "type": 'textarea'},
        { "key": "data.value", "title": "Значение", "placeholder": "Числовое значение" },
        { type: "submit", title: "Отправить" },
    ]

};