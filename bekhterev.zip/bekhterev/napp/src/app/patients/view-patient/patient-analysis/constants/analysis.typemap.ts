import { schemas } from "../forms"
let AnalysisTypemap: { [id: string]: string; } = {
    // "textData": "Текстовые данные",
    // "numberData": "Числовые данные"
}

for (const schema of schemas) {
    if (!(schema.type in AnalysisTypemap)) {
        AnalysisTypemap[schema.type] = schema.title;
    }
}

export { AnalysisTypemap }