import {
  AfterViewInit,
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import { Patient, Analysis } from '../../models';
import { schemas } from './forms';
import { Form } from './models/form.model';
import { rBootstrap4FrameworkComponent } from 'src/app/shared/components/russianBootstrap4Form/rbf.component';
import { AnalysisTypemap } from './constants';
import { TemplateRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import {isNullOrUndefined} from "util";
import {ViewAnalysisComponent} from "../view-analysis/view-analysis.component";

@Component({
  selector: 'app-patient-analysis',
  templateUrl: './patient-analysis.component.html',
  styleUrls: ['./patient-analysis.component.scss', '../patient-section.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PatientAnalysisComponent implements AfterViewInit, OnInit {
  _patient: Patient;
  analysesToView = []
  pgpr:number[] = [];
  pgtype = [];
  editing = [];
  get patient(): Patient {
    return this._patient;

  }

  @Input() numOfVizit = 1;

  @Input('patient')
  set patient(value: Patient) {
    this._patient = value;
    if (this._patient.analyzes)
      this.analysesToView = this._patient.analyzes.filter((x) => {return (x.numOfVisit == this.numOfVizit)});
    if (isNullOrUndefined(this.dtElement.dtInstance)) this.dtTrigger.next();
    if (!isNullOrUndefined(this.analysesToView)) {
      this.pgpr = []
      this.pgtype = []
      this.editing = []
      this.analysesToView.forEach((item, i, arr) => {
        this.editing.push({});
        let count1 = 0
        let count2 = 0

        for (let an in item.data) {
          if (!(isNullOrUndefined(item.data[an]) || item.data[an] == "")) {
            count1++
          }
          let schema = this.schemas.find((x) => {return x.type == item.contentType})
          count2 = Object.keys(schema.schema["schema"]["properties"]["data"]["properties"]).length
        }
        console.log(count1, count2, i, this.analysesToView.length);
        if (count2 > 0) {
          let perc = (count1 / count2) * 100
          this.pgpr.push(perc)
          if (perc < 50) this.pgtype.push('danger')
          else if (perc < 100) this.pgtype.push('warning')
          else this.pgtype.push('success')

        }
        else
        {this.pgpr.push(0)
          this.pgtype.push('danger')}
      });
    }
  }

  @Output() reloader = new EventEmitter<string>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  collapse: boolean = false;
  AnalysysInputVisible: boolean = false;
  inputFormType: number = 0;


  rows = [];
  constructor(private patientsService: PatientsService, private toastr: ToastrService, private modalService: BsModalService) {
    for (let i = 0; i < (this.schemas.length + 2); i += 3) {
      let row = [];
      for (let k = i; k < i + 3 && k < this.schemas.length; k += 1)
      {
        row.push(this.schemas[k]);
      }
      this.rows.push(row);
    }

  }
  dtOptions: DataTables.Settings = {destroy: true, lengthChange: false, paging: false, autoWidth: false, searching: false};
  dtTrigger: Subject<any> = new Subject();

  get jsonSchemaForm(): object {
    return this.schemas[this.inputFormType].schema;
  }

  get isJsonSchema(): boolean {
    return !!this.schemas[this.inputFormType].schema;
  }

  get componentType(): string {
    return this.schemas[this.inputFormType].component_type;
  }

  get formType(): string {
    return this.schemas[this.inputFormType].type;
  }

  framework = {
    framework: rBootstrap4FrameworkComponent
  }

  modalRef: BsModalRef;
  modalRef2: BsModalRef;
  modalRef3: BsModalRef;

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  openAnalysisModal(analysis) {
    const initialState = { analysis:analysis, patient:this._patient, par:this}
    this.modalRef3 = this.modalService.show(ViewAnalysisComponent, {class:"my-modal", initialState});

  }
  openNewAnalysisModal(index, template: TemplateRef<any>) {
    this.inputFormType = index
    this.modalRef2 = this.modalService.show(template, );
  }

  deleteAnalysis(analysis: Analysis, i: number) {
    this.patientsService.deleteAnalysis(this.patient._id, analysis._id)
      .subscribe(_ => {
        this.toastr.success('Анализ удален', 'Анализ успешно удален');
        this.analysesToView.splice(i, 1);
        this.updatePatient(this.patient._id);

      }, error => { this.toastr.error(error.message); });
  }

  ngOnInit() {
  }

  schemas: Form[] = schemas;
  onsubmit(analysis: Analysis) {
    let t = this.formType;
    analysis.contentType = t;
    analysis.creationDate = new Date();
    analysis.numOfVisit = this.numOfVizit;
    if (t === "XLSXData") {

    }
    else {
      this.UploadAnalysis(analysis).subscribe(
        _ => {
          this.toastr.success('Сохранено', 'Данные сохранены');
          this.modalRef2.hide()
          this.modalRef.hide()
          this.reloader.emit(this.patient._id);
        },
        error => {
          this.toastr.error('Ошибка', error.error.message.toString());
          console.log(error);
        });
    }
  }


  updatePatient(id: string) {
    this.reloader.emit(this.patient._id);
  }

  ngAfterViewInit(): void {
    this.reloader.emit(this.patient._id);
  }


  AnalysisTypeToTitle(t: string): string {
    return t in AnalysisTypemap ? AnalysisTypemap[t] : t;
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
    $.fn['dataTable'].ext.search.pop();
  }


  uploadAnalyzes(analyzes: Analysis[]) {
    let n = analyzes.length;
    let i = 0;
    for (const analysis of analyzes) {
      this.UploadAnalysis(analysis).subscribe(
        _ => {
          i++;
          if (n > 1) {
            this.toastr.success('Сохранено', 'Данные сохранены. Осталось ' + (n - i));
            console.log(n - i, n - i === 0)
            if (n - i === 0) {
              this.reloader.emit(this.patient._id);
              this.AnalysysInputVisible = false;
            }

          }
          else {
            this.toastr.success('Сохранено', 'Данные сохранены');
            this.reloader.emit(this.patient._id);
            this.AnalysysInputVisible = false;
          }
        },
        error => {
          this.toastr.error('Ошибка', error.error.message.toString());
          console.log(error);
        });
    }

    // function showtoaster(that) {
    //   i++;
    //   if (n == 1)
    //     that.toastr.success('Сохранено', 'Данные сохранены. Осталось ' + (n - i));
    //   else
    //     that.toastr.success('Сохранено', 'Данные сохранены');
    // }
  }

  UploadAnalysis(analysis: Analysis) {
    return this.patientsService.uploadAnalysis(this.patient._id, analysis);
    // console.log(this.AnalysisInput);
  }


  updateComment(event, index:any,  property: any) {
    if (property == 'comment')
      this.patient.analyzes[index].description = event.target.value;
    else if (property == 'date')
      this.patient.analyzes[index].date = event.target.value;
    this.UpdateAnalysis(this.patient.analyzes[index]).subscribe(x => {
      this.editing[index][property] = false;
    })
  }

  UpdateAnalysis(analysis: Analysis) {
    return this.patientsService.updateAnalysis(analysis);
    // console.log(this.AnalysisInput);
  }
}
