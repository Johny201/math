import { Form } from "../models/form.model";
import { SimpleNumberForm } from "./simpleNumberForm";
import { SimpleTextForm } from "./simpleTextForm";
import { psycho } from "./psycho";
import { descriptionForm } from "./descriptionForm";
import { bloodForm, hormonalForm, MRIForm, EEGForm } from "./medical_forms";

import { biochemistryForm } from "./fl_biochemistry";
import { cytogeneticsForm } from "./fl_cytogenetics";
import { hormonesForm } from "./fl_hormones";
import { lymphocytesForm } from "./fl_lymphocytes";

let schemas: Form[] = [
   /* {
        type: "XLSXData",
        title: "Excel-файл",
        isSchema: false,
        component_type: "xlsx_input",
        color: "#fafafa",
        isInResearch: false
    },*/
    {
        type: "psychoData",
        title: "ЭПО",
        schema: psycho,
        isSchema: true,
        color: "#a8faa4",
        isInResearch: true
    },
  {
    type: "MRI",
    title: "МРТ",
    schema: MRIForm,
    isSchema: true,
    color: "#fa003c",
    isInResearch: true,
    files: ['dcm', 'stats']
  },
  {
    type: "EEG",
    title: "ЭЭГ",
    schema: EEGForm,
    isSchema: true,
    color: "#fa9305",
    isInResearch: true,
    files: ['eeg']

  },
    {
      type: "description",
      title: "Описание",
      schema: descriptionForm,
      isSchema: true,
      color: "#faf2ab",
      isInResearch: true
    },
  {
    type: "blood",
    title: "Биохимия",
    schema: biochemistryForm,
    isSchema: true,
    color: "#faca7c",
    isInResearch: true
  },
  {
    type: "hormonal",
    title: "Гормоны",
    schema: hormonesForm ,
    isSchema: true,
    color: "#faf952",
    isInResearch: true
  },
  {
    type: "citogenetical",
    title: "Цитогенетика",
    schema: cytogeneticsForm ,
    isSchema: true,
    color: "#b6fadb",
    isInResearch: true
  },
  {
    type: "lymphocites",
    title: "Лимфоциты",
    schema: lymphocytesForm ,
    isSchema: true,
    color: "#c9ebfa",
    isInResearch: true
  }
]

export { schemas };
