import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  TemplateRef,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import {Patient, Anamnez, anamnesisScheme, Analysis} from '../../models';
import { PatientsComponent } from '../../patients.component';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import {isNullOrUndefined} from "util";
import { schemas } from 'src/app/patients/view-patient/patient-analysis/forms';
import {Form} from "../patient-analysis/models/form.model";
import {dateToString} from "angular6-json-schema-form";
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import {rBootstrap4FrameworkComponent} from "../../../shared/components/russianBootstrap4Form/rbf.component";
import {FormBuilder, FormGroup} from "@angular/forms";


@Component({
  selector: 'app-patient-info',
  templateUrl: './patient-info.component.html',
  styleUrls: ['./patient-info.component.scss', '../patient-section.scss']
})
export class PatientInfoComponent {
  _patient: Patient;
  @Output() reloader = new EventEmitter<string>();
  collapse: boolean = false;
  EditFIO: boolean = false;
  anamnezIsExpanded = false;
  update_patient: Patient = new Patient();
  schemas: Form[] = schemas;
  researches: Form[] = [];
  resStatus = {}
  anamnesisFields = []
  anamnesisScheme = anamnesisScheme;
  // labels: { label: string, value: string }[] = []
  constructor(private patientsService: PatientsService, private toastr: ToastrService, private modalService: BsModalService, private renderer: Renderer2, private fb: FormBuilder) { }

  modalRef: BsModalRef;

  framework = {
    framework: rBootstrap4FrameworkComponent
  }

  @ViewChild('AnamnezisPanel') AnamnezisPanel: ElementRef;
  @ViewChild('AnamnezisDiv') AnamnezisDiv: ElementRef;



  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  get patient(): Patient {
    return this._patient;
  }

  patGroup = "Неизвестно";
  patGroupColor = ""
  groups = ["Неизвестно", "БА", "СД", "Депрессия", "Контроль", "Б. Паркинсона", "Деменция"]
  groupsKeys = Object.keys(this.groups);
  groupForm: FormGroup;
  colors = {0:"black", 1:"#86192e", 2:"#bd5f0f", 3:"#6c3664", 4:"#176107",
    5:"#798c00", 6:"#005852"}
  rows = [];
  @Input('patient')
  set patient(value: Patient) {
    this._patient = value;

    if (value.group) {
      this.patGroup = this.groups[value.group];
      this.patGroupColor = this.colors[value.group];
    }
    this.anamnesisFields = Object.keys(this.anamnesisScheme.schema.properties.data.properties);
    if (value.anamnez && value.anamnez.data) {
      let keys = Object.keys(value.anamnez.data);
      this.rows = [];
      for (let i = 0; i < keys.length + 6; i += 7) {

        let row = [];
        for (let k = i; k < i + 6 ; k += 1) {
          let rec = {};
          if (k < keys.length) {
            let key = keys[k];
            console.log(key);
            rec["title"] = this.anamnesisScheme["schema"]["properties"]["data"]["properties"][key]["title"];
            rec["val"] = value.anamnez.data[key]
          }
          row.push(rec);
        }
        this.rows.push(row);
      }
    }

    //an.forEach((x) => {this.anamnesis.push(anamnesisScheme["schema"]["properties"]["data"]["properties"][x]["title"])});
    this.researches = [];
    this.schemas.forEach((schema) => {
      if (schema.isInResearch)
      {
        let isDone = false;
        if (!isNullOrUndefined(value.analyzes)) {
          value.analyzes.forEach((analysis) => {
            if (analysis.contentType == schema.type)
              isDone = true
          })
        }
        this.researches.push(schema);
        this.resStatus[schema.type] = isDone
      }
    })
  }

  ngAfterViewInit() {
    // this.initPatientScope();
  }

  formatDate(date) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  FIOEdit() {
    if (this.patient['personal']) {
      this.update_patient = JSON.parse(JSON.stringify(this.patient));
      //this.update_patient.personal.birthday = this.formatDate(this.update_patient.personal.birthday);
      this.EditFIO = true;
    }
  }



  FIOInputSave() {
    this.patientsService.updatePatient(this.update_patient).subscribe(
      _ => {
        //this.patient = JSON.parse(JSON.stringify(this.update_patient));;
        this.update_patient = new Patient();
        this.toastr.success('Сохранено', 'Данные сохранены');
        this.reloader.emit(this.patient._id)
      },
      error => {
        this.toastr.error('Ошибка', error.error.message.toString());
        console.log(error);
      });
    this.EditFIO = false;

  }

  FIOInputCancel() {
    this.EditFIO = false;
    this.update_patient = new Patient();
    console.log(this.patient)
  }

  get labels(): { label: string, value: string }[] {
    let labels: { label: string, value: string }[] = []
    //labels.push({ label: 'Хеш код:', value: this.patient.hash });
    //labels.push({ label: 'ID:', value: this.patient._id });
    let d = dateToString(this.patient.creationDate, 'dd.MM.yyyy HH:mm');
    labels.push({ label: 'Дата создания в БД:', value: this.patient.creationDate ? d : undefined });
    return labels;
  }

  onsubmit(anamnez: Anamnez) {
    anamnez.creationDate = new Date();
      this.UploadAnamnez(anamnez).subscribe(
        _ => {
          this.toastr.success('Сохранено', 'Данные сохранены');
          this.modalRef.hide()
          this.reloader.emit(this.patient._id);
        },
        error => {
          this.toastr.error('Ошибка', error.error.message.toString());
          console.log(error);
        });
  }


  UploadAnamnez(an: Anamnez) {
    this.patient.anamnez = an;
    return this.patientsService.updatePatient(this.patient)
    // console.log(this.AnalysisInput);
  }

  get jsonSchemaForm(): object {
    return this.anamnesisScheme;
  }


  expandAnamnez() {
    if (this.anamnezIsExpanded) {
      this.renderer.setStyle(this.AnamnezisPanel.nativeElement, "height", "150px");
      this.renderer.setStyle(this.AnamnezisDiv.nativeElement, "height", "90px");
      this.renderer.setStyle(this.AnamnezisPanel.nativeElement, "width", "70%");

    }
    else {
      this.renderer.setStyle(this.AnamnezisPanel.nativeElement, "height", "500px");
      this.renderer.setStyle(this.AnamnezisDiv.nativeElement, "height", "440px");
      this.renderer.setStyle(this.AnamnezisPanel.nativeElement, "width", "70%");
    }

    this.anamnezIsExpanded = !this.anamnezIsExpanded;
  }
}
