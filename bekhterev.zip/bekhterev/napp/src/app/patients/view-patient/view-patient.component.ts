import {Component, OnInit, ViewChild, AfterViewInit, AfterViewChecked} from '@angular/core';
import { Patient, Analysis } from '../models';
import { PatientsService } from '../patients.service';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { saveAs } from 'file-saver';
import {TabDirective, TabsetComponent} from "ngx-bootstrap";
import { NavClass } from '../../nav/models/index';

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.scss', './patient-section.scss']
})
export class ViewPatientComponent implements OnInit, AfterViewChecked {

  constructor(private patientsService: PatientsService, private activatedRoute: ActivatedRoute, private toastr: ToastrService) {
  }
  @ViewChild('Tabs') staticTabs: TabsetComponent;
  navlist: NavClass[] = [];

  patient: Patient = new Patient();
  pid: string = "";
  aid: string = "";
  ableToAddRes = false;
  checked = 0;
  AnalysysInputVisible: boolean = false;

  get analysis() {
    return this.isFullView ? new Analysis() : this.getAnalysisById(this.aid);
  }

  onSelect(data: TabDirective): void {
    this.ableToAddRes = false;
    this.staticTabs.tabs[this.staticTabs.tabs.length-2].active = true;
    if (this.patient.numOfVisits)
      this.patient.numOfVisits += 1;
    else this.patient.numOfVisits = 2;
    this.patientsService.updatePatient(this.patient).subscribe( (x) =>
      {this.toastr.success("Обследование добавлено");
        this.staticTabs.tabs[this.staticTabs.tabs.length-1].active = true;
        this.ableToAddRes = true;
      }
    )
  }

  getAnalysisById(id: string) {
    if (this.patient.analyzes)
      for (const analysis of this.patient.analyzes) {
        if (analysis._id === id)
          return analysis;
      }
    return new Analysis();
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params: any) => {
      this.navlist = [{
        clickable: true,
        routerlink: "/patients",
        title: "Пациенты"
      }]
      this.initFields();
      console.log(params);
      if (params['pid']) {
        this.pid = params['pid'];
        this.getPatient(this.pid);
      }
      if (params['aid']) {
        this.aid = params['aid'];
      }
    });
  }


  get isFullView() {
    return this.aid == "all" || this.aid == "" || !this.aid;
  }

  initFields() {
    this.pid = "";
    this.aid = "";
    this.patient = new Patient();
  }

  counter(i: number) {
    return new Array(i);
  }

  getPatient(id: string) {
    console.log(id);
    this.patientsService.getPatient(id).subscribe(data => {
      if (this.checked == 0)
        this.checked = 1;
      this.patient = data;

      this.ableToAddRes = true;

      if (!this.isFullView) { if (this.navlist.length > 2) this.navlist.pop()}
      if (this.navlist.length > 1) this.navlist.pop();

      this.navlist.push({
        clickable: false,
        routerlink: "/patient/"+this.patient._id+"/all",
        title: (this.patient.personal ? (this.patient.personal.lastname + ' ' + this.patient.personal.firstname + ' ' + this.patient.personal.patronymic) : ("Пациент #" + this.patient._id))
      })
      if (!this.isFullView) {
        this.navlist[1].clickable = true;
        
      this.navlist.push({
        clickable: false,
        routerlink: "/patient/"+this.patient._id+"/all",
        title: "Анализ #" + this.aid
      })

      }
    });

  }

  ngAfterViewChecked(): void {
    if (this.checked == 1) {
      console.log(this.staticTabs.tabs, Object.keys(this.staticTabs.tabs));
      console.log(this.staticTabs.tabs);
      console.log(this.staticTabs.tabs[0]);
      console.log(this.staticTabs.tabs[1]);
      this.checked = 2;
      this.staticTabs.tabs[this.staticTabs.tabs.length - 2].active = true;

    }
  }


}
