import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientFileAnalysisComponent } from './patient-file-analysis.component';

describe('PatientRemoteFilesComponent', () => {
  let component: PatientFileAnalysisComponent;
  let fixture: ComponentFixture<PatientFileAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientFileAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientFileAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
