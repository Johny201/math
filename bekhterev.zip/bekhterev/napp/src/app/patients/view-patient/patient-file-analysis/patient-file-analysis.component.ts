import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Patient, PatientFile } from '../../models';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-patient-file-analysis',
  templateUrl: './patient-file-analysis.component.html',
  styleUrls: ['./patient-file-analysis.component.scss', '../patient-section.scss']
})
export class PatientFileAnalysisComponent implements OnInit {
  @Input() patient: Patient;
  @Output() reloader = new EventEmitter<string>();
  collapse: boolean = false;
  filesToUpload: File[] = [];
  fileSet = new Set();
  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }

  ngOnInit() {
  }

  uploadFiles() {
    const self = this;
    try {
      this.fileSet.forEach(file => {
        console.log(file)
        const formData: FormData = new FormData();
        formData.append('file', file, file.name);
        formData.append('description', file.description);
        formData.append('patientId', this.patient._id.toString());
        formData.append('_id', 'test');
        formData.append('type', 'test');
        this.patientsService.uploadFile(formData, this.patient._id)
          .subscribe(cfile => {
            cfile.creationDate = new Date(cfile.creationDate);
            this.patient.files ? this.patient.files.push(cfile) : this.patient.files = [cfile];
            self.fileSet.delete(file);
            self.toastr.success('Файл загружен', 'Файл ' + file.name + ' успешно загружен');
          }, (err) => {
            if (err.error !== undefined && err.error.message !== undefined) {
              this.toastr.error('Ошибка', err.error.message);
            }
          });

      });
    } catch (e) { self.toastr.error('Ошибка', e.value()); }
  }

  clearFilesToUpload() {
    this.fileSet.clear();
  }

  handleFileInput(files: FileList) {
    const self = this;
    this.filesToUpload = Array.from(files);
    this.filesToUpload.forEach(file => {
      self.fileSet.add(file);
    });
    this.filesToUpload = null;
  }
  toMbAndRound(filesize: number) {
    return Math.round(filesize / 1024 / 1024 * 100) / 100;
  }
  DeleteFile(cfile: PatientFile, i: number) {
    console.log(cfile);
    this.patientsService.deleteFile(this.patient._id, cfile._id)
      .subscribe(_ => {
        this.toastr.success('Файл удален', 'Файл ' + cfile.data.originalFilename + ' успешно удален');
        this.patient.files.splice(i, 1);

      }, error => { this.toastr.error(error.message); });
  }

  downloadFile(file, originalFilename) {
    this.patientsService.downloadFile(file, this.patient._id).subscribe(data => {
      const blob = new Blob([data]);
      saveAs(blob, originalFilename);
    }, (err) => {
      if (err.error !== undefined && err.error.message !== undefined) {
        this.toastr.error('Ошибка', err.error.message);
      }
      else {
        this.toastr.error("Внутренняя ошибка сервера")
      }
    });
  }


}
