import {Component, OnInit, Input, ViewChild, Output, EventEmitter, Directive, ElementRef} from '@angular/core';
import { Analysis } from 'src/app/patients/models';
import { schemas } from 'src/app/patients/view-patient/patient-analysis/forms';
import {Form} from "../../../patient-analysis/models/form.model";
import {Subject} from "rxjs";
import {DataTableDirective} from "angular-datatables";
import {isNullOrUndefined} from "util";
import {PatientsService} from "../../../../patients.service";
import {ToastrService} from "ngx-toastr";

@Component({
  selector: 'app-group-value',
  templateUrl: './group-value.component.html',
  styleUrls: ['./group-value.component.scss']
})
export class GroupValueComponent implements OnInit {
  _analysis: Analysis
  _schemaProperties = []
  _schemaPropertyTitles = {}
  schemas: Form[] = schemas;
  dtOptions: DataTables.Settings = {destroy: true, lengthChange: false, paging: false, searching: false, ordering:false, info:false};
  dtTrigger: Subject<any> = new Subject();
  editing = {}
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  @Output() reloader = new EventEmitter<string>();

  updateValue(event, cell) {
    console.log('inline editing rowIndex', cell);
    this.editing[cell] = false;
    if (!this._analysis.data) this._analysis.data = {};
    this._analysis.data[cell] = event.target.value;
    console.log('UPDATED!', event.target.value);

    this.UpdateAnalysis(this._analysis).subscribe((x) => {
      console.log('Emitting ' + x);
       this.reloader.emit(this.analysis._id);}, (e) => {
      this.toastr.error('Ошибка', e.error.message.toString());

      console.log(e)})
  }

  get analysis(): Analysis {
    return this._analysis;

  }
  @Input('analysis') set analysis(value: Analysis) {
    this._analysis = value
    let schema = this.schemas.find((x) => {return x.type == value.contentType})
    this._schemaProperties = Object.keys(schema.schema["schema"]["properties"]["data"]["properties"])
    this._schemaProperties.forEach((x) => {this._schemaPropertyTitles[x] = schema.schema["schema"]["properties"]["data"]["properties"][x]["title"] });

    this.dtTrigger.next();
  }
  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }

  ngOnInit() {

  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  uploadAnalyzes(analyzes: Analysis[]) {
    let n = analyzes.length;
    let i = 0;
    for (const analysis of analyzes) {
      this.UpdateAnalysis(analysis).subscribe(
        _ => {
          i++;
          if (n > 1) {
            this.toastr.success('Сохранено', 'Данные сохранены. Осталось ' + (n - i));
            console.log(n - i, n - i === 0)
            if (n - i === 0) {
              this.reloader.emit(this.analysis._id);
            }

          }
          else {
            this.toastr.success('Сохранено', 'Данные сохранены');
            this.reloader.emit(this.analysis._id);
          }
        },
        error => {
          this.toastr.error('Ошибка', error.error.message.toString());
          console.log(error);
        });
    }
  }

  UpdateAnalysis(analysis: Analysis) {
    return this.patientsService.updateAnalysis(analysis);
    // console.log(this.AnalysisInput);
  }


}

@Directive({
  selector: '[myAutofocus]'
})
export class AutofocusDirective implements OnInit {

  constructor(private elementRef: ElementRef) { };

  ngOnInit(): void {
    this.elementRef.nativeElement.focus();
  }

  ngAfterViewInit() {
    this.elementRef.nativeElement.focus();
  }

}
