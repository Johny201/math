import { Component, OnInit, Input } from '@angular/core';
import { Analysis } from 'src/app/patients/models';

@Component({
  selector: 'app-table-value',
  templateUrl: './table-value.component.html',
  styleUrls: ['./table-value.component.scss']
})
export class TableValueComponent implements OnInit {

  @Input() analysis: Analysis;
  constructor() { }

  ngOnInit() {
  }

}
