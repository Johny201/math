import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Analysis, Patient } from '../../models';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import { AnalysisViewTypemap } from './constants';
import {AnalysisTypemap} from "../patient-analysis/constants";

@Component({
  selector: 'app-view-analysis',
  templateUrl: './view-analysis.component.html',
  styleUrls: ['./view-analysis.component.scss', '../patient-section.scss']
})
export class ViewAnalysisComponent implements OnInit {

  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }
  @Input() analysis: Analysis;
  @Input() patient: Patient;
  @Input() par: any;
  collapse: boolean = false;
  @Output() reloader = new EventEmitter<string>();

  updatePatient(id: string) {
    this.par.updatePatient(this.patient._id)
  }

  ngOnInit() {
  }

  AnalysisTypeToTitle(t: string): string {
    return t in AnalysisTypemap ? AnalysisTypemap[t] : t;
  }

  get t() {
    return this.analysis ? this.analysis.contentType in AnalysisViewTypemap ?  AnalysisViewTypemap[this.analysis.contentType] : "unknown" : "unknown"
  }

}
