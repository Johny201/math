import { Component, OnInit, Input } from '@angular/core';
import { Analysis } from 'src/app/patients/models';

@Component({
  selector: 'app-single-value',
  templateUrl: './single-value.component.html',
  styleUrls: ['./single-value.component.scss']
})
export class SingleValueComponent implements OnInit {

  @Input() analysis: Analysis;
  constructor() { }

  ngOnInit() {
  }

}
