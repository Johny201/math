// import { schemas } from "../forms"
let AnalysisViewTypemap: { [id: string]: string; } = {
    "textData": "singleValue",
    "hormonal": "groupValue",
    "MRI": "groupValue",
    "EEG": "groupValue",
    "psychoData": "groupValue",
    "description": "groupValue",
    "anamnesis": "groupValue",
    "blood": "groupValue",
    "citogenetical": "groupValue",
    "lymphocites":"groupValue",
    "XLSXData": "table"
}

// for (const schema of schemas) {
//     if (!(schema.type in AnalysisTypemap)) {
//         AnalysisTypemap[schema.type] = schema.title;
//     }
// }

export { AnalysisViewTypemap }
