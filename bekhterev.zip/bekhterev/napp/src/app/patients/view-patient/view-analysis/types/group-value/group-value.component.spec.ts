import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupValueComponent } from './group-value.component';

describe('GroupValueComponent', () => {
  let component: GroupValueComponent;
  let fixture: ComponentFixture<GroupValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
