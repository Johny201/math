import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Patient } from '../../models';
import { PatientsComponent } from '../../patients.component';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import {isNullOrUndefined} from "util";
import { schemas } from 'src/app/patients/view-patient/patient-analysis/forms';
import {Form} from "../patient-analysis/models/form.model";

@Component({
  selector: 'app-research-status',
  templateUrl: './research-status.component.html',
  styleUrls: ['./research-status.component.scss', '../patient-section.scss']
})
export class ResearchStatusComponent {
  _patient: Patient;
  schemas: Form[] = schemas;
  researches: Form[] = [];
  resStatus = {};
  // labels: { label: string, value: string }[] = []
  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }

  get patient(): Patient {
    return this._patient;
  }
  @Input() numOfVizit = [1];

  @Input('patient')
  set patient(value: Patient) {
    this._patient = value;
    this.researches = [];
    this.numOfVizit.forEach((num) => {
      this.resStatus[num] = {}
    })
    this.schemas.forEach((schema) => {
      if (schema.isInResearch)
      {
        this.researches.push(schema);
        this.numOfVizit.forEach((num) => {
          let isDone = 0;
          if (!isNullOrUndefined(value.analyzes)) {
            value.analyzes.forEach((analysis) => {
              if ((analysis.contentType == schema.type) && (analysis.numOfVisit == num + 1)) {
                let full = true;
                for (let key of Object.keys(schema.schema["schema"]["properties"]["data"]["properties"]))
                {
                  if (!analysis.data[key])
                  {
                    full = false;
                    break;
                  }
                }
                if (full)
                  isDone = 2
                else isDone = 1
              }
            })
          }

          this.resStatus[num][schema.type] = isDone
        })
      }
    });
  }

}
