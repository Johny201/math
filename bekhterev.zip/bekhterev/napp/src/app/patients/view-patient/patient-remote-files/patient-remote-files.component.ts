import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Patient, RemoteFile } from '../../models';
import { PatientsService } from '../../patients.service';
import { ToastrService } from 'ngx-toastr';
import { saveAs } from 'file-saver';
import { Analysis } from '../../models';
import { schemas } from 'src/app/patients/view-patient/patient-analysis/forms';
import {Form} from "../patient-analysis/models/form.model";

@Component({
  selector: 'app-patient-remote-files',
  templateUrl: './patient-remote-files.component.html',
  styleUrls: ['./patient-remote-files.component.scss', '../patient-section.scss']
})
export class PatientRemoteFilesComponent implements OnInit {
  @Input() patient: Patient;
  _analysis: Analysis;
  files: RemoteFile[]
  schemas: Form[] = schemas;
  hasFiles = false
  fileFormats = ""

  get analysis(): Analysis {
    return this._analysis;
  }
  @Input('analysis')
  set analysis(value: Analysis) {
    this._analysis = value
    let schema = this.schemas.find((x) => {return x.type == value.contentType})
    if (schema.files) {
      this.hasFiles = true
      let ftypes = schema.files
      console.log(ftypes)
      ftypes.forEach((ftype)=> {this.fileFormats += '.' + ftype +',' })
    }

    if (this.hasFiles) {
      this.patientsService.getListOfAnalysesFromSystem(value._id).subscribe((x) => {
        this.files = x
      })
    }
  }
  @Output() reloader = new EventEmitter<string>();
  collapse: boolean = false;
  filesToUpload: File[] = [];
  fileSet = new Set();
  constructor(private patientsService: PatientsService, private toastr: ToastrService) { }

  ngOnInit() {
  }

  uploadFiles() {
    const self = this;
    try {
      this.fileSet.forEach(file => {
        const formData: FormData = new FormData();
        formData.append('file', file, file.name);
        formData.append('description', file.description);
        console.log('2')
        console.log(this.patient, this.analysis)
        formData.append('patientId', this.patient._id.toString());
        formData.append('_id', this.analysis._id.toString());
        console.log('3')
        formData.append('type', this.analysis.contentType);
        this.patientsService.uploadToAnalysisSystem(formData, this.patient._id)
          .subscribe(cfile => {
            cfile.creationDate = new Date(cfile.creationDate);
            this.files ? this.files.push(cfile) : this.files = [cfile];
            self.fileSet.delete(file);
            self.toastr.success('Файл загружен', 'Файл ' + file.name + ' успешно загружен');
          }, (err) => {
            if (err.error !== undefined && err.error.message !== undefined) {
              this.toastr.error('Ошибка', err.error.message);
            }
          });

      });
    } catch (e) { self.toastr.error('Ошибка', e.value()); }
  }

  clearFilesToUpload() {
    this.fileSet.clear();
  }

  handleFileInput(files: FileList) {
    const self = this;
    this.filesToUpload = Array.from(files);
    this.filesToUpload.forEach(file => {
      self.fileSet.add(file);
    });
    this.filesToUpload = null;
  }

  toMbAndRound(filesize: number) {
    return Math.round(filesize / 1024 / 1024 * 100) / 100;
  }
  DeleteFile(cfile: RemoteFile, i: number) {
    this.patientsService.deleteRemoteFile(cfile.fileId)
      .subscribe(_ => {
        this.toastr.success('Файл удален', 'Файл ' + cfile.name + ' успешно удален');
        this.files.splice(i, 1);

      }, error => { this.toastr.error(error.message); });
  }

  downloadFile(fileId, name) {
    this.patientsService.downloadFileFromRemote(fileId).subscribe(data => {
      const blob = new Blob([data]);
      saveAs(blob, name);
    }, (err) => {
      if (err.error !== undefined && err.error.message !== undefined) {
        this.toastr.error('Ошибка', err.error.message);
      }
      else {
        this.toastr.error("Внутренняя ошибка сервера")
      }
    });
  }


}
