import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientRemoteFilesComponent } from './patient-remote-files.component';

describe('PatientRemoteFilesComponent', () => {
  let component: PatientRemoteFilesComponent;
  let fixture: ComponentFixture<PatientRemoteFilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientRemoteFilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientRemoteFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
