import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppConfig } from '../shared/config/app.config';
import {Patient, Analysis, AnalysisInfo, PatientFile, RemoteFile} from './models';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class PatientsService {
  constructor(private http: HttpClient) { }



  getPatients(): Observable<Patient[]> {
    return this.http.get<Patient[]>(AppConfig.endpoints['getPatients']);
  }

  getPatient(id: string): Observable<Patient> {
    return this.http.get<Patient>(AppConfig.endpoints['getPatient'], { params: { _id: id } });
  }

  deletePatient(id: string): Observable<Patient> {
    return this.http.delete<Patient>(AppConfig.endpoints['getPatient'], { params: { _id: id } });
  }

  updatePatient(patient: Patient): Observable<any> {
    return this.http.put(AppConfig.endpoints['getPatient'], patient);
  }

  createPatient(patient: Patient): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post(AppConfig.endpoints['getPatient'], patient, httpOptions);
  }

  uploadFile(formData: FormData, id: string): Observable<PatientFile> {
    return this.http.post<PatientFile>(AppConfig.endpoints['files'], formData, { params: { '_id': id } });
  }

  uploadToAnalysisSystem(formData: FormData, id: string): Observable<RemoteFile> {
    return this.http.post<RemoteFile>(AppConfig.endpoints['filesToAnalysisSystem'], formData, { params: { '_id': id } });
  }

  getListOfAnalysesFromSystem(id: string): Observable<RemoteFile[]> {
    return this.http.get<RemoteFile[]>(AppConfig.endpoints['filesListFromAnalysisSystem'], { params: { '_id': id } });
  }

  getListOfMRIFromSystem(id: string): Observable<RemoteFile[]> {
    return this.http.get<RemoteFile[]>(AppConfig.endpoints['MRIListFromAnalysisSystem'], { params: { '_id': id } });
  }

  getMRIUrls(id: string): Observable<string[]> {
    const urls: string[] = [];
    return this.getListOfMRIFromSystem(id).pipe(map((res) => {
      console.log(res);
      res.forEach((x) => {
      urls.push(AppConfig.endpoints['filesToAnalysisSystem'] + '?fileId=' + x.fileId);
    });
    return urls;
    })
    );
  }

  downloadFileFromRemote(fileId: string): Observable<Blob> {
    return this.http.get(AppConfig.endpoints['filesToAnalysisSystem'], {
      responseType: 'blob',
      params: { fileId: fileId}
    });
  }

  deleteRemoteFile(file_id: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        fileId: file_id,
      }
    };
    return this.http.delete(AppConfig.endpoints['filesToAnalysisSystem'], httpOptions);
  }

  downloadFile(file: string, id: string): Observable<Blob> {
    return this.http.get(AppConfig.endpoints['files'], {
      responseType: 'blob',
      params: { filename: file, _id: id }
    });
  }
  deleteFile(id: string, file_id: string): Observable<any> {
    console.log(id, file_id);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        _id: id,
        file: { _id: file_id }
      }
    };
    return this.http.delete(AppConfig.endpoints['fileObject'], httpOptions);
  }

  deleteAnalysis(id: string, analysis_id: string): Observable<any> {
    console.log(id, analysis_id);
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        _id: id,
        analysis: { _id: analysis_id }
      }
    };
    return this.http.delete(AppConfig.endpoints['analysisObject'], httpOptions);
  }

  uploadAnalysis(id: string, analysis: Analysis): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.post(AppConfig.endpoints['analysisObject'], {
      _id: id, analysis: analysis
    }, httpOptions);
  }

  updateAnalysis(analysis: Analysis): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    return this.http.put(AppConfig.endpoints['analysisObject'], {
      analysis: analysis
    }, httpOptions);
  }

  getAnalyzesInfo(): Observable<AnalysisInfo[]> {
    return this.http.get<AnalysisInfo[]>(AppConfig.endpoints['getAnalyzesInfo']);
  }

}
