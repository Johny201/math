import {Component, OnInit, TemplateRef, ViewChild} from '@angular/core';
import { PatientsService } from './patients.service';
import {Analysis, Anamnez, Patient, PersonalInfo} from './models';
import { ToastrService } from 'ngx-toastr';
import { NavClass } from '../nav/models';
import * as XLSX from 'xlsx';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { schemas } from './view-patient/patient-analysis/forms';
import {PatientInfoComponent} from "./view-patient/patient-info/patient-info.component";
type AOA = any[][];
import { anamnesisScheme } from './models';
import {Subject} from "rxjs";
import {DataTableDirective} from "angular-datatables";
import {isNullOrUndefined} from "util";
import {count} from "rxjs/operators";

@Component({
  selector: 'app-patients',
  templateUrl: './patients.component.html',
  styleUrls: ['./patients.component.scss']
})
export class PatientsComponent implements OnInit {
  dtOptions: DataTables.Settings = {destroy: true, lengthChange: true, paging: true, autoWidth: false, searching: true};
  dtTrigger: Subject<any> = new Subject();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  navlist: NavClass[] = [{
    clickable: false,
    routerlink: "/patients",
    title: "Пациенты"
  }]
  constructor(private patientsService: PatientsService, private toastr: ToastrService, private modalService: BsModalService) { }

  public patients: Patient[] = [];
  groups = {0:"Неизвестно", 1:"БА", 2:"СД", 3:"Депрессия", 4:"Контроль", 5:"Б. Паркинсона", 6:"Деменция"}
  colors = {0:"black", 1:"#86192e", 2:"#bd5f0f", 3:"#6c3664", 4:"#176107",
    5:"#798c00", 6:"#005852"}

  ngOnInit() {
    this.patientsService.getPatients().subscribe(data => {
      this.patients = data.sort((a,b) => {return a.number - b.number;});
      if (isNullOrUndefined(this.dtElement.dtInstance)) this.dtTrigger.next();

    }, e => {
      this.toastr.error("Ошибка получения списка пациентов");
    })
  }

  createArray(n: number)
  {
    return Array.apply(null, {length: n}).map(Number.call, Number);
  }

  deletePatient(_id: string, i: number) {
    this.patientsService.deletePatient(_id).subscribe(x => {this.patients.splice(i, 1)})
  }

  loadExcel() {

  }

  modalRef2: BsModalRef;

  onlyNewAnalyzes = true;
  openModal(template: TemplateRef<any>) {
    this.modalRef2 = this.modalService.show(template);
  }



  data = {};

  inputdata: {
    title: string,
    comment: string,
    delnum: number,
    type: string
  } = {
    title: "",
    comment: "",
    delnum: 0,
    type: "many"
  }


  inputfile(event: any) {
    this.data = {};
    const target: DataTransfer = <DataTransfer>(event.target);
    if (target.files.length !== 1) {
      this.toastr.error("Поддерживается импорт только по одному xlsx файлу");
      return;
    };
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = (XLSX.utils.sheet_to_json(ws));
      this.parseExcel();
    };
    reader.readAsBinaryString(target.files[0]);
  }
  newPatients: Patient[] = [];
  updatedPatients: Patient[] = [];
  parseExcel() {
    let patients = Object.keys(this.data);
    for (let patK of patients) {
      let needToUpd = false;
      let pat = this.data[patK];
      let fio = pat["ФИО"].split(' ');
      var exdate = pat["Дата рождения"]; // represents Jan 1, 1993
      var e0date = new Date(0); // epoch "zero" date
      var offset = e0date.getTimezoneOffset(); // tz offset in min

      // calculate Excel xxx days later, with local tz offset
      var jsdate = new Date(0, 0, exdate-1, 0, -offset, 0);

      let oldpat = this.patients.find((x) => {
        let bd = new Date(x.personal.birthday)
        return (x.personal.lastname == fio[0])  && (x.personal.firstname == fio[1])
      && ((x.personal.patronymic == fio[2]) ||  (!x.personal.patronymic && !fio[2])) && (bd.getFullYear() == jsdate.getFullYear()
          && bd.getMonth() == jsdate.getMonth() && bd.getDate() == jsdate.getDate()) });

      let newPat = new Patient();
      let analyzes = [];
      if (oldpat)
      {
        analyzes = oldpat.analyzes;
        oldpat.group = pat["КОД3 основной"];
      }
      else {
        newPat.personal = new PersonalInfo();
        newPat.personal.firstname = fio[1];
        newPat.personal.lastname = fio[0];
        newPat.personal.patronymic = fio[2];
        newPat.group = pat["КОД3 основной"];


        newPat.personal.birthday = jsdate;
        newPat.anamnez = new Anamnez();
        newPat.anamnez.data = {};
      }
      for (let sch of schemas) {
        let analysis = new Analysis();
        analysis.data = {};
        analysis.contentType = sch.type;
        let needToUpdAnalysis = false;

        let oldA: any;
        let have = false;
        let an = sch.schema["schema"]["properties"]["data"]["properties"]
        let keys = Object.keys(an)
        for (let key of keys) {
          if (pat[an[key].title]) {
            if (!needToUpdAnalysis && this.onlyNewAnalyzes && oldpat)
              if (oldpat.analyzes && oldpat.analyzes.some(x => Object.keys(x.data).some(y => y == key))) {
                needToUpdAnalysis = true;
                analysis = oldpat.analyzes.find(x => Object.keys(x.data).some(y => y == key));
                oldA = analysis
              }

            if (this.onlyNewAnalyzes && oldpat) {
              if (analysis.data[key] == pat[an[key].title])
                continue;
              else {
                console.log(key, analysis.data[key], pat[an[key].title])
                needToUpd = true;
              }
            }

            have = true;

            analysis.data[key] = pat[an[key].title];
            analysis.date = new Date(pat["Год обращения"], 0);

          }
        }
        if (have && (!oldpat || (!needToUpdAnalysis && Object.keys(analysis.data).length >=0))) analyzes.push(analysis)
        else if (needToUpdAnalysis)  oldpat.analyzes[oldpat.analyzes.indexOf(oldA)] = analysis;
      }

      let anamnesScheme = anamnesisScheme["schema"]["properties"]["data"]["properties"];
      for (let anKey of Object.keys(anamnesScheme))
      {
        if (pat[anamnesScheme[anKey]["title"]]) {
          if (oldpat)
          {
            if (anamnesScheme[anKey]["enum"]) {
              if (oldpat.anamnez.data[anKey] != anamnesScheme[anKey]["enum"][pat[anamnesScheme[anKey]["title"]] - 1]) {
                console.log(oldpat.number, anKey, oldpat.anamnez.data[anKey], anamnesScheme[anKey]["enum"][pat[anamnesScheme[anKey]["title"]] - 1])
                needToUpd = true;
              }
              oldpat.anamnez.data[anKey] = anamnesScheme[anKey]["enum"][pat[anamnesScheme[anKey]["title"]] - 1];
            }
            else {
              if (oldpat.anamnez.data[anKey] != pat[anamnesScheme[anKey]["title"]]) {
                console.log(oldpat.number, anKey, oldpat.anamnez.data[anKey], pat[anamnesScheme[anKey]["title"]])
                needToUpd = true;
              }
              oldpat.anamnez.data[anKey] = pat[anamnesScheme[anKey]["title"]];
            }
          }
          else {
            if (anamnesScheme[anKey]["enum"])
              newPat.anamnez.data[anKey] = anamnesScheme[anKey]["enum"][pat[anamnesScheme[anKey]["title"]] - 1];
            else newPat.anamnez.data[anKey] = pat[anamnesScheme[anKey]["title"]];
          }

        }
      }

      if (oldpat) {
        //oldpat.analyzes = analyzes;
        if (needToUpd)
          this.updatedPatients.push(oldpat);
      } else {
        newPat.analyzes = analyzes;
        this.newPatients.push(newPat);
      }
    }
    this.uploadLen = this.newPatients.length + this.updatedPatients.length;
  }

  uploadStarted = false;
  uploadedCount = 0;
  uploadLen = 1;
  async UploadAfterExcel()
  {
    this.uploadStarted = true;
    this.uploadedCount = 0;
    console.log("STARTED ");
    //let f = async () => {
      for (let pat of this.newPatients) {
        console.log("AWAIT")
        await (this.patientsService.createPatient(pat).toPromise())
        this.uploadedCount++;
        if (this.uploadedCount >= this.uploadLen) {
            this.modalRef2.hide();
            this.ngOnInit();
        }
      //}
     // f().then((x) => {})
    }


    for (let pat of this.updatedPatients)
    {
      console.log("AWAIT_UPD")
      await (this.patientsService.updatePatient(pat).toPromise())
        this.uploadedCount++;
        if (this.uploadedCount >= this.uploadLen) {
          this.modalRef2.hide();
          this.ngOnInit();
        }

    }


  }


}
