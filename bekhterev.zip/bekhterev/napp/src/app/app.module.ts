import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, Injector } from '@angular/core';

import { AppComponent } from './app.component';
import { PatientsComponent } from './patients/patients.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { HttpModule } from '@angular/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CreatePatientComponent } from './create-patient/create-patient.component';
import { ViewPatientComponent } from './patients/view-patient/view-patient.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppConfig } from './shared/config/app.config';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { CommonModule } from '@angular/common';
import { PatientInfoComponent } from './patients/view-patient/patient-info/patient-info.component';
import { PatientAnalysisComponent } from './patients/view-patient/patient-analysis/patient-analysis.component';
import { PatientFileAnalysisComponent } from './patients/view-patient/patient-file-analysis/patient-file-analysis.component';
import { PatientRemoteFilesComponent } from './patients/view-patient/patient-remote-files/patient-remote-files.component';
import { Bootstrap4FrameworkModule } from 'angular6-json-schema-form';
import { rBootstrap4FrameworkComponent } from './shared/components/russianBootstrap4Form/rbf.component';
import { ViewAnalysisComponent } from './patients/view-patient/view-analysis/view-analysis.component';
import { SingleValueComponent } from './patients/view-patient/view-analysis/types/single-value/single-value.component';
import {
  AutofocusDirective,
  GroupValueComponent
} from './patients/view-patient/view-analysis/types/group-value/group-value.component';
import { ResearchStatusComponent } from './patients/view-patient/research-status/research-status.component';
import { JwtInterceptor } from './shared/interceptors/jwt-interceptor';
import { XlsxInputComponent } from './patients/view-patient/patient-analysis/forms/xlsx-input/xlsx-input.component';
import { NavComponent } from './nav/nav.component';
import { TableValueComponent } from './patients/view-patient/view-analysis/types/table-value/table-value.component';
import { AnalyzesComponent } from './analyzes/analyzes.component';
import {BsModalService, ModalModule} from 'ngx-bootstrap/modal';
import { DataTablesModule } from 'angular-datatables';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { DwvModule } from '../dwv/dwv.module';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { DicomViewComponent } from './DICOM-view/dicom-view.component';
import { ForbiddenComponent } from './login-components/forbidden/forbidden.component';
import { UnauthorizedComponent } from './login-components/unauthorized/unauthorized.component';
import {PsychoTestWrapperComponent} from "./psycho-test-wrapper/psycho-test-wrapper.component";
import { AppRoutingModule } from './app-routing.module';
import {
  AuthModule,
  OidcSecurityService,
  OidcConfigService,
} from 'angular-auth-oidc-client';
import { AuthService } from './shared/services/auth.service';

import { ExpressTestResComponent } from './psyhological-test-component/test-patient/test-res/express-test-res/express-test-res.component';
import { BdiTestResComponent } from './psyhological-test-component/test-patient/test-res/bdi-test-res/bdi-test-res.component';
import { WmsTestResComponent } from './psyhological-test-component/test-patient/test-res/wms-test-res/wms-test-res.component';
import { IttTestResComponent } from './psyhological-test-component/test-patient/test-res/itt-test-res/itt-test-res.component';
import { Block1TestResComponent } from './psyhological-test-component/test-patient/test-res/block1-test-res/block1-test-res.component';
import { FormExpressTestComponent } from './psyhological-test-component/form/form-express-test/form-express-test.component';
import { FormBdiTestComponent } from './psyhological-test-component/form/form-bdi-test/form-bdi-test.component';
import { FormWmsTestComponent } from './psyhological-test-component/form/form-wms-test/form-wms-test.component';
import { FormIttTestComponent } from './psyhological-test-component/form/form-itt-test/form-itt-test.component';
import { StrypTestResComponent } from './psyhological-test-component/test-patient/test-res/stryp-test-res/stryp-test-res.component';
import { FormStrypTestComponent } from './psyhological-test-component/form/form-stryp-test/form-stryp-test.component';
import { AdkTestResComponent } from './psyhological-test-component/test-patient/test-res/adk-test-res/adk-test-res.component';
import { FormAdkTestComponent } from './psyhological-test-component/form/form-adk-test/form-adk-test.component';
import { CommonService } from './psyhological-test-component/common.service'
import { PsyhologicalTestComponentComponent } from './psyhological-test-component/psyhological-test-component.component';
import { InfoPatientComponentComponent } from './psyhological-test-component/info-patient-component/info-patient-component.component';
import { TestPatientComponent } from './psyhological-test-component/test-patient/test-patient.component';
import {ComponentLoaderFactory, PositioningService} from "ngx-bootstrap";
import {PsyhoTestService} from "./psyhological-test-component/psyho-test.service";
import {PatientsService} from "./patients/patients.service";


@NgModule({
  declarations: [
    AppComponent,
    PatientsComponent,
    HomeComponent,
    ProfileComponent,
    CreatePatientComponent,
    ViewPatientComponent,
    PatientInfoComponent,
    PatientAnalysisComponent,
    PatientFileAnalysisComponent,
    rBootstrap4FrameworkComponent,
    ViewAnalysisComponent,
    SingleValueComponent,
    GroupValueComponent,
    XlsxInputComponent,
    NavComponent,
    TableValueComponent,
    AnalyzesComponent,
    ResearchStatusComponent,
    AutofocusDirective,
    PatientRemoteFilesComponent,
    DicomViewComponent,
    ForbiddenComponent,
    UnauthorizedComponent,

    PsyhologicalTestComponentComponent,
    InfoPatientComponentComponent,
    TestPatientComponent,
    ExpressTestResComponent,
    BdiTestResComponent,
    WmsTestResComponent,
    IttTestResComponent,
    Block1TestResComponent,
    StrypTestResComponent,
    AdkTestResComponent,
    FormExpressTestComponent,
    FormBdiTestComponent,
    FormWmsTestComponent,
    FormIttTestComponent,
    FormStrypTestComponent,
    FormAdkTestComponent,
    PsychoTestWrapperComponent,

  ],
  entryComponents: [
    rBootstrap4FrameworkComponent,
    ViewAnalysisComponent
  ],
  imports: [
    NgxUiLoaderModule,
    Bootstrap4FrameworkModule,
    CommonModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    FormsModule,
    BrowserModule,
    HttpClientModule,
    DataTablesModule.forRoot(),
    HttpModule,
    AppRoutingModule,
    ModalModule.forRoot(),
    ProgressbarModule.forRoot(),
    DwvModule,
    TabsModule.forRoot(),
    AuthModule.forRoot(),
    ReactiveFormsModule,


  ],
  providers: [
    AppConfig,
    OidcSecurityService,
    OidcConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: AuthService.LoadConfig,
      deps: [OidcConfigService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true
    },CommonService, BsModalService, ComponentLoaderFactory, PositioningService],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(private authService: AuthService) {
    this.authService.Configurate();
  }
}
