import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PsyhologicalTestComponentComponent } from './psyhological-test-component.component';

describe('PsyhologicalTestComponentComponent', () => {
  let component: PsyhologicalTestComponentComponent;
  let fixture: ComponentFixture<PsyhologicalTestComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PsyhologicalTestComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PsyhologicalTestComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
