import { TestBed } from '@angular/core/testing';

import { PsyhoTestService } from './psyho-test.service';

describe('PsyhoTestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PsyhoTestService = TestBed.get(PsyhoTestService);
    expect(service).toBeTruthy();
  });
});
