import {EventEmitter, Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Express } from './models/test/express';
import { BDI } from './models/test/bdi';
import { WMS } from './models/test/wms';
import { ITT } from './models/test/itt';
import { Stryp } from './models/test/stryp';
import { ADK } from './models/test/adk';
import {Patient} from "../patients/models";
import {PatientsService} from "../patients/patients.service";


@Injectable({
  providedIn: 'root',
})
export class PsyhoTestService {

  constructor(private patientsService: PatientsService) {
    console.log('CREATED SERVICE')
  }
  patient: Patient = new Patient();
  updateEmitter = new EventEmitter<string>();

  setLocalPat(pat: Patient)
  {
    this.patient = pat;
  }

  getLocalPat()
  {
    return this.patient;
  }

  updatePatient(pat: Patient)
  {
    this.patientsService.updatePatient(pat).subscribe(x => {this.updateEmitter.emit('upd')})
  }

}
