import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { BDI } from '../../../models/test/bdi';
import { Express } from '../../../models/test/express';

@Component({
  selector: 'app-block1-test-res',
  templateUrl: './block1-test-res.component.html',
  styleUrls: ['./block1-test-res.component.css', './../../../psyhological-test-component.component.css']
})
export class Block1TestResComponent implements OnInit {

  @Input() id: Number
  @Input() bdi: BDI
  @Input() express: Express
  @Output() reloader = new EventEmitter<string>();
  @Output() expressChanged = new EventEmitter<Express>()
  @Output() bdiChanged = new EventEmitter<BDI>()

  constructor() { }

  ngOnInit() {
    
  }

  expressChangedInChild(newExpress: Express)
  {
    this.expressChanged.emit(newExpress);
  }

  bdiChangedInChild(newBDI: BDI)
  {
    this.bdiChanged.emit(newBDI);
  }

}
