import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { Stryp } from '../../../models/test/stryp';
import { isUndefined } from 'util';

@Component({
  selector: 'app-stryp-test-res',
  templateUrl: './stryp-test-res.component.html',
  styleUrls: ['./stryp-test-res.component.css', './../../../psyhological-test-component.component.css']
})
export class StrypTestResComponent implements OnInit {
  @Output() reloader = new EventEmitter<string>();
  _stryp: Stryp;
  @Input('stryp')
  set stryp(value: Stryp) {
    this._stryp = value;

    if (!this.stryp.strypTest) {
      this.stryp.strypTest = new Array(6)
      for (let i = 0; i < 6; i++) {
        this.stryp.strypTest[i] = ''
      }
      this.presence = false
    } else {
      if (this.stryp.strypRes.length == 0) {
        this.stryp.strypTest = new Array(6)
        for (let i = 0; i < 6; i++) {
          this.stryp.strypTest[i] = ''
        }
        this.presence = false
      } else {
        this.presence = true
      }
    }
  }

  get stryp(): Stryp {
    return this._stryp;
  }
  @Input() public id: Number

  public presence : Boolean

  strypTest: Array<String>
  strypRes: Array<String>

  constructor() {
    this.getStryp()
  }

  ngOnInit() {
  }

  presenceChanged(presence: any) {
    this.presence = presence
    this.reloader.emit('upd');
  }

  getStryp() {
    this.strypRes = new Array(
      "Коэффициент интерференции",
      "Коэффициент вербальности",
    )

    this.strypTest = new Array(
      "Карта 1",
      "Карта 2",
      "Карта 3"
    )
  }

}
