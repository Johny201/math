import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpressTestResComponent } from './express-test-res.component';

describe('ExpressTestResComponent', () => {
  let component: ExpressTestResComponent;
  let fixture: ComponentFixture<ExpressTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpressTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpressTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
