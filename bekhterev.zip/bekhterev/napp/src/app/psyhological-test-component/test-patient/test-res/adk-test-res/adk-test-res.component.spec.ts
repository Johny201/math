import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdkTestResComponent } from './adk-test-res.component';

describe('AdkTestResComponent', () => {
  let component: AdkTestResComponent;
  let fixture: ComponentFixture<AdkTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdkTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdkTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
