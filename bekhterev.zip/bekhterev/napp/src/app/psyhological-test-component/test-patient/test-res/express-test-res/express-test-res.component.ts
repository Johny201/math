import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { Express } from '../../../models/test/express';
import { isUndefined } from 'util';
import { ExpressRes } from '../../../models/test/express/express-res';

@Component({
  selector: 'app-express-test-res',
  templateUrl: './express-test-res.component.html',
  styleUrls: ['./express-test-res.component.css', './../../../psyhological-test-component.component.css']
})
export class ExpressTestResComponent implements OnInit {
  @Output() reloader = new EventEmitter<string>();
  @Output() expressChanged = new EventEmitter<Express>()
  _express: Express;
  @Input('express')
  set express(value: Express) {
    this._express = value;
    this.getExpressRes();
    if (this.express.expressRes)
    this.changeColor()
  }

  get express(): Express {
    return this._express;
  }
  @Input() public id: Number
  
  public presence : Boolean
  expressTestRes : Array<String>
  style: Array<String>
  
  constructor() { 
  }

  ngOnInit() {
    if (!this.style) this.style = ["", "", ""];

  }

  presenceChanged(presence: any) {
    this.presence = presence
    this.changeColor()
    this.reloader.emit('upd');
  }

  expressChangedInChild(newExpress: Express)
  {
    this.expressChanged.emit(newExpress)
  }

  getExpressRes() {
    if (!this.express.expressRes) {
      this.express.expressRes = new ExpressRes()
      this.presence = false
    }
    this.expressTestRes = new Array(
      "Тест 'Рисование часов'",
      "Батарея лобной дисфункции",
      "MMSE"
    )
    
  }

  changeColor() {
    if (!this.style) this.style = ["", "", ""];
    if (this.express.expressRes.resMMSE != '') {
      this.presence = true
      var k = Number(this.express.expressRes.resMMSE)
      switch(true){
        case (k < 11):
           this.style[2] = 'violet'
           break;
        case (k < 20):
           this.style[2] = 'red'
           break;
        case (k < 24):
           this.style[2] = 'orange'
           break;
        case (k < 28):
           this.style[2] = 'yellow'
           break;
        default:
           this.style[2] = 'green'
      }
    }
    if (this.express.expressRes.resFAB != '') {
      var k = Number (this.express.expressRes.resFAB)
      switch(true){
        case (k < 12):
           this.style[1] = 'red'
           break;
        case (k < 16):
           this.style[1] = 'yellow'
           break;
        default:
           this.style[1] = 'green'
      }
    }
  }

}
