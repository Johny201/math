import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { ITT } from '../../../models/test/itt';
import { isUndefined } from 'util';
import { IttRes } from '../../../models/test/itt/itt-res';
import {Patient} from "../../../../patients/models";

@Component({
  selector: 'app-itt-test-res',
  templateUrl: './itt-test-res.component.html',
  styleUrls: ['./itt-test-res.component.css', './../../../psyhological-test-component.component.css']
})
export class IttTestResComponent implements OnInit {
  @Output() reloader = new EventEmitter<string>();
  _itt: ITT;
  @Input('itt')
  set itt(value: ITT) {
    this._itt = value;
    if (!this.itt.ittRes) {
      this.itt.ittRes = new IttRes()
      this.presence = false
    } else {
      if (this.itt.ittRes.sittRes.length == 0) {
        this.presence = false
        this.changeColor()
      } else {
        this.presence = true
        this.changeColor()
      }
    }
  }

  get itt(): ITT {
    return this._itt;
  }
  @Input() public id: Number

  public presence : Boolean
  scale: Array<String>
  style: Array<String>

  constructor() {
    this.scale = new Array ('Общий показатель', 'Эмоциональный дискомфорт', 'Астения', 'Страхи', 'Оценка перспективы', 'Сензетивность')
    this.style = new Array(12)
  }
  

  ngOnInit() {
  }

  presenceChanged(presence: any) {
    this.presence = presence
    this.changeColor()
    this.reloader.emit('upd');
  }

  changeColor() {

    if (this.itt.ittRes.sittRes[0] != '') {
      for (let i = 0; i < 6; i++) {
        var k = Number(this.itt.ittRes.sittRes[i+6])
        switch(true) {
          case (k > 6): 
            this.style[i] = 'red'
            break;
          case (k > 3):
            this.style[i] = 'green'
            break;
          default: 
            this.style[i] = 'blue'
        }
      }
      for (let i = 0; i < 6; i++) {
        var k = Number(this.itt.ittRes.pittRes[i+6])
        switch(true) {
          case (k > 6): 
            this.style[i+6] = 'red'
            break;
          case (k > 3):
            this.style[i+6] = 'green'
            break;
          default: 
            this.style[i+6] = 'blue'
        }
      }
    }
  }
}
