import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { BDI } from '../../../models/test/bdi';
import { isUndefined } from 'util';
import {Express} from "../../../models/test/express";

@Component({
  selector: 'app-bdi-test-res',
  templateUrl: './bdi-test-res.component.html',
  styleUrls: ['./bdi-test-res.component.css', './../../../psyhological-test-component.component.css']
})
export class BdiTestResComponent implements OnInit {

  @Output() reloader = new EventEmitter<string>();
  @Input() id: Number
  _bdi: BDI;
  @Input('bdi')
  set bdi(value: BDI) {
    this._bdi = value;
    if (!this.bdi.bdiRes) {
      this.bdi.bdiRes = ''
      this.presence = false
    } else {
      this.presence = true
      this.changeColor()
    }
  }

  get bdi(): BDI {
    return this._bdi;
  }

  presence : Boolean
  style: String
  res = "Уровень депрессии Бека"
  
  constructor() { 
  }

  ngOnInit() {
  }

  @Output() bdiChanged = new EventEmitter<BDI>()
  bdiChangedInChild(newBDI: BDI)
  {
    this.bdiChanged.emit(newBDI)
  }

  presenceChanged(presence: any) {
    this.presence = presence
    this.changeColor()
    this.reloader.emit('upd');
  }

  changeColor() {
    if (this.bdi.bdiRes != '') {
      var k = Number (this.bdi.bdiRes)
      switch(true){
        case (k > 29):
           this.style = 'violet'
           break;
        case (k > 19):
           this.style = 'red'
           break;
        case (k > 15):
           this.style = 'orange'
           break;
        case (k > 9):
           this.style = 'yellow'
           break;
        default:
           this.style = 'green'
      }
    }
  }

}
