import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Block1TestResComponent } from './block1-test-res.component';

describe('Block1TestResComponent', () => {
  let component: Block1TestResComponent;
  let fixture: ComponentFixture<Block1TestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Block1TestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Block1TestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
