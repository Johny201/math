import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BdiTestResComponent } from './bdi-test-res.component';

describe('BdiTestResComponent', () => {
  let component: BdiTestResComponent;
  let fixture: ComponentFixture<BdiTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BdiTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BdiTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
