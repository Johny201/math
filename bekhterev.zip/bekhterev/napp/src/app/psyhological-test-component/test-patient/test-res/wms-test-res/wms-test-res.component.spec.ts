import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WmsTestResComponent } from './wms-test-res.component';

describe('WmsTestResComponent', () => {
  let component: WmsTestResComponent;
  let fixture: ComponentFixture<WmsTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WmsTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WmsTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
