import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IttTestResComponent } from './itt-test-res.component';

describe('IttTestResComponent', () => {
  let component: IttTestResComponent;
  let fixture: ComponentFixture<IttTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IttTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IttTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
