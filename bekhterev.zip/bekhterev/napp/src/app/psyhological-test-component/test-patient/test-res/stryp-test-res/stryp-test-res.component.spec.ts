import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StrypTestResComponent } from './stryp-test-res.component';

describe('StrypTestResComponent', () => {
  let component: StrypTestResComponent;
  let fixture: ComponentFixture<StrypTestResComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StrypTestResComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StrypTestResComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
