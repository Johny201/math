import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { isUndefined } from 'util';
import { WmsRes } from '../../../models/test/wms-res';
import { WMS } from '../../../models/test/wms';
import {Patient} from "../../../../patients/models";
import {PsyhoTest} from "../../../models/psyho-test";
import {ADK} from "../../../models/test/adk";
import {BDI} from "../../../models/test/bdi";
import {Express} from "../../../models/test/express";
import {ITT} from "../../../models/test/itt";
import {Stryp} from "../../../models/test/stryp";

@Component({
  selector: 'app-wms-test-res',
  templateUrl: './wms-test-res.component.html',
  styleUrls: ['./wms-test-res.component.css', '../../../psyhological-test-component.component.css']
})
export class WmsTestResComponent implements OnInit {
  private _patient: Patient;
  @Output() reloader = new EventEmitter<string>();
  @Input('patient')
  set patient(value: Patient) {
    this._patient = value;
    this.getWmsRes();
  }

  get patient(): Patient {
    return this._patient;
  }

  public presence : Boolean
  style : Array<String>
  wmsRes : Array<String>
  wmsTotalRes: Array<String>

  constructor() { 
    this.style = new Array('', '', '')    
  }

  ngOnInit() {
  }

  presenceChanged(presence: any) {
    this.presence = presence
    this.changeColor()
    this.reloader.emit('upd');
  }

  getWmsRes() {
    if (!this.patient.psyhoTest.wms.wmsRes) {
      this.patient.psyhoTest.wms.wmsRes = new WmsRes()
      this.presence = false
    } else {
      if (this.patient.psyhoTest.wms.wmsRes.wmsTotalRes.length == 0) {
        this.presence = false
      } else {
        this.presence = true
        this.changeColor()
      }
    }
    this.wmsRes = new Array(
      "I",
      "II",
      "III",
      "IV",
      "V",
      "Va",
      "Vb",
      "VI",
      "VII",
      "VIIa",
      "VIIb"
    )
  
    this.wmsTotalRes = new Array(
      "Абсолютный показатель",
      "Корригированный показатель",
      "Эквивалентный показатель памяти"
    )
  }

  changeColor() {
    if (this.patient.psyhoTest.wms.wmsRes.wmsTotalRes[2] != '') {
      this.presence = true
      var k = Number(this.patient.psyhoTest.wms.wmsRes.wmsTotalRes[2])
      switch(true){
        case (k < 70):
           this.style[2] = 'red'
           break;
        case (k < 90):
           this.style[2] = 'orange'
           break;
        case (k < 110):
           this.style[2] = 'yellow'
           break;
        default:
           this.style[2] = 'green'
      }
    }
  }
}
