import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../../../psyho-test.service';
import { ADK } from '../../../models/test/adk';
import { isUndefined } from 'util';


@Component({
  selector: 'app-adk-test-res',
  templateUrl: './adk-test-res.component.html',
  styleUrls: ['./adk-test-res.component.css' , './../../../psyhological-test-component.component.css']
})
export class AdkTestResComponent implements OnInit {

  @Output() reloader = new EventEmitter<string>();

  _adk: ADK;
  @Input('adk')
  set adk(value: ADK) {
    this._adk = value;
    this.getAdkRes()
  }

  get adk(): ADK {
    return this._adk;
  }
  
  @Input() public id: Number

  presence : Boolean
  adkRes : Array<String>
  
  constructor() {
    
  }

  ngOnInit() {

  }

  presenceChanged(presence: any) {
    this.presence = presence;
    this.reloader.emit('upd');
  }

  getAdkRes() {
    if (this.adk && this.adk.adkRes && this.adk.adkRes.length != 0) {
      this.presence = true
    } else {
      this.adk.adkRes = new Array(6)
      for (let i=0; i < 6; i++) {
        this.adk.adkRes[i] = ' '
      }
      this.presence = false
    }
    this.adkRes = new Array(
      "Внимание",
      "Память",
      "Беглость",
      "Язык",
      "ЗПО",
      "Общий балл"
    )
  }

}
