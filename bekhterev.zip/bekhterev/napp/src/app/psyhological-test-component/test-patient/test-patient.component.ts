import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from '../psyho-test.service';
import {Patient} from "../../patients/models";
import {Express} from "../models/test/express";
import {BDI} from "../models/test/bdi";

@Component({
  selector: 'app-test-patient',
  templateUrl: './test-patient.component.html',
  styleUrls: ['./test-patient.component.css', './../psyhological-test-component.component.css']
})
export class TestPatientComponent implements OnInit {
  @Output() reloader = new EventEmitter<string>();
  @Output() updater = new EventEmitter<Patient>();
  @Input() public patient: Patient;
  load = false

  constructor() {
  }

  ngOnInit() {
  }

  updPatient(s: any){
    this.reloader.emit('upd');
  }

  updExpress(newExpress: Express)
  {
    this.patient.psyhoTest.express = newExpress;
    this.updater.emit(this.patient);
  }

  updBDI(newBDI: BDI)
  {
    this.patient.psyhoTest.bdi = newBDI;
    this.updater.emit(this.patient);
  }



}
