import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PsyhoTestService } from './psyho-test.service';
import {Patient} from "../patients/models";
import {PsyhoTest} from "./models/psyho-test";
import {ADK} from "./models/test/adk";
import {BDI} from "./models/test/bdi";
import {Express} from "./models/test/express";
import {ITT} from "./models/test/itt";
import {Stryp} from "./models/test/stryp";
import {WMS} from "./models/test/wms";


@Component({
  selector: 'app-psyhological-test-component',
  templateUrl: './psyhological-test-component.component.html',
  styleUrls: ['./psyhological-test-component.component.css']
})
export class PsyhologicalTestComponentComponent implements OnInit {

  _patient: Patient;
  load = false;
  @Output() reloader = new EventEmitter<Patient>();
  @Input('patient')
  set patient(value: Patient) {
    console.log('NEW PAT DATA')
    this.psyhoTest.setLocalPat(value);
    console.log(this.psyhoTest.getLocalPat())
    this._patient = value;
    if (!this._patient.psyhoTest) {
      this._patient.psyhoTest = new PsyhoTest();
      this._patient.psyhoTest.adk = new ADK();
      this._patient.psyhoTest.bdi = new BDI();
      this._patient.psyhoTest.express = new Express();
      this._patient.psyhoTest.itt = new ITT();
      this._patient.psyhoTest.stryp = new Stryp();
      this._patient.psyhoTest.wms = new WMS();
    }
    this.load = true;
  }

  get patient(): Patient {
    return this._patient;
  }


  constructor(private psyhoTest: PsyhoTestService) { 
    this.patient = new Patient();
  }

  ngOnInit() {
    
  }

  updatePat(s: any) {
    console.log("UPDATE");
    this.reloader.emit(s);
  }
}
