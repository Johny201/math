import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoPatientComponentComponent } from './info-patient-component.component';

describe('InfoPatientComponentComponent', () => {
  let component: InfoPatientComponentComponent;
  let fixture: ComponentFixture<InfoPatientComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfoPatientComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoPatientComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
