import { Document, Paragraph, TextRun, WidthType, BorderStyle, Table} from "docx";
import { ExpressRes } from '../models/test/express/express-res';
import { IttRes } from '../models/test/itt/itt-res';
import { WmsRes } from '../models/test/wms-res';
import { Stryp } from '../models/test/stryp';
import {Patient, PersonalInfo} from "../../patients/models";

export class DocumentCreator {

    doc: Document
    constructor() {
        this.doc = new Document()
    }

    create(patient: Patient) {
        this.style()
        this.doc.createParagraph("Психологическое обследование по научной теме «Ранняя диагностика БА»").heading1().center()

        this.createInfoPatient(patient.personal, patient.psyhoTest.date)
        this.createBdiRes(patient.psyhoTest.bdi.bdiRes)
        this.createIttRes(patient.psyhoTest.itt.ittRes)
        this.createWmsRes(patient.psyhoTest.wms.wmsRes)
        this.createExpressRes(patient.psyhoTest.express.expressRes)
        this.createStryp(patient.psyhoTest.stryp)
        this.createAdk(patient.psyhoTest.adk.adkRes)

        return this.doc
    }

    style() {
        this.doc.Styles.createParagraphStyle('Normal', 'Normal')
        .quickFormat()
        .size(24)
        .font("Times New Roman")
        .spacing({after: 120});

        this.doc.Styles.createParagraphStyle('Heading1', 'Heading 1')
        .basedOn("Normal")
        .next("Normal")
        .quickFormat()
        .size(26)
        .bold()
        .spacing({after: 120});

        this.doc.Styles.createParagraphStyle('Heading2', 'Heading 2')
        .basedOn("Normal")
        .next("Normal")
        .quickFormat()
        .size(24)
        .bold()
        .spacing({after: 120});
    }

    createInfoPatient(data: PersonalInfo, date: Date) {
        var moment = require('moment');
        var day = moment(date);
        var birthday = moment(data.birthday);
        var age = moment.duration(day.diff(birthday))._data.years;
        this.doc.addParagraph(new Paragraph(`ФИО пациента: ${data.lastname} ${data.firstname}`))
        this.doc.addParagraph(new Paragraph(`Дата обследования: ${day.format('DD.MM.YYYY')}`))
        this.doc.addParagraph(new Paragraph(`Дата рождения: ${birthday.format('DD.MM.YYYY')}`))
        this.doc.addParagraph(new Paragraph(`Возраст пациента: ${age}`))
        this.addEmptyString()
    }

    createExpressRes(data: ExpressRes) {
        this.doc.createParagraph("4. Экспресс-тестирование").heading2()
        var table = this.doc.createTable(3, 2)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        this.deleteBorder(table, 3, 2)
        table.getCell(0, 0).addContent(new Paragraph(`Тест «Часы»`).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
        table.getCell(0, 1).addContent(new Paragraph(data.Clock.toString()).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
        table.getCell(1, 0).addContent(new Paragraph(`FAB`).center())
        table.getCell(1, 1).addContent(new Paragraph(`${data.resFAB}`).center())
        table.getCell(2, 0).addContent(new Paragraph(`MMSE`).center())
        table.getCell(2, 1).addContent(new Paragraph(`${data.resMMSE}`).center())     
    }

    createBdiRes(data: String) {
        this.doc.createParagraph("1. Опросник Бека").heading2()
        var table = this.doc.createTable(1, 2)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        this.deleteBorder(table, 1, 2)
        table.getCell(0, 0).addContent(new Paragraph(`Уровень депрессии`).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
        table.getCell(0, 1).addContent(new Paragraph(`${data}`).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
    }

    createIttRes(ittRes: IttRes){
        this.doc.createParagraph("2. Интегративный тест тревожности").heading2()
        var table = this.doc.createTable(8, 5)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        this.deleteBorder(table, 8, 5)
        table.getCell(0, 0).addContent(new Paragraph(``)).CellProperties.setWidth('40%', WidthType.PERCENTAGE)
        table.getRow(0).mergeCells(3, 4)
        table.getRow(0).mergeCells(1, 2)
        table.getCell(0, 1).addContent(new Paragraph(`Ситуативная тревожность`).center()).CellProperties.setWidth('30%', WidthType.PERCENTAGE)
        table.getCell(0, 2).addContent(new Paragraph(`Личностная тревожность`).center()).CellProperties.setWidth('30%', WidthType.PERCENTAGE)
        table.getCell(1, 0).addContent(new Paragraph(``)).CellProperties.setWidth('40%', WidthType.PERCENTAGE)
        table.getCell(1, 1).addContent(new Paragraph(`Сырые баллы`).center()).CellProperties.setWidth('17.5%', WidthType.PERCENTAGE)
        table.getCell(1, 2).addContent(new Paragraph(`Стены`).center()).CellProperties.setWidth('12.5%', WidthType.PERCENTAGE)
        table.getCell(1, 3).addContent(new Paragraph(`Сырые баллы`).center()).CellProperties.setWidth('17.5%', WidthType.PERCENTAGE)
        table.getCell(1, 4).addContent(new Paragraph(`Стены`).center()).CellProperties.setWidth('12.5%', WidthType.PERCENTAGE)

        var name = new Array('Общий показатель', 'Эмоциональный дискомфорт', 'Астения', 'Страхи', 'Оценка перспективы', 'Сензетивность')
        for (let i = 0; i < 6; i++) {
            table.getCell(2 + i, 0).addContent(new Paragraph(`${name[i]}`))
            table.getCell(2 + i, 1).addContent(new Paragraph(`${ittRes.sittRes[i]}`).center())
            table.getCell(2 + i, 2).addContent(new Paragraph(`${ittRes.sittRes[i + 6]}`).center())
            table.getCell(2 + i, 3).addContent(new Paragraph(`${ittRes.pittRes[i]}`).center())
            table.getCell(2 + i, 4).addContent(new Paragraph(`${ittRes.pittRes[i + 6]}`).center())
        }

    }

    createWmsRes(data: WmsRes) {
        this.doc.createParagraph("3. Шкала памяти Векслера").heading2()
        var table = this.doc.createTable(7, 6)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        this.deleteBorder(table, 7, 6)
        table.getCell(0, 0).addContent(new Paragraph(`I`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(0, 1).addContent(new Paragraph(`${data.wmsSubRes[0]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(1, 0).addContent(new Paragraph(`II`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(1, 1).addContent(new Paragraph(`${data.wmsSubRes[1]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(2, 0).addContent(new Paragraph(`III`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(2, 1).addContent(new Paragraph(`${data.wmsSubRes[2]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(3, 0).addContent(new Paragraph(`IV`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(3, 1).addContent(new Paragraph(`${data.wmsSubRes[3]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 0).addContent(new Paragraph(`V`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 1).addContent(new Paragraph(`${data.wmsSubRes[4]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 2).addContent(new Paragraph(`Va`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 3).addContent(new Paragraph(`${data.wmsSubRes[5]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 4).addContent(new Paragraph(`Vb`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(4, 5).addContent(new Paragraph(`${data.wmsSubRes[6]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(5, 0).addContent(new Paragraph(`VI`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(5, 1).addContent(new Paragraph(`${data.wmsSubRes[7]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 0).addContent(new Paragraph(`VII`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 1).addContent(new Paragraph(`${data.wmsSubRes[8]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 2).addContent(new Paragraph(`VIIa`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 3).addContent(new Paragraph(`${data.wmsSubRes[9]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 4).addContent(new Paragraph(`VIIb`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        table.getCell(6, 5).addContent(new Paragraph(`${data.wmsSubRes[10]}`).center()).CellProperties.setWidth(`${100/6}%`, WidthType.PERCENTAGE)
        this.addEmptyString()

        var totalTable = this.doc.createTable(3,2)
        totalTable.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        this.deleteBorder(totalTable, 3, 2)
        totalTable.getCell(0, 0).addContent(new Paragraph(`Абсолютный показатель`)).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
        totalTable.getCell(0, 1).addContent(new Paragraph(`${data.wmsTotalRes[0]}`).center()).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
        totalTable.getCell(1, 0).addContent(new Paragraph(`Корригированный показатель`)).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
        totalTable.getCell(1, 1).addContent(new Paragraph(`${data.wmsTotalRes[1]}`).center()).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
        totalTable.getCell(2, 0).addContent(new Paragraph(`Эквивалентный показатель памяти`)).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
        totalTable.getCell(2, 1).addContent(new Paragraph(`${data.wmsTotalRes[2]}`).center()).CellProperties.setWidth(`50%`, WidthType.PERCENTAGE)
    }

    createStryp(data: Stryp) {
        this.addEmptyString()
        this.addEmptyString()
        this.doc.createParagraph("5. Тест Струпа").heading2()
        var table = this.doc.createTable(4, 3)
        this.deleteBorder(table, 4, 3)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        table.getCell(0, 0).addContent(new Paragraph(``).center()).CellProperties.setWidth(`${100/3}%`, WidthType.PERCENTAGE)
        table.getCell(0, 1).addContent(new Paragraph(`Время выполнения, сек`).center()).CellProperties.setWidth(`${100/3}%`, WidthType.PERCENTAGE)
        table.getCell(0, 2).addContent(new Paragraph(`Общее число ошибок`).center()).CellProperties.setWidth(`${100/3}%`, WidthType.PERCENTAGE)
        for (let i = 0; i < 3; i++) {
            table.getCell(i + 1, 0).addContent(new Paragraph(`Карта ${i + 1}`).center())
            table.getCell(i + 1, 1).addContent(new Paragraph(`${data.strypTest[i]}`).center())
            table.getCell(i + 1, 2).addContent(new Paragraph(`${data.strypTest[i+3]}`).center())
        }
        this.addEmptyString()

        var res = this.doc.createTable(2, 2)
        this.deleteBorder(res, 2, 2)
        res.Properties.setWidth(WidthType.PERCENTAGE , '100%')
        res.getCell(0, 0).addContent(new Paragraph(`Коэффициент интерференции`).center()).CellProperties.setWidth(`${100/2}%`, WidthType.PERCENTAGE)
        res.getCell(0, 1).addContent(new Paragraph(`${data.strypRes[0]}`).center()).CellProperties.setWidth(`${100/2}%`, WidthType.PERCENTAGE)
        res.getCell(1, 0).addContent(new Paragraph(`Коэффициент вербальности`).center()).CellProperties.setWidth(`${100/2}%`, WidthType.PERCENTAGE)
        res.getCell(1, 1).addContent(new Paragraph(`${data.strypRes[1]}`).center()).CellProperties.setWidth(`${100/2}%`, WidthType.PERCENTAGE)

    }

    createAdk(data: Array<String>) {
        this.doc.createParagraph("6. Адденбрукская когнитивная шкала").heading2()
        var table = this.doc.createTable(6, 2)
        this.deleteBorder(table, 6, 2)
        table.Properties.setWidth(WidthType.PERCENTAGE , '100%')

        var name = new Array('Внимание', 'Память', 'Беглость', 'Язык', 'ЗПО', 'Общий балл')
        for (let i = 0; i < 6; i++) {
            table.getCell(i, 0).addContent(new Paragraph(`${name[i]}`).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
            table.getCell(i, 1).addContent(new Paragraph(`${data[i]}`).center()).CellProperties.setWidth('50%', WidthType.PERCENTAGE)
        }
    }

    deleteBorder(table: Table, row: number, column: number) {
        for (let i = 0; i < row; i++) {
            for (let j = 0; j < column; j++) {
                table.getCell(i, j).CellProperties.Borders.addTopBorder(BorderStyle.SINGLE, 1, 'grey')
                table.getCell(i, j).CellProperties.Borders.addEndBorder(BorderStyle.SINGLE, 1, 'grey')
                table.getCell(i, j).CellProperties.Borders.addStartBorder(BorderStyle.SINGLE, 1, 'grey')
                table.getCell(i, j).CellProperties.Borders.addBottomBorder(BorderStyle.SINGLE, 1, 'grey')
            }
        }
    }

    addEmptyString() {
        this.doc.addParagraph(new Paragraph().addRun(new TextRun("")))
    }
}
