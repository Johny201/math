import { Component, OnInit, Input } from '@angular/core';
import { Data } from '../models/data';
import { Packer} from 'docx';
import * as saveAs from 'file-saver/src/FileSaver';
import { PsyhoTestService } from '../psyho-test.service';
import { DocumentCreator } from './document-creator';
import { isUndefined } from 'util';
import {Patient} from '../../patients/models';
import {PsyhoTest} from "../models/psyho-test";
import {ADK} from "../models/test/adk";
import {BDI} from "../models/test/bdi";
import {Express} from "../models/test/express";
import {ITT} from "../models/test/itt";
import {Stryp} from "../models/test/stryp";
import {WMS} from "../models/test/wms";

@Component({
  selector: 'app-info-patient-component',
  templateUrl: './info-patient-component.component.html',
  styleUrls: ['./info-patient-component.component.css', './../psyhological-test-component.component.css'],
  providers: [ PsyhoTestService ]
})
export class InfoPatientComponentComponent implements OnInit {

  _patient: Patient;
  @Input('patient')
  set patient(value: Patient) {
    this._patient = value;
    console.log('PAT: ', value)
    this.getInfoPatient()
    this.getConclusion()
  }

  get patient(): Patient {
    return this._patient;
  }

  infoPatient: Array<Data>
  conclusion: Array<String>

  constructor() { 
    this.conclusion = new Array('', '', '', '')
  }

  ngOnInit() {
  }

  getInfoPatient() {
    var moment = require('moment');
    var date = moment(this.patient.psyhoTest.date);
    var birthday = moment(this.patient.personal.birthday);
    var age = moment.duration(date.diff(birthday))._data.years;
    this.infoPatient = new Array(
      {name: "Номер пациента", value: this.patient.number}, 
      {name: "Фамилия пациента", value: this.patient.personal.lastname}, 
      {name: "Имя пациента", value: this.patient.personal.firstname},
      {name: "Дата рождения", value: birthday.format('DD.MM.YYYY')},
      {name: "Возраст", value: age},
      {name: "Дата обследования", value: date.format('DD.MM.YYYY')},
      {name: "Группа", value: this.patient.group},
      //{name: "Мануальная асимметрия", value: this.patient.personal.asymmetry}
    )
  }

  getConclusion() {
    if (this.patient.psyhoTest.express.expressRes) {
      this.getConclusionExpress()
    }
    if (this.patient.psyhoTest.bdi.bdiRes) {
      this.getConclusionBdi()
    }  
    if (this.patient.psyhoTest.wms.wmsRes && this.patient.psyhoTest.wms.wmsRes.wmsSubRes && this.patient.psyhoTest.wms.wmsRes.wmsSubRes[0]) {
      this.getConclusionWms()
    }
  }

  getConclusionExpress() {
    let conclusionFab : string
      if (this.patient.psyhoTest.express.expressRes.resFAB != ' ') {
        var totalFab = Number(this.patient.psyhoTest.express.expressRes.resFAB)
        switch (true) {
          case (totalFab <= 11): 
            conclusionFab = "Есть признаки лобной деменции"
            break;
          case (totalFab <= 15):
            conclusionFab = "Умеренная лобная дисфункция"
            break;
          default:
            conclusionFab = "Нормальная лобная дисфункция"
            break;
        }
      } else {
        conclusionFab = ""
      }
      this.conclusion[0] = conclusionFab

      let conclusionMmse: string
      if (this.patient.psyhoTest.express.expressRes.resMMSE != ' ') {
        var totalMmse = Number(this.patient.psyhoTest.express.expressRes.resMMSE)
        switch (true) {
          case (totalMmse <= 10): 
            conclusionMmse = "Тяжелая деменция"
            break;
          case (totalMmse <= 19): 
            conclusionMmse = "Деменция умеренной степени выраженности"
            break;
          case (totalMmse <= 23): 
            conclusionMmse = "Деменция легкой степени выраженности"
            break;
          case (totalMmse <= 27): 
            conclusionMmse = "Легкие когнитивные нарушения"
            break;
          default:
            conclusionMmse = "Нет нарушений когнитивных функций"
            break;
        }
      } else {
        conclusionMmse = ""
      }
      
      this.conclusion[1] = conclusionMmse
  }

  getConclusionBdi() {
    if (this.patient.psyhoTest.bdi.bdiRes != ' ') {
      let res = Number(this.patient.psyhoTest.bdi.bdiRes)
      let conclusionBdi:string
      switch (true) {
        case (res <= 9): 
          conclusionBdi = "Депрессивные симптомы отсутствуют"
          break;
        case (res <= 15): 
          conclusionBdi = "Лёгкая депрессия"
          break;
        case (res <= 19): 
          conclusionBdi = "Умеренная депрессия"
          break;
        case (res <= 29): 
          conclusionBdi = "Выраженная депрессия"
          break;
        default:
          conclusionBdi = "Тяжелая депрессия"
          break;
      }
      this.conclusion[2] = conclusionBdi
    } else {
      this.conclusion[2] = ''
    }
  }

  getConclusionWms() {
    if (this.patient.psyhoTest.wms.wmsRes.wmsTotalRes[2] != '') {
      var res = Number(this.patient.psyhoTest.wms.wmsRes.wmsTotalRes[2])
      let conclusion:string
      switch (true) {
        case (res <= 20): 
        conclusion = "Полная УО (идиотия)"
        break;
        case (res <= 35): 
        conclusion = "Глубокая УО, выраженная имбецильность"
        break;
        case (res <= 51): 
        conclusion = "Умеренная (средняя) УО, невыраженная имбецильность"
        break;
        case (res <= 57): 
        conclusion = "Легкая УО (дебильность)"
        break;
        case (res <= 69): 
        conclusion = "Умственный дефект"
        break;
        case (res <= 79): 
        conclusion = "Пограничная зона"
        break;
        case (res <= 89): 
        conclusion = "Низкая (плохая) норма"
        break;
        case (res <= 109): 
        conclusion = "Средний результат"
        break;
        case (res <= 119): 
        conclusion = "Хорошая норма"
        break;
        case (res <= 129): 
        conclusion = "Высокий  результат"
        break;
        default:
        conclusion = "Очень высокий  результат"
        break;
      }
      this.conclusion[3] = conclusion
    } else {
      this.conclusion[3] = ''
    }
  }

  public download() {
    var documentCreator = new DocumentCreator()
    var doc = documentCreator.create(this.patient)

    const packer = new Packer();
    var nameFile = this.infoPatient[1].value + "_" + this.infoPatient[2].value + ".docx"
    packer.toBlob(doc).then(blob => {
      saveAs(blob, nameFile);
      console.log('Document created successfully');
    });
  }

}
