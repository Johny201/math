import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Data } from '../../models/data';
import { PsyhoTestService } from '../../psyho-test.service';
import { BDI } from '../../models/test/bdi';

@Component({
  selector: 'app-form-bdi-test',
  templateUrl: './form-bdi-test.component.html',
  styleUrls: ['./form-bdi-test.component.css', './../../psyhological-test-component.component.css']
})
export class FormBdiTestComponent implements OnInit {

  @Input() bdi: BDI
  @Input() id: Number
  @Output() presenceChanged = new EventEmitter<boolean>()
  @Output() bdiChanged = new EventEmitter<BDI>()

  bdiRes: String
  bdiTest: Array<Data>
  bdi1: Array<String>
  number: Array<number>

  all: Boolean

  constructor(private psyhoTest: PsyhoTestService) { 
    this.testBdi()
    this.all = false
  }

  ngOnInit() {
    this.bdiRes = this.bdi.bdiRes
    this.bdi1 = this.bdi.bdiTest
  }

  public next(inp) {
    var elems = inp.form.elements

    elems[[].indexOf.call(elems, inp) + 4 - ([].indexOf.call(elems, inp) - 1) % 4].focus()
    elems[[].indexOf.call(elems, inp) + 4 - ([].indexOf.call(elems, inp) - 1) % 4].checked = true
    elems[[].indexOf.call(elems, inp) + 5 - ([].indexOf.call(elems, inp) - 1) % 4].checked = false
    elems[[].indexOf.call(elems, inp) + 6 - ([].indexOf.call(elems, inp) - 1) % 4].checked = false
    elems[[].indexOf.call(elems, inp) + 7 - ([].indexOf.call(elems, inp) - 1) % 4].checked = false

    var id = elems[[].indexOf.call(elems, inp)].id
    if (id.length == 6) {
      var number = Number(id.charAt(3))
      var answer = Number(id.charAt(5))
    } else {
      var number = 10 * Number(id.charAt(3)) + Number(id.charAt(4))
      var answer = Number(id.charAt(6))
    }

    this.bdi1[number] = "bdi_" + answer
    this.bdi1[number + 1] = "bdi_0"

    this.all = true
  
    for (let el of this.bdi1) {
      if (el == "") {
        this.all = false
      }
    }
  }

  public onSubmitted(){
    let res: number
    if (this.all) {
      res = 0
      for (let el of this.bdi1){
        res += Number(el.charAt(4))
      }
      this.bdiRes = res.toString()
    } 
    this.updateBdi()
  }

  updateBdi(){
    let result = new BDI()
    result.bdiRes = this.bdiRes
    result.bdiTest = this.bdi1
    console.log(result)
    this.presenceChanged.emit(true);
    this.bdiChanged.emit(result);
  }

  private testBdi() {
    this.number = new Array(21)
    for (let i = 0; i < 21; i++) {
      this.number[i] = i
    }

    this.bdiTest = new Array(
      {name: "1", value: "Я не чувствую себя несчастным"},
      {name: "2", value: "Я чувствую себя несчастным"},
      {name: "3", value: "Я все время несчастен и не могу освободиться от этого чувства."},
      {name: "4", value: "Я настолько несчастен и опечален, что не могу это вынести."},
  
      {name: "1", value: "Думая о будущем, я не чувствую себя особенно разочарованным."},
      {name: "2", value: "Думая о будущем я чувствую себя разочарованным."},
      {name: "3", value: "Я чувствую, что мне нечего ждать в будущем"},
      {name: "4", value: "Я чувствую, что будущее безнадежно и ничто не изменится к лучшему"},
  
      {name: "1", value: "Я не чувствую себя неудачником"},
      {name: "2", value: "Я чувствую, что у меня было больше неудач, чем у большинства других людей"},
      {name: "3", value: "Когда я оглядываюсь на прожитую жизнь, все, что я вижу – это череда неудач."},
      {name: "4", value: "Я чувствую себя полным неудачником"},
  
      {name: "1", value: "Я получаю столько же удовольствия от жизни, как и раньше."},
      {name: "2", value: "Я не получаю столько же удовольствия от жизни, как и раньше."},
      {name: "3", value: "Я не получаю настоящего удовлетворения от чего бы то ни было."},
      {name: "4", value: "Я всем не удовлетворен, и мне все надоело"},
  
      {name: "1", value: "Я не чувствую себя особенно виноватым"},
      {name: "2", value: "Довольно часто я чувствую себя виноватым."},
      {name: "3", value: "Почти всегда я чувствую себя виноватым."},
      {name: "4", value: "Я чувствую себя виноватым все время"},
  
      {name: "1", value: "Я не чувствую, что меня за что-то наказываю"},
      {name: "2", value: "Я чувствую, что могу быть наказан за что-то."},
      {name: "3", value: "Я ожидаю, что меня накажут."},
      {name: "4", value: "Я чувствую, что меня наказывают за что-то."},
  
      {name: "1", value: "Я не испытываю разочарования в себе"},
      {name: "2", value: "Я разочарован в себе"},
      {name: "3", value: "Я внушаю себе отвращение"},
      {name: "4", value: "Я ненавижу себя"},
  
      {name: "1", value: "У меня нет чувства, что я в чем-то хуже других"},
      {name: "2", value: "Я самокритичен и признаю свои слабости и ошибки"},
      {name: "3", value: "Я все время виню себя за свои ошибки"},
      {name: "4", value: "Я виню себя за все плохое, что происходит"},
  
      {name: "1", value: "У меня нет мыслей о том, чтобы покончить с собой"},
      {name: "2", value: "У меня есть мысли о том, чтобы покончить с собой, но я этого не делаю"},
      {name: "3", value: "Я хотел бы покончить жизнь самоубийством"},
      {name: "4", value: "Я бы покончил с собой, если бы представился удобный случай"},
  
      {name: "1", value: "Я плачу не больше, чем обычно"},
      {name: "2", value: "Сейчас я плачу больше обычного"},
      {name: "3", value: "Я теперь все время плачу"},
      {name: "4", value: "Раньше я еще мог плакать, но теперь не смогу, даже если захочу"},
  
      {name: "1", value: "Сейчас я не более раздражен, чем обычно"},
      {name: "2", value: "Я раздражаюсь легче, чем раньше, даже по пустякам"},
      {name: "3", value: "Сейчас я все время раздражен"},
      {name: "4", value: "Меня уже ничто не раздражает, потому что все стало безразлично"},
  
      {name: "1", value: "Я не потерял интереса к другим людям"},
      {name: "2", value: "У меня меньше интереса к другим людям, чем раньше"},
      {name: "3", value: "Я почти утратил интерес к другим людям"},
      {name: "4", value: "Я потерял всякий интерес к другим людям"},
  
      {name: "1", value: "Я способен принимать решения, так же как всегда"},
      {name: "2", value: "Я откладываю принятия решений, чаще чем обычно"},
      {name: "3", value: "Я испытываю больше трудностей в принятии решений, чем обычно"},
      {name: "4", value: "Я больше не могу принимать какие-либо решения."},
  
      {name: "1", value: "Я не чувствую, что выгляжу хуже, чем обычно"},
      {name: "2", value: "Я обеспокоен тем, что выгляжу постаревшим или непривлекательным"},
      {name: "3", value: "Я чувствую, что изменения, произошедшие с моей внешностью, сделали меня непривлекательным."},
      {name: "4", value: "Я уверен, что выгляжу безобразно"},
  
      {name: "1", value: "Я могу работать, так же как раньше"},
      {name: "2", value: "Мне надо приложить дополнительные усилия, что бы начать что-то делать"},
      {name: "3", value: "Я с большим трудом заставляю себя что-то сделать"},
      {name: "4", value: "Я вообще не могу работать"},
  
      {name: "1", value: "Я могу спать так же хорошо, как обычно"},
      {name: "2", value: "Я сплю не так хорошо, как всегда"},
      {name: "3", value: "Я просыпаюсь на 1-2 часа раньше чем обычно, и с трудом могу заснуть снова"},
      {name: "4", value: "Я практически вообще не сплю"},
  
      {name: "1", value: "Я устаю не больше чем обычно"},
      {name: "2", value: "Я устаю легче обычного"},
      {name: "3", value: "Я устаю почти от всего того, что делаю"},
      {name: "4", value: "Я слишком устал, что бы делать что бы то ни было"},
  
      {name: "1", value: "Мой аппетит не хуже чем обычно"},
      {name: "2", value: "У меня не такой хороший аппетит, как был раньше"},
      {name: "3", value: "Сейчас мой аппетит стал намного хуже"},
      {name: "4", value: "Я вообще потерял аппетит"},
  
      {name: "1", value: "Если в последнее время я и потерял в весе, то совсем не намного"},
      {name: "2", value: "Я потерял в весе более 2 кг"},
      {name: "3", value: "Я потерял в весе более 4 кг"},
      {name: "4", value: "Я потерял в весе более 6 кг"},
  
      {name: "1", value: "Я беспокоюсь о своем здоровье не больше, чем обычно"},
      {name: "2", value: "Меня беспокоят такие проблемы, как различные боли, расстройства желудка, запоры"},
      {name: "3", value: "Я настолько обеспокоен своим здоровьем, что мне даже трудно думать о чем-то другом"},
      {name: "4", value: "Я настолько обеспокоен своим здоровьем, что даже не могу думать о чем-то другом"},
  
      {name: "1", value: "Я не замечал каких-либо изменений в моих сексуальных интересах"},
      {name: "2", value: "Я меньше, чем обычно интересуюсь сексом"},
      {name: "3", value: "Сейчас я намного меньше интересуюсь сексом"},
      {name: "4", value: "Я совершенно утратил интерес к сексу"},
  )
  }
}

