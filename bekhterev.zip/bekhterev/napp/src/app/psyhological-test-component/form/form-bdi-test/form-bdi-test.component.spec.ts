import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormBdiTestComponent } from './form-bdi-test.component';

describe('FormBdiTestComponent', () => {
  let component: FormBdiTestComponent;
  let fixture: ComponentFixture<FormBdiTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormBdiTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormBdiTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
