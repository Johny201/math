import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PsyhoTestService } from '../../psyho-test.service';
import { CommonService } from '../../common.service';
import { ITT } from '../../models/test/itt';
import { isUndefined } from 'util';
import { IttRes } from '../../models/test/itt/itt-res';
import { IttTest } from '../../models/test/itt/itt-test';

@Component({
  selector: 'app-form-itt-test',
  templateUrl: './form-itt-test.component.html',
  styleUrls: ['./form-itt-test.component.css', './../../psyhological-test-component.component.css']
})
export class FormIttTestComponent implements OnInit {

  @Input() itt : ITT
  @Input() id: Number
  @Output() presenceChanged = new EventEmitter<boolean>()

  sitt: Array<String>
  pitt: Array<String>
  
  sittTest: Array<String>
  pittTest: Array<String>

  sittRes: Array<String>
  pittRes: Array<String>

  all: Boolean

  constructor(private psyhoTest: PsyhoTestService, private commonService: CommonService) {
    this.test()
    this.all = false
   }

  ngOnInit(): void {
    this.getIttTest()
    this.getIttRes()
  }

  getIttRes() {
    this.sittRes = this.itt.ittRes.sittRes
    this.pittRes = this.itt.ittRes.pittRes
  }

  getIttTest() {
    if (!isUndefined(this.itt.ittTest)) {
      if (this.itt.ittTest.sittTest.length == 0) {
        this.sitt = new Array(15)
        this.pitt = new Array(15)
        for (let i = 0; i < 15; i++) {
          this.sitt[i] = ''
          this.pitt[i] = ''
        }
      } else {
        this.sitt = this.itt.ittTest.sittTest
        this.pitt = this.itt.ittTest.pittTest 
      }
    } else {
      this.sitt = new Array(15)
      this.pitt = new Array(15)
      for (let i = 0; i < 15; i++) {
        this.sitt[i] = ''
        this.pitt[i] = ''
      }
    }
  }

  public next(inp) {
    var elems = inp.form.elements

    elems[[].indexOf.call(elems, inp) + 4 - ([].indexOf.call(elems, inp)) % 4].focus()
    elems[[].indexOf.call(elems, inp) + 4 - ([].indexOf.call(elems, inp)) % 4].checked = true
    elems[[].indexOf.call(elems, inp) + 5 - ([].indexOf.call(elems, inp)) % 4].checked = false
    elems[[].indexOf.call(elems, inp) + 6 - ([].indexOf.call(elems, inp)) % 4].checked = false
    elems[[].indexOf.call(elems, inp) + 7 - ([].indexOf.call(elems, inp)) % 4].checked = false
    this.all = true
    
    var id = elems[[].indexOf.call(elems, inp)].id
    if (id.length == 7) {
      var number = Number(id.charAt(4))
      var answer = Number(id.charAt(6))
    } else {
      var number = 10 * Number(id.charAt(4)) + Number(id.charAt(5))
      var answer = Number(id.charAt(7))
    }
    
    if (id.charAt(0) == 's') {
      this.sitt[number] = "sitt_" + answer
      if (number < 14) {
        this.sitt[number + 1] = "sitt_0"
      } else {
        if (number == 14) {
          this.pitt[0] = "pitt_0"
        }
      }
    } else {
      this.pitt[number] = "pitt_" + answer
      if (number < 14) {
        this.pitt[number + 1] = "pitt_0"
      }
    }
    
    for (let el of this.sitt) {
      if (el == "") {
        this.all = false
      }
    }
    for (let el of this.pitt) {
      if (el == "") {
        this.all = false
      }
    }
  }

  updateItt() {
    let newITT = new ITT()
    newITT.ittRes = new IttRes()
    newITT.ittTest = new IttTest()
    newITT.ittRes.sittRes = this.sittRes
    newITT.ittRes.pittRes = this.pittRes
    newITT.ittTest.sittTest = this.sitt
    newITT.ittTest.pittTest = this.pitt
    let newPat = this.psyhoTest.patient;
    newPat.psyhoTest.itt = newITT;
    this.psyhoTest.updatePatient(newPat);
    this.presenceChanged.emit(true)
  }

  public onSubmitted() {
    var diagFactor: number[][] =[
      [0, 25, 49, 74],
      [0, 24, 49, 73],
      [0, 37, 74, 110],
      [0, 24, 53, 80],
      [0, 32, 65, 98],
      [0, 24, 49, 73],
      [0, 37, 74, 111],
      [0, 30, 61, 91],
      [0, 28, 56, 85],
      [0, 57, 114, 171],
      [0, 43, 86, 129],
      [0, 29, 58, 87],
      [0, 41, 81, 122],
      [0, 29, 58, 87],
      [0, 31, 61, 92]
    ] 

    var totalSitt = 0
    var sittTestNumber = new Array<number>(15)
    var i = 0
    for (let el of this.sitt) {
      sittTestNumber[i] = Number(el.charAt(5))
      totalSitt += sittTestNumber[i]
      i++
    }
    this.sittRes[0] = totalSitt.toString()
    
    var sittTestResNumber = new Array<number>(5)
    for (var k = 0; k < sittTestNumber.length; k++) {
        sittTestNumber[k] = diagFactor[k][sittTestNumber[k]]
    }

    sittTestResNumber[0] = sittTestNumber[0] + sittTestNumber[1] + sittTestNumber[3] + sittTestNumber[5]
    sittTestResNumber[1] = sittTestNumber[7] + sittTestNumber[12] + sittTestNumber[13]
    sittTestResNumber[2] = sittTestNumber[6] + sittTestNumber[8] + sittTestNumber[11]
    sittTestResNumber[3] = sittTestNumber[2] + sittTestNumber[4] + sittTestNumber[14]
    sittTestResNumber[4] = sittTestNumber[9] + sittTestNumber[10]

    for (var k = 0; k < sittTestResNumber.length; k++) {
      this.sittRes[k+1] = sittTestResNumber[k].toString()
    }

    diagFactor[3][1] = 27

    var totalPitt = 0
    var pittTestNumber = new Array<number>(15)
    var i = 0
    for (let el of this.pitt) {
      pittTestNumber[i] = Number(el.charAt(5))
      totalPitt += pittTestNumber[i]
      i++
    }
    this.pittRes[0] = totalPitt.toString()
    
    var pittTestResNumber = new Array<number>(5)
    for (var k = 0; k < pittTestNumber.length; k++) {
        pittTestNumber[k] = diagFactor[k][pittTestNumber[k]]
    }

    pittTestResNumber[0] = pittTestNumber[0] + pittTestNumber[1] + pittTestNumber[3] + pittTestNumber[5]
    pittTestResNumber[1] = pittTestNumber[7] + pittTestNumber[12] + pittTestNumber[13]
    pittTestResNumber[2] = pittTestNumber[6] + pittTestNumber[8] + pittTestNumber[11]
    pittTestResNumber[3] = pittTestNumber[2] + pittTestNumber[4] + pittTestNumber[14]
    pittTestResNumber[4] = pittTestNumber[9] + pittTestNumber[10]

    for (var k = 0; k < pittTestResNumber.length; k++) {
      this.pittRes[k+1] = pittTestResNumber[k].toString()
    }

    var total = new Array<number>(0, 6, 8, 9, 11, 14, 18, 22, 26)
    var ed = new Array<number>(0, 34, 48, 62, 76, 100, 137, 173, 209)
    var aca = new Array<number>(0, 26, 36, 47, 57, 82, 122, 161, 201)
    var pca = new Array<number>(0, 13, 19, 24, 29, 54, 99, 144, 188)
    var pa = new Array<number>(0, 44, 62, 80, 97, 122, 155, 187, 219)
    var srp = new Array<number>(0, 50, 70, 90, 110, 135, 165, 195, 225)

    var sittResS = new Array<number>(0, 0, 0, 0, 0, 0) 
    var pittResS = new Array<number>(0, 0, 0, 0, 0, 0) 

    for (let el of total) {
      if (totalSitt > el) sittResS[0]++
      if (totalPitt > el) pittResS[0]++ 
    }

    for (let el of ed) {
      if (sittTestResNumber[0] > el) sittResS[1]++
      if (pittTestResNumber[0] > el) pittResS[1]++ 
    }

    for (let el of aca) {
      if (sittTestResNumber[1] > el) sittResS[2]++
      if (pittTestResNumber[1] > el) pittResS[2]++ 
    }

    for (let el of pca) {
      if (sittTestResNumber[2] > el) sittResS[3]++
      if (pittTestResNumber[2] > el) pittResS[3]++ 
    }

    for (let el of pa) {
      if (sittTestResNumber[3] > el) sittResS[4]++
      if (pittTestResNumber[3] > el) pittResS[4]++ 
    }

    for (let el of srp) {
      if (sittTestResNumber[4] > el) sittResS[5]++
      if (pittTestResNumber[4] > el) pittResS[5]++ 
    }

    for (let k = 0; k < 6; k++) {
      this.sittRes[k+6] = sittResS[k].toString()
      this.pittRes[k+6] = pittResS[k].toString()
    }

    this.updateItt()
   }

   test() {
     this.sittTest = new Array(
      "Я нахожусь в напряжении",
      "Я расстроен",
      "Я тревожусь о будущем",
      "Я нервничаю",
      "Я озабочен",
      "Я возбужден",
      "Я ощущаю непонятную угрозу",
      "Я быстро устаю",
      "Я не уверен в себе",
      "Я избегаю любых конфликтов",
      "Я легко прихожу в замешательство",
      "Я ощущаю свою бесполезность",
      "Я плохо сплю",
      "Я ощущаю себя утомленным",
      "Я эмоционально чувствителен"
     )

     this.pittTest = new Array(
      "Я находился в напряжении",
      "Я расстраивался",
      "Я тревожился о будущем",
      "Я нервничал",
      "Я бывал озабочен",
      "Я бывал возбужден",
      "Я ощущал непонятную угрозу",
      "Я быстро устал",
      "Я был не уверен в себе",
      "Я избегал любых конфликтов",
      "Я легко приходил в замешательство",
      "Я ощущал свою бесполезность",
      "Я плохо спал",
      "Я ощущал себя утомленным",
      "Я бывал эмоционально чувствителен"
     )
   }
}
