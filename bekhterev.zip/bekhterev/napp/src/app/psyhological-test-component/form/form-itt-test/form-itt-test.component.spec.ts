import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormIttTestComponent } from './form-itt-test.component';

describe('FormIttTestComponent', () => {
  let component: FormIttTestComponent;
  let fixture: ComponentFixture<FormIttTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormIttTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormIttTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
