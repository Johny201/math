import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormStrypTestComponent } from './form-stryp-test.component';

describe('FormStrypTestComponent', () => {
  let component: FormStrypTestComponent;
  let fixture: ComponentFixture<FormStrypTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormStrypTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormStrypTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
