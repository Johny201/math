import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Data } from '../../models/data';
import { Stryp } from '../../models/test/stryp';
import { isUndefined } from 'util';
import { PsyhoTestService } from '../../psyho-test.service';

@Component({
  selector: 'app-form-stryp-test',
  templateUrl: './form-stryp-test.component.html',
  styleUrls: ['./form-stryp-test.component.css', './../../psyhological-test-component.component.css']
})
export class FormStrypTestComponent implements OnInit {

  @Input() stryp: Stryp
  @Input() id: Number
  @Output() presenceChanged = new EventEmitter<boolean>()

  strypTest: Array<Data>
  strypRes: Array<String>
  
  constructor(private psyhoTest: PsyhoTestService) {
    console.log("FORM CREATED")
  }

  ngOnInit() {
    this.getStryp()
  }

  getStryp() {
    this.strypTest = new Array(
      {name: "Карта 1", value: ""},
      {name: "Карта 2", value: ""},
      {name: "Карта 3", value: ""},
      {name: "Карта 1", value: ""},
      {name: "Карта 2", value: ""},
      {name: "Карта 3", value: ""},
    )
    if (!isUndefined(this.stryp.strypTest) && this.stryp.strypTest.length != 0) {
      for (let i = 0; i < 6;  i++) {
        this.strypTest[i].value = this.stryp.strypTest[i]
      }
    }
    this.strypRes = this.stryp.strypRes 
  }

  public nextInput(inp) {
    var elems = inp.form.elements
    elems[[].indexOf.call(elems, inp)+1].focus()
  }

  public onSubmitted() {
    this.strypRes[0] = (Number(this.strypTest[2].value) - Number(this.strypTest[1].value)).toString()
    this.strypRes[1] = (Number(this.strypTest[1].value)/Number(this.strypTest[0].value)).toFixed(2)
    this.updateStryp()
  }

  updateStryp(){
    var test:String[] = new Array(6)
    for (let i = 0; i < 6; i++) {
      test[i] = this.strypTest[i].value
    }
    let newStryp = new Stryp()
    newStryp.strypRes = this.strypRes
    newStryp.strypTest = test
    console.log(this.psyhoTest)
    let newpat = this.psyhoTest.getLocalPat();

    newpat.psyhoTest.stryp = newStryp;
    this.psyhoTest.updatePatient(newpat)
    this.presenceChanged.emit(true);

  }

}
