import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormExpressTestComponent } from './form-express-test.component';

describe('FormExpressTestComponent', () => {
  let component: FormExpressTestComponent;
  let fixture: ComponentFixture<FormExpressTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormExpressTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormExpressTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
