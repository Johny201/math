import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Data } from '../../models/data';
import { PsyhoTestService } from '../../psyho-test.service';
import { Express } from '../../models/test/express';
import { isUndefined } from 'util';
import { ExpressRes } from '../../models/test/express/express-res';
import { ExpressTest } from '../../models/test/express/express-test';

@Component({
  selector: 'app-form-express-test',
  templateUrl: './form-express-test.component.html',
  styleUrls: ['./form-express-test.component.css', './../../psyhological-test-component.component.css']
})

export class FormExpressTestComponent implements OnInit {

  @Input() express : Express
  @Input() id: Number
  @Output() presenceChanged = new EventEmitter<boolean>()
  @Output() expressChanged = new EventEmitter<Express>()

  res: Array<String>
  fabAnswer: Array<String>
  mmseAnswer: Array<String>
  fabTest: Array<String>
  mmseTest: Array<String>
  mmseBound: Array<Data>

  constructor(private psyhoTest: PsyhoTestService) { 
    this.mmseBound = new Array(
      {name: "10", value: "(10|[0-9])"},
      {name: "3", value: "[0-3]"},
      {name: "5", value: "[0-5]"},
      {name: "3", value: "[0-3]"},
      {name: "8", value: "[0-8]"},
      {name: "1", value: "[0-1]"},
    );
    this.fabTest = new Array(
      "Концептуализация",
      "Беглость речи",
      "Динамический праксис",
      "Простая реакция выбора", 
      "Усложненная реакция выбора",
      "Исследование хватательных рефлексов"
    );
    this.mmseTest = new Array(
      "Ориентация",
      "Запоминание", 
      "Внимание и счёт", 
      "Воспроизведение", 
      "Речь", 
      "Конструтивный праксис"
    );
  }

  ngOnInit() {
    this.res = new Array(3)
    if (isUndefined(this.express.expressRes) || isUndefined(this.express.expressRes.Clock)) {
      console.log('z nen')
      for (let i = 0; i < 3; i++) {
        this.res[i] = " "
      }
    } else {
      console.log('ytn nen')
      this.res[0] = this.express.expressRes.Clock
      this.res[1] = this.express.expressRes.resFAB
      this.res[2] = this.express.expressRes.resMMSE
    }
    if (isUndefined(this.express.expressTest) || this.express.expressTest.testFAB.length == 0) {
      console.log('ntgthm ghfdbkmyj')
      this.mmseAnswer = new Array(6)
      this.fabAnswer = new Array(6)
      for (let i = 0; i < 6; i++) {
        this.fabAnswer[i] = ''
        this.mmseAnswer[i] = ''
      }
    } else {
      this.mmseAnswer = this.express.expressTest.testMMSE
      this.fabAnswer = this.express.expressTest.testFAB
    }
  }


  updateExpress() {
    let newExpress = new Express()
    newExpress.expressRes = new ExpressRes()
    newExpress.expressRes.Clock = this.res[0]
    newExpress.expressRes.resFAB = this.res[1]
    newExpress.expressRes.resMMSE = this.res[2]
    newExpress.expressTest = new ExpressTest()
    newExpress.expressTest.testFAB = this.fabAnswer
    newExpress.expressTest.testMMSE = this.mmseAnswer
    this.expressChanged.emit(newExpress);
    this.presenceChanged.emit(true);
  }

  public nextInput(inp) {
    var elems = inp.form.elements
    elems[[].indexOf.call(elems, inp)+1].focus()
  }

  public onSubmitted() {
    let totalFab : number = 0;
    for (let el of this.fabAnswer) {
      totalFab += Number(el);
    }

    let allMMSE = true
    for (let el of this.mmseAnswer) {
      if (el == '') allMMSE = false
    }
    console.log(allMMSE)
    let totalMmse: number = 0;
    if (allMMSE) {
      for (let el of this.mmseAnswer) {
        totalMmse += Number(el);
      }
    } else {
      totalMmse = Number(this.res[2])
    }

    this.res[1] = totalFab.toString();
    this.res[2] = totalMmse.toString();

    this.updateExpress()
  }

}
