import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormAdkTestComponent } from './form-adk-test.component';

describe('FormAdkTestComponent', () => {
  let component: FormAdkTestComponent;
  let fixture: ComponentFixture<FormAdkTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormAdkTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormAdkTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
