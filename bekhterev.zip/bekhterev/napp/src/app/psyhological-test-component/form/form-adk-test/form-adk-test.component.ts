import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Data } from '../../models/data';
import { PsyhoTestService } from '../../psyho-test.service';
import { CommonService } from '../../common.service';
import { ADK } from '../../models/test/adk';
import { isUndefined } from 'util';

@Component({
  selector: 'app-form-adk-test',
  templateUrl: './form-adk-test.component.html',
  styleUrls: ['./form-adk-test.component.css', './../../psyhological-test-component.component.css']
})
export class FormAdkTestComponent implements OnInit {

  @Input() adk: ADK
  @Input() id: Number
  @Output() presenceChanged = new EventEmitter<boolean>()

  adkBound: Array<Data>
  adkRes: Array<String>
  adkTest: Array<String>
  adkAnswer: Array<String>
  adkOne: Array<Data>
  adkTwo: Array<Data>

  constructor(private psyhoTest: PsyhoTestService) {
    console.log("FORM CREATED")
    this.test()
  }

  ngOnInit() {
    this.getAdkTest()

    this.getAdkRes()

    this.adkOne = new Array(
      {name: "День", value: ""},
      {name: "Дата", value: ""},
      {name: "Месяц", value: ""},
      {name: "Год", value: ""},
      {name: "Время года", value: ""}
    )

    this.adkTwo = new Array(
      {name: "Этаж", value: ""},
      {name: "Улица", value: ""},
      {name: "Город", value: ""},
      {name: "Область", value: ""},
      {name: "Страна", value: ""}
    )

    if (this.adkAnswer.length !=0 && this.adkAnswer[0] != "") {
      let one = this.adkAnswer[0]
      console.log(one)
      for (let i = 0; i < one.length; i++) {
        this.adkOne[Number(one.charAt(i))].value = "true"
      }
    }

    if (this.adkAnswer.length !=0 && this.adkAnswer[1] != "") {
      let two = this.adkAnswer[1]
      for (let i = 0; i < two.length; i++) {
        this.adkTwo[Number(two.charAt(i))].value = "true"
      }
    }
    
  }

  getAdkRes() {
    this.adkRes = this.adk.adkRes
  }

  getAdkTest() {
    if (isUndefined(this.adk.adkTest) || this.adk.adkTest.length != 6) {
      this.adk.adkTest = new Array(24)
      for (let i = 0; i < 24; i++) {
        this.adk.adkTest[i] = ''
      }
    } 
    this.adkAnswer = this.adk.adkTest
  }

  updateAdk() {
    let newAdk = new ADK()
    newAdk.adkRes = this.adkRes
    newAdk.adkTest = this.adkAnswer
    console.log(newAdk)
    let newpat = this.psyhoTest.getLocalPat();
    newpat.psyhoTest.adk = newAdk;
    this.psyhoTest.updatePatient(newpat)
    this.presenceChanged.emit(true)

  }

  public nextInput(inp) {
    var elems = inp.form.elements
    elems[[].indexOf.call(elems, inp)+1].focus()
  }

  public onSubmitted(){
    let str = ""
    let res = new Array(0, 0, 0, 0, 0)
    for (let i = 0; i < 5; i++) {
      if (this.adkOne[i].value != "") {
        str += i.toString()
        res[0]++
      }
    }
    this.adkAnswer[0] = str
    str = ""
    for (let i = 0; i < 5; i++) {
      if (this.adkTwo[i].value != "") {
        str += i.toString()
        res[0]++
      }
    }
    this.adkAnswer[1] = str

    res[0] += Number(this.adkAnswer[2]) + Number(this.adkAnswer[3])
    res[1] = Number(this.adkAnswer[4]) + Number(this.adkAnswer[7]) + Number(this.adkAnswer[8]) + Number(this.adkAnswer[22]) + Number(this.adkAnswer[23])
    for (let i = 9; i < 17; i++) {
      res[3] += Number(this.adkAnswer[i])
    }
    for (let i = 17; i < 22; i++) {
      res[4] += Number(this.adkAnswer[i])
    }

    let l_test = Number(this.adkAnswer[5])
    let letters = new Array(1, 3, 5, 7, 10, 13, 17)
    for (let el of letters) {
      if (l_test > el) {
        res[2]++
      }
    }
    let a_test = Number(this.adkAnswer[6])
    let animals = new Array(5, 6, 8, 10, 13, 16, 21)
    for (let el of animals) {
      if (a_test > el) {
        res[2]++
      }
    }

    let total = 0
    for (let el of res) {
      total += el
    }

    this.adkRes[5] = total.toString()
    for (let i = 0; i < 5; i++) {
      this.adkRes[i] = res[i].toString()
    }
    
    this.updateAdk()
  }

  test() {
    this.adkTest = new Array(
      "Внимание. Какой сегодня",
      "Внимание. Какой",
      "Внимание. Три слова",
      "Внимание. Вычитание 7",
      "Память. Повторение трёх слов",
      "Беглость. Слова на букву",
      "Беглость. Животные",
      "Память. Имя и адрес (3-ья попытка)",
      "Память. Имена премьер-министров и президентов",
      "Язык. Карандаш + лист бумаги",
      "Язык. Написание предложений",
      "Язык. Повторение слов",
      "Язык. Повторение: 'Данил и Лина в долине Нила'",
      "Язык. Повторение: 'Озадачили на даче Зою задачами'",
      "Язык. Назвать предметы на картинках",
      "Язык. Выбор картинки",
      "Язык. Прочитать слова",
      "ЗПО. Две бесконечности",
      "ЗПО. Куб",
      "ЗПО. Часы",
      "ЗПО. Количество точек",
      "ЗПО. Буквы",
      "Память. Имя и адрес",
      "Память. Имя и адрес с подсказкой"
    )

    this.adkBound = new Array(
      {name: "", value: ""},
      {name: "", value: ""},
      {name: "Значение поля должно быть от 0 до 3", value: "[0-3]"},
      {name: "Значение поля должно быть от 0 до 5", value: "[0-5]"},
      {name: "Значение поля должно быть от 0 до 3", value: "[0-3]"},
      {name: "Обязательное поле для ввода", value: "^[0-9]+$"},
      {name: "Обязательное поле для ввода", value: "^[0-9]+$"},
      {name: "Значение поля должно быть от 0 до 7", value: "[0-7]"},
      {name: "Значение поля должно быть от 0 до 4", value: "[0-4]"},
      {name: "Значение поля должно быть от 0 до 3", value: "[0-3]"},
      {name: "Значение поля должно быть от 0 до 2", value: "[0-2]"},
      {name: "Значение поля должно быть от 0 до 2", value: "[0-2]"},
      {name: "Значение поля должно быть от 0 до 1", value: "[0-1]"},
      {name: "Значение поля должно быть от 0 до 1", value: "[0-1]"},
      {name: "Значение поля должно быть от 0 до 12", value: "([0-9]|10|11|12)"},
      {name: "Значение поля должно быть от 0 до 4", value: "[0-4]"},
      {name: "Значение поля должно быть от 0 до 1", value: "[0-1]"},
      {name: "Значение поля должно быть от 0 до 1", value: "[0-1]"},
      {name: "Значение поля должно быть от 0 до 2", value: "[0-2]"},
      {name: "Значение поля должно быть от 0 до 5", value: "[0-5]"},
      {name: "Значение поля должно быть от 0 до 4", value: "[0-4]"},
      {name: "Значение поля должно быть от 0 до 4", value: "[0-4]"},
      {name: "Значение поля должно быть от 0 до 7", value: "[0-7]"},
      {name: "Значение поля должно быть от 0 до 5", value: "[0-5]"},
    );
  }
}
