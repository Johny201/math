import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Data } from '../../models/data';
import { PsyhoTestService } from '../../psyho-test.service';
import { CommonService } from '../../common.service';
import { WMS } from '../../models/test/wms';
import { isUndefined } from 'util';
import { WmsRes } from '../../models/test/wms-res';
import {Patient} from "../../../patients/models";

@Component({
  selector: 'app-form-wms-test',
  templateUrl: './form-wms-test.component.html',
  styleUrls: ['./form-wms-test.component.css', './../../psyhological-test-component.component.css']
})
export class FormWmsTestComponent implements OnInit {

  @Input() patient: Patient
  @Output() presenceChanged = new EventEmitter<boolean>()

  wmsTest: Array<Data>
  wmsRes: Array<String>
  wmsTotalRes: Array<String>
  age: number

  constructor(private psyhoTest: PsyhoTestService) { 
  }

  ngOnInit() {
    this.getWmsTest()
    this.getWmsRes()
  }

  getWmsTest(){
    this.wmsTest = new Array(
      {name: "Общий балл", value: ''},
      {name: "Общий балл", value: ''},
      {name: "Общий балл", value: ''},
      {name: "А", value: ''},
      {name: "В", value: ''},
      {name: "А", value: ''},
      {name: "В", value: ''},
      {name: "А", value: ''},
      {name: "Б", value: ''},
      {name: "В", value: ''},
      {name: "Г", value: ''},
      {name: "1", value: ''},
      {name: "2", value: ''},
      {name: "3", value: ''},
      {name: "1", value: ''},
      {name: "2", value: ''},
      {name: "3", value: ''}
    )
    if (!isUndefined(this.patient.psyhoTest.wms.wmsTest)) {
      for (let i = 0; i < 17;  i++) {
        this.wmsTest[i].value = this.patient.psyhoTest.wms.wmsTest[i]
      }
    }
  }

  getWmsRes() {
    this.wmsRes = this.patient.psyhoTest.wms.wmsRes.wmsSubRes
    this.wmsTotalRes = this.patient.psyhoTest.wms.wmsRes.wmsTotalRes
      
    var moment = require('moment');
    var date = moment(this.patient.psyhoTest.date);
    var birthday = moment(this.patient.personal.birthday);
    this.age = moment.duration(date.diff(birthday))._data.years;
  }

  public nextInput(inp) {
    var elems = inp.form.elements
    elems[[].indexOf.call(elems, inp)+1].focus()
  }

  public onSubmitted(){
    this.wmsRes[0] = this.wmsTest[0].value
    this.wmsRes[1] = this.wmsTest[1].value
    this.wmsRes[2] = this.wmsTest[2].value
    this.wmsRes[3] = Math.floor(((Number(this.wmsTest[3].value) + Number(this.wmsTest[4].value))/2)).toString()
    this.wmsRes[4] = (Number(this.wmsTest[5].value) + Number(this.wmsTest[6].value)).toString()
    this.wmsRes[5] = this.wmsTest[5].value
    this.wmsRes[6] = this.wmsTest[6].value
    this.wmsRes[7] = (Number(this.wmsTest[7].value) + Number(this.wmsTest[8].value) + Number(this.wmsTest[9].value) + Number(this.wmsTest[10].value)).toString()
    this.wmsRes[10] = (Number(this.wmsTest[14].value) + Number(this.wmsTest[15].value) + Number(this.wmsTest[16].value)).toString()
    this.wmsRes[9] = Math.floor(((Number(this.wmsTest[11].value) + Number(this.wmsTest[12].value) + Number(this.wmsTest[13].value))/2)).toString()
    this.wmsRes[8] = (Number(this.wmsRes[9]) + Number(this.wmsRes[10])).toString()

    let totalWms = 0
    let i = 0
    for (i = 0; i< 9; i++) {
      if ((i!=5) && (i!=6)) {
        totalWms+= Number(this.wmsRes[i])
      } 
    }
    this.wmsTotalRes[0] = totalWms.toString()

    switch (true) {
      case ( this.age >= 16 && this.age <= 19):
        totalWms += 32
        break;
        case ( this.age >= 20 && this.age <= 24):
        totalWms += 33
        break;
        case ( this.age >=25  && this.age <= 29):
        totalWms += 34
        break;
        case ( this.age >= 30 && this.age <= 34):
        totalWms += 36
        break;
        case ( this.age >= 35 && this.age <= 39):
        totalWms += 38
        break;
        case ( this.age >= 40 && this.age <= 44):
        totalWms += 40
        break;
        case ( this.age >= 45 && this.age <= 49):
        totalWms += 42
        break;
        case ( this.age >= 50 && this.age <= 54):
        totalWms += 44
        break;
        case ( this.age >= 55 && this.age <= 59):
        totalWms += 46
        break;
        case ( this.age >= 60 && this.age <= 64):
        totalWms += 48
        break;
        case ( this.age >= 65 && this.age <= 69):
        totalWms += 50
        break;
        case ( this.age >= 70 && this.age <= 74):
        totalWms += 52
        break;
        default: 
        totalWms += 54
        break;
    }

    this.wmsTotalRes[1] = totalWms.toString()

    let eqMemory: Array<number> = new Array(48, 49, 49, 50, 51, 52, 52, 53, 54, 55, 55, 56, 57, 57, 58, 59,
                                59, 60, 61, 62, 62, 63, 64, 64, 66, 67, 69, 70, 72, 73, 74, 76, 77, 79, 80, 
                                81, 84, 84, 86, 87, 89, 90, 92, 93, 94, 96, 97, 99, 100, 101, 103, 105, 106,
                                108, 110, 112, 114, 116, 118, 120, 122, 124, 128, 129, 132, 135, 137, 140, 143)
    
    if (totalWms > 50) {
      this.wmsTotalRes[2] = eqMemory[totalWms-50].toString()
    } else {
      this.wmsTotalRes[2] = "143"
    }

    this.updateWms()
  }

  updateWms() {
    var test:String[] = new Array(17)
    for (let i = 0; i < 17; i++) {
      test[i] = this.wmsTest[i].value
    }
    let newWMS = new WMS()
    newWMS.wmsTest = test
    newWMS.wmsRes = new WmsRes()
    newWMS.wmsRes.wmsSubRes = this.wmsRes
    newWMS.wmsRes.wmsTotalRes = this.wmsTotalRes
    let newpat = this.psyhoTest.getLocalPat();
    newpat.psyhoTest.wms = newWMS;
    this.psyhoTest.updatePatient(newpat)
    this.presenceChanged.emit(true);

  }

}
