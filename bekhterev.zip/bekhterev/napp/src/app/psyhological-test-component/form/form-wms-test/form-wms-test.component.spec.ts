import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormWmsTestComponent } from './form-wms-test.component';

describe('FormWmsTestComponent', () => {
  let component: FormWmsTestComponent;
  let fixture: ComponentFixture<FormWmsTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormWmsTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormWmsTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
