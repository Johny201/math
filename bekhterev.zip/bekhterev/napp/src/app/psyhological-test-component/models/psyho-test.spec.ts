import { PsyhoTest } from './psyho-test';

describe('PsyhoTest', () => {
  it('should create an instance', () => {
    expect(new PsyhoTest()).toBeTruthy();
  });
});
