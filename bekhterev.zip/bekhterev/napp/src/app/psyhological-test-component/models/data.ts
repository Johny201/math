export class Data {
    name : String
    value: String
}
