import { BDI } from './test/bdi';
import { Express } from './test/express';
import { WMS } from './test/wms';
import { ITT } from './test/itt';
import { ADK } from './test/adk';
import { Stryp } from './test/stryp';

export class PsyhoTest {
    date: Date;
    express?: Express;
    bdi?: BDI;
    wms?: WMS;
    itt?: ITT;
    stryp?: Stryp;
    adk?: ADK;
}
