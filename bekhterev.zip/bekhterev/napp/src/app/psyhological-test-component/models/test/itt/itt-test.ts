export class IttTest {
    sittTest: Array<String>
    pittTest: Array<String>
}
