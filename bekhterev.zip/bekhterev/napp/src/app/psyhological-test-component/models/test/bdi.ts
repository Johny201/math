export class BDI {
    bdiRes: String
    bdiTest: Array<String>
}
