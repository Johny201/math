import { IttTest } from './itt-test';

describe('IttTest', () => {
  it('should create an instance', () => {
    expect(new IttTest()).toBeTruthy();
  });
});
