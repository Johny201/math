export class Stryp {
    strypRes: Array<String>
    strypTest: Array<String>

    constructor() {
        this.strypRes = new Array(2)
        this.strypTest = new Array(6)
    }
}
