export class ADK {
    adkRes: Array<String>
    adkTest: Array<String>
}
