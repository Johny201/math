import { IttRes } from './itt-res';

describe('IttRes', () => {
  it('should create an instance', () => {
    expect(new IttRes()).toBeTruthy();
  });
});
