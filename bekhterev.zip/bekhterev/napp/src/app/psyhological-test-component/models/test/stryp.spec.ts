import { Stryp } from './stryp';

describe('Stryp', () => {
  it('should create an instance', () => {
    expect(new Stryp()).toBeTruthy();
  });
});
