import { WMS } from './wms';

describe('WMS', () => {
  it('should create an instance', () => {
    expect(new WMS()).toBeTruthy();
  });
});
