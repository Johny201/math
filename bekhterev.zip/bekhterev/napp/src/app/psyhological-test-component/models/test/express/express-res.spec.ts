import { ExpressRes } from './express-res';

describe('ExpressRes', () => {
  it('should create an instance', () => {
    expect(new ExpressRes()).toBeTruthy();
  });
});
