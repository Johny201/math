export class IttRes {
    sittRes: Array<String>
    pittRes: Array<String>

    constructor() {
        this.sittRes = new Array(12)
        for (let el of this.sittRes) {
            el = ""
        }
        this.pittRes = new Array(12)
        for (let el of this.pittRes) {
            el = ""
        }

    }
}
