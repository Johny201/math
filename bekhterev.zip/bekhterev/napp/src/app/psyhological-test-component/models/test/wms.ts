import { WmsRes } from './wms-res';

export class WMS {
    wmsRes?: WmsRes
    wmsTest: Array<String>
}
