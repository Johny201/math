import { ExpressRes } from './express/express-res';
import { ExpressTest } from './express/express-test';

export class Express {
    expressRes?: ExpressRes
    expressTest?: ExpressTest
}
