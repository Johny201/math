import { ExpressTest } from './express-test';

describe('ExpressTest', () => {
  it('should create an instance', () => {
    expect(new ExpressTest()).toBeTruthy();
  });
});
