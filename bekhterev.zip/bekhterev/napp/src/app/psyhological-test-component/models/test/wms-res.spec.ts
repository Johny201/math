import { WmsRes } from './wms-res';

describe('WmsRes', () => {
  it('should create an instance', () => {
    expect(new WmsRes()).toBeTruthy();
  });
});
