import { IttTest } from './itt/itt-test';
import { IttRes } from './itt/itt-res';

export class ITT {
    ittRes?: IttRes 
    ittTest?: IttTest
}
