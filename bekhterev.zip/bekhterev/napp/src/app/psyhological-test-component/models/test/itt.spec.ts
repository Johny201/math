import { ITT } from './itt';

describe('ITT', () => {
  it('should create an instance', () => {
    expect(new ITT()).toBeTruthy();
  });
});
