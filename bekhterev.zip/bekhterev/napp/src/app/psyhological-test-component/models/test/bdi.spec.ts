import { BDI } from './bdi';

describe('BDI', () => {
  it('should create an instance', () => {
    expect(new BDI()).toBeTruthy();
  });
});
