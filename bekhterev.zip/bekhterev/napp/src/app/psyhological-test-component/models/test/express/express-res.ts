export class ExpressRes {
    Clock: String
    resFAB: String
    resMMSE: String

    constructor() {
        this.Clock = ''
        this.resFAB = ''
        this.resMMSE = ''
    }
}
