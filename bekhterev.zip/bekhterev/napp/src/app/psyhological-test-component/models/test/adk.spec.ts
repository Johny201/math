import { ADK } from './adk';

describe('ADK', () => {
  it('should create an instance', () => {
    expect(new ADK()).toBeTruthy();
  });
});
