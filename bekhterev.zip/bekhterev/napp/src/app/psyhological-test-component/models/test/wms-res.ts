export class WmsRes {
    wmsSubRes: Array<String>
    wmsTotalRes: Array<String>

    constructor() {
        this.wmsSubRes = new Array(11)
        for (let el of this.wmsSubRes) {
            el = ''
        }
        this.wmsTotalRes = new Array(3)
        for (let el of this.wmsTotalRes) {
            el = ''
        }
    }
}
