import { Injectable } from '@angular/core';
import { Subject }    from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  public editExpress_Observable = new Subject();
  public editBdi_Observable = new Subject();
  public editWms_Observable = new Subject();
  public editItt_Observable = new Subject();
  public editStryp_Observable = new Subject();
  public editAdk_Observable = new Subject();

  constructor() { }

  notifyExpressEdit() {
    this.editExpress_Observable.next()
  }

  notifyBdiEdit() {
    this.editBdi_Observable.next()
  }

  notifyWmsEdit() {
    this.editWms_Observable.next()
  }

  notifyIttEdit() {
    this.editItt_Observable.next()
  }

  notifyStrypEdit() {
    this.editStryp_Observable.next()
  }

  notifyAdkEdit() {
    this.editAdk_Observable.next()
  }
}
