import { Component, OnInit, Input } from '@angular/core';
import { NavClass } from './models';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  @Input() navlist: NavClass[] = [];
  constructor() { }

  ngOnInit() {
  }

}
