export interface NavClass {
    clickable: boolean;
    routerlink: string;
    title: string;
}