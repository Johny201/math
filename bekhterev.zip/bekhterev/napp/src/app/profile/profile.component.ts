import { Component, OnInit } from '@angular/core';
import { Profile } from "../shared/models";
import { ProfileService } from "./profile.service";
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {


  profile: Profile;
  constructor(private http: HttpClient, private profileService: ProfileService) {

  }

  ngOnInit() {
    this.profileService.getProfile().subscribe((x) => {
      this.profile = x;
      console.log(x);
    })

    this.http.get("https://gk.gk:8080/test").subscribe((a) => console.log(a))
  }

}
