
import {Profile} from "../shared/models";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {AppConfig} from "../shared/config/app.config";
import {Injectable} from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class ProfileService{

  constructor(private http: HttpClient) { }


  getProfile(): Observable<Profile> {
    return this.http.get<Profile>(AppConfig.endpoints["getProfile"]);
  }



}
