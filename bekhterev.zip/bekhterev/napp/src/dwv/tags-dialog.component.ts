import {Component, Inject, Input} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
    selector: 'app-dwv-tags-dialog',
    templateUrl: './tags-dialog.component.html'
})

export class TagsDialogComponent {

    constructor() {}
    @Input() data

}
