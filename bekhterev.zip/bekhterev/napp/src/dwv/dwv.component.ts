import {Component, Input, OnInit} from '@angular/core';
import { VERSION } from '@angular/core';
import * as dwv from 'dwv';
import { MatDialog } from '@angular/material';
import { TagsDialogComponent } from './tags-dialog.component';
import {Analysis, Patient} from "../app/patients/models";
import {PatientsService} from "../app/patients/patients.service";

// gui overrides

// decode query
dwv.utils.decodeQuery = dwv.utils.base.decodeQuery;
// progress
dwv.gui.displayProgress = function () {};
// get element
dwv.gui.getElement = dwv.gui.base.getElement;
// refresh element
dwv.gui.refreshElement = dwv.gui.base.refreshElement;

// Image decoders (for web workers)
dwv.image.decoderScripts = {
    'jpeg2000': 'assets/dwv/decoders/pdfjs/decode-jpeg2000.js',
    'jpeg-lossless': 'assets/dwv/decoders/rii-mango/decode-jpegloss.js',
    'jpeg-baseline': 'assets/dwv/decoders/pdfjs/decode-jpegbaseline.js'
};

@Component({
  selector: 'app-dwv',
  templateUrl: './dwv.component.html',
  styleUrls: ['./dwv.component.css']
})

export class DwvComponent implements OnInit {
  public versions: any;
  public tools = ['Scroll', 'ZoomAndPan', 'WindowLevel', 'Draw'];
  public selectedTool = 'Select Tool';
  public loadProgress = 0;
  public dataLoaded = false;
  private dwvApp: any;
  tags: any[];
  private _analysis: Analysis;

  get analysis() {
    return this._analysis;
  }
  @Input('analysis') set analysis(value: Analysis)
  {
    this._analysis = value;

    // create app
    this.dwvApp = new dwv.App();
    // initialise app
    this.dwvApp.init({
      'containerDivId': 'dwv',
      'tools': this.tools,
      'shapes': ['Ruler'],
      'isMobile': false
    });
    // progress
    const self = this;
    this.patientsService.getMRIUrls(this.analysis._id).subscribe((urls) => {
      console.log("URLS: " + urls)
      this.dwvApp.loadURLs(urls);
      this.dwvApp.addEventListener('load-progress', function (event) {
        self.loadProgress = event.loaded;
      });
      this.dwvApp.addEventListener('load-end', function (event) {
        // set data loaded flag
        self.dataLoaded = true;
        // set dicom tags
        self.tags = self.dwvApp.getTags();
        // set the selected tool
        if (self.dwvApp.isMonoSliceData() && self.dwvApp.getImage().getNumberOfFrames() === 1) {
          self.selectedTool = 'ZoomAndPan';
        } else {
          self.selectedTool = 'Scroll';
        }
      });
    })
  }

  constructor(public dialog: MatDialog, private patientsService: PatientsService) {
    this.versions = {
      'dwv': dwv.getVersion(),
      'angular': VERSION.full
    };
  }

  ngOnInit() {

  }

  onChangeTool(tool): void {
    if ( this.dwvApp ) {
      this.selectedTool = tool;
      this.dwvApp.onChangeTool({ currentTarget: { value: tool } });
    }
  }

  onReset(): void {
    if ( this.dwvApp ) {
      this.dwvApp.onDisplayReset();
    }
  }

}
