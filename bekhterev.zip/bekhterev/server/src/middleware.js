import router from "./router";
import multerConfig from "./api/multer";

import oidc from "./oidc/oidc";
import checking from "./api/check";

const morgan = require("morgan");
const path = require("path");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const mongoose = require("mongoose");
const cors = require("cors");
const ResourceServer = require("@solid/oidc-rs");

// const mongo_express = require("mongo-express/lib/middleware")
// const mongo_express_config = require("./config/me_config")

export default async function (app, express, config) {
  const rs = new ResourceServer();
  const check = checking(rs);
  const expressRouter = express.Router();
  const corsOptions = {
    origin(origin, callback) {
      if (config.get("cors").indexOf(origin) !== -1 || !origin) {
        callback(null, true);
      } else {
        callback(new Error(`Not allowed by CORS ${origin}`));
      }
    },
    optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
  };
  app.use(cors(corsOptions));

  await oidc(app, config);

  const db = mongoose.connection;
  mongoose.Promise = global.Promise;
  mongoose.connect(config.get("mongo:uri"));

  db.on("error", (err) => {
    console.log("connection error:", err.message);
  });

  multerConfig(app, config, check);
  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(bodyParser.json());
  app.use(morgan(":remote-addr - :remote-user [:date[clf]] \":method :url\" :status :res[content-length] \":referrer\""));
  app.use(cookieParser());


  const prefix = "/api";
  app.use(session({
    secret: "secretbekhterevkey",
    resave: true,
    saveUninitialized: true,
  }));

  app.use((req, res, next) => {
    req.auth = config.get("auth");
    next();
  });

  app.get(
    "/test", check(), check("personalRead"),
    (req, res) => {
      console.log(req.token);
      console.log(req.claims);
      res.send("hello");
    },
  );
  // app.use((req, res, next) => {
  //     req.user = {roles: ["personalRead"]};
  //     next();
  // })

  // app.use("/db", mongo_express(mongo_express_config))
  app.use(prefix, expressRouter);
  router(expressRouter, app, check);

  app.use(express.static(path.join(__dirname, "../../napp/dist/napp")));
  // app.use("/static", express.static(path.join(__dirname, "../../client/static")))
  // app.use("/lib", express.static(path.join(__dirname, "../../client/static/lib")))
  // app.use("/style", express.static(path.join(__dirname, "../../client/static/style")))

  app.use((req, res) => {
    res.sendFile((path.join(__dirname, "../../napp/dist/napp/index.html")));
  });

  // eslint-disable-next-line no-unused-vars
  app.use((req, res, next) => {
    // res.status(404)
    // console.log("Not found URL: %s", req.url)
    res.redirect("/");
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    res.status(err.status || 500);
    console.log("Internal error(%d): %s", res.statusCode, err);
    console.log(err);
    res.send({ message: err.message });
  });
}
