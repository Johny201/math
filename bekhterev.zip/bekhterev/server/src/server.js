import middleware from "./middleware";
import Config from "./config/config";

const fs = require("fs");
const https = require("https");
const http = require("http");

const args = require("args-parser")(process.argv);

let c = "";
if (args.d) {
  console.log("Developer mode");
  c = "d";
} else if (args.l) {
  console.log("Local mode");
  c = "l";
} else if (args.ls) {
  console.log("Local https mode");
  c = "ls";
} else {
  console.log("Production mode");
  c = "p";
}

const express = require("express");

const config = Config(c);
console.log(config.get("ip"));
const app = express();
const httpApp = express();
httpApp.set('port', config.get("port") || 80);
httpApp.get("*", function (req, res, next) {
  res.redirect("https://" + req.headers.host + "/" + req.path);
});

middleware(app, express, config)
  .then(() => {
    // https.
    if (config.get("https:isHttps")) {
      const options = {
        ...(config.get("https:cert:pfx") ? { pfx: fs.readFileSync(config.get("https:cert:pfx")) } : undefined),
        ...(config.get("https:cert:passphrase") ? { passphrase: config.get("https:cert:passphrase") } : undefined),
        ...(config.get("https:cert:privkey") ? { key: fs.readFileSync(config.get("https:cert:privkey"), "utf8") } : undefined),
        ...(config.get("https:cert:cert") ? { cert: fs.readFileSync(config.get("https:cert:cert"), "utf8") } : undefined),
        ...(config.get("https:cert:chain") ? { ca: fs.readFileSync(config.get("https:cert:chain"), "utf8") } : undefined),
      };

      https.createServer(options, app).listen(config.get("https:port"), () => {
        console.log(`Express сервер прослушивает https ${config.get("https:host")} и порт: ${config.get("https:port")}`);
      });
      http.createServer(httpApp).listen(httpApp.get('port'), function () {
        console.log('Express HTTP server listening on port ' + httpApp.get('port'));
      });
    } else {
      app.listen(config.get("port"), config.get("ip"), () => {
        console.log(`Express сервер прослушивает ip: ${config.get("ip")} и порт: ${config.get("port")}`);
      });
    }
  })
  .catch(e => console.log(e));
