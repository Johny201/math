import { Model as Patient } from "../schemes/patient";

const mongoose = require("mongoose");
const fs = require("fs");

const { ObjectId } = mongoose.Types;
const multer = require("multer");


export default function (app, config, check) {
  const storage = multer.diskStorage({
    destination(req, file, cb) {
      const dir = `${config.get("analysis_path")}/${req.query._id}`;
      if (!fs.existsSync(dir)) {
        fs.mkdir(dir, err => cb(err, dir));
      } else {
        cb(null, dir);
      }
    },
    filename(req, file, cb) {
      const datetimestamp = Date.now();
      const split = file.originalname.split(".");
      const filename = file.originalname.slice(0, -split[split.length - 1].length);
      cb(null, `${filename}-${datetimestamp}.${split[split.length - 1]}`);
    },
  });
  const upload = multer({
    storage,
  }).single("file");

  app.get("/api/files", check(), check(["admin", "researcher", "file:get", "file", "default"]), (req, res) => {
    if (!req.user && req.auth) {
      res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
    } else {
      const file = `${config.get("analysis_path")}/${req.query._id}/${req.query.filename}`;
      if (fs.existsSync(file)) {
        res.download(file);
      } else {
        res.status(500).send({ errCode: 1, message: "Файл не найден" });
      }
    }
  });

  app.delete("/api/files", check(), check(["admin", "researcher", "file:delete", "file"]), (req, res) => {
    if (!req.user && req.auth) {
      res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
    } else {
      const { _id, patientFile } = req.body;
      Patient.findOneAndUpdate({ _id, "files._id": patientFile._id }, { "analyzes.$.removed": true }, (err) => {
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
        } else {
          res.status(200).send();
        }
      });
    }
  });

  app.post("/api/files", check(), check(["admin", "researcher", "file:get", "file", "default"]), (req, res) => {
    if (!req.user && req.auth) {
      res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
    } else {
      const id = req.query._id;
      Patient.findOne({ _id: id }, (findOneErr, patient) => {
        if (findOneErr) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД" });
        } else if (patient) {
          upload(req, res, (err) => {
            if (err) {
              console.log(err);
            } else {
              console.log(req);
              const patFile = {
                contentType: "file",
                description: req.body.description,
                data: {
                  filename: req.file.filename,
                  originalFilename: req.file.originalname,
                },
                _id: new ObjectId(),
                creationDate: Date.now(),
              };
              patient.files ? patient.files.push(patFile) : patient.files = [patFile];
              patient.save((saveErr, updatedPatient) => {
                if (saveErr) {
                  res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
                } else if (updatedPatient) {
                  res.json(patFile);
                } else {
                  res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
                }
              });
            }
          });
        } else {
          res.status(500).send({ errCode: 1, message: "Пациент с таким _id не найден" });
        }
      });
    }
  });
}
