import { Model as Patient } from "../schemes/patient";

const mongoose = require("mongoose");

export default function (router, check) {
  router.route("/patient")
    .get(check(), check(["admin", "researcher", "default", "patient:get", "patient"]), (req, res) => {
      const map = {
        hash: 1,
        creationDate: 1,
        number: 1,
        anamnez: 1,
        group: 1,
        numOfVisits: 1,
        psyhoTest: 1,
        analyzes: {
          $filter: {
            input: "$analyzes",
            as: "analysis",
            cond: { $eq: ["$$analysis.removed", false] },
          },
        },
        files: {
          $filter: {
            input: "$files",
            as: "file",
            cond: { $eq: ["$$file.removed", false] },
          },
        },
      };
      const map1 = {
        "analyzes.contentType": 1,
        "analyzes.title": 1,
        "analyzes.description": 1,
        "analyzes.data": 1,
        "analyzes.creationDate": 1,
        "analyzes.numOfVisit": 1,
        "analyzes.date": 1,
        "analyzes._id": 1,
        "anamnez.data": 1,
        "anamnez.creationDate": 1,
        "anamnez._id": 1,
        "files.contentType": 1,
        "files.title": 1,
        "files.description": 1,
        "files.data": 1,
        "files.date": 1,
        "files.creationDate": 1,
        "files._id": 1,
        psyhoTest: 1,
        hash: 1,
        creationDate: 1,
        number: 1,
        numOfVisits: 1,
        group:1,
      };
      if ("user" in req && "roles" in req.user && req.user.roles.includes("personalRead")) {
        map1.personal = 1;
        map.personal = 1;
        map1["analyzes.hiddenData"] = 1;
        map1["files.hiddenData"] = 1;
      }
      console.log("GET: " + req.query._id);
      Patient.aggregate([
        {
          $match: {
            _id: mongoose.Types.ObjectId(req.query._id),
            $or: [{ removed: { $exists: false } }, { removed: false }],
          },
        },
        { $project: map },
        {
          $project: map1,
        },
      ], (err, patient) => {
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД" });
        } else if (patient.length >= 1) {
          res.json(patient[0]);
        } else {
          res.status(500).send({ errCode: 1, message: "Пациент с таким _id не найден" });
        }
      });
    })
    .post(check(), check(["admin", "researcher", "default", "patient:post", "patient"]), (req, res) => {
      const patient = new Patient();
      console.log("POST: " + req.body);
      const pat = req.body;
      if (!("personal" in pat) || !("firstname" in pat.personal) || !("lastname" in pat.personal)) {
        res.status(500).send({ errCode: 1, message: "Ошибка, некорректный формат данных" });
      } else {
        Object.assign(patient, pat);
        patient.hash = patient.generateHash(patient.personal.firstname + patient.personal.lastname);
        patient.generateNumber((n) => {
          patient.number = n;
          patient.save((err) => {
            if (err) {
              res.status(500).send({ errCode: 1, message: "Ошибка при сохранение в БД", err });
            } else {
              res.status(200).send();
            }
          });
        });
      }
    })
    .delete(check(), check(["admin", "researcher", "patient:delete", "patient"]), (req, res) => {
      const _id  = req.query._id;
      console.log("DELETE: " + _id)
      if (_id === undefined) {
        res.status(500).send({ errCode: 1, message: "Ошибка" });
      } else {
        Patient.findOneAndUpdate({ _id }, { $set: { removed: true } }, (err) => {
          if (err) {
            res.status(500).send({ errCode: 2, message: "Ошибка при чтении из БД", err });
          } else {
            res.status(200).send();
          }
        });
      }
    })
    .put(check(), check(["admin", "researcher", "patient:put", "patient"]), (req, res) => {
      const patient = req.body;
      if (!("_id" in patient)) {
        res.status(500).send({ errCode: 1, message: "Ошибка" });
      } else {
        Patient.findOneAndUpdate({ _id: patient._id }, { $set: patient }, (err, npatient) => {
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else {
            res.status(200).send();
          }
        });
      }
    });

  router.route("/analyzes")
    .get(check(), check(["admin", "researcher", "default", "analyzes:get", "analysis"]), (req, res) => {
      const map = {
        number: 1,
        numOfVisits: 1,
        analyzes: {
          $filter: {
            input: "$analyzes",
            as: "analysis",
            cond: { $eq: ["$$analysis.removed", false] },
          },
        },
      };
      const map1 = {
        number: 1,
        "analyzes.contentType": 1,
        "analyzes.title": 1,
        "analyzes.description": 1,
        "analyzes.creationDate": 1,
        "analyzes.numOfVisit": 1,
        "analyzes.date": 1,
        "analyzes._id": 1,
        numOfVisits: 1,
      };

      if ("user" in req && "roles" in req.user && req.user.roles.includes("personalRead")) {
        map1.personal = 1;
        map.personal = 1;
      }
      Patient.aggregate([
        { $match: { $or: [{ removed: { $exists: false } }, { removed: false }] } },
        { $project: map },
        { $project: map1 },
        { $unwind: "$analyzes" }], (err, patients) => {
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
        } else if (patients) {
          res.json(patients);
        } else {
          res.status(500).send({ errCode: 1, message: "Пациент с таким _id не найден" });
        }
      });
    });


  router.route("/patients")
    .get(check(), check(["admin", "researcher", "default", "patients:get", "patient"]), (req, res) => {
      const map = {
        hash: 1,
        creationDate: 1,
        number: 1,
        anamnez: 1,
        group: 1,
        numOfVisits: 1,
        psyhoTest: 1,
        analyzes: {
          $filter: {
            input: "$analyzes",
            as: "analysis",
            cond: { $eq: ["$$analysis.removed", false] },
          },
        },
        files: {
          $filter: {
            input: "$files",
            as: "file",
            cond: { $eq: ["$$file.removed", false] },
          },
        },

      };
      const map1 = {
        "analyzes.contentType": 1,
        "analyzes.title": 1,
        "analyzes.description": 1,
        "analyzes.data": 1,
        "analyzes.date": 1,
        "analyzes.numOfVisit": 1,
        "analyzes.creationDate": 1,
        "analyzes._id": 1,
        "files.contentType": 1,
        "files.title": 1,
        "files.description": 1,
        "files.data": 1,
        "files.date": 1,
        "files.creationDate": 1,
        "files._id": 1,
        "anamnez.data": 1,
        "anamnez.creationDate": 1,
        "anamnez._id": 1,
        hash: 1,
        psyhoTest: 1,
        creationDate: 1,
        numOfVisits: 1,
        number: 1,
        group: 1,
      };
      if ("user" in req && "roles" in req.user && req.user.roles.includes("personalRead")) {
        map1.personal = 1;
        map.personal = 1;
        map1["analyzes.hiddenData"] = 1;
        map1["files.hiddenData"] = 1;
      }

      Patient.aggregate([
        { $match: { $or: [{ removed: { $exists: false } }, { removed: false }] } },
        { $project: map },
        {
          $project: map1,
        },
      ], (err, patients) => {
        for (let i = 0; i < patients.length; i++) {
          const patient = patients[i];
          patient.analyzesCount = patient.analyzes ? patient.analyzes.length : 0;
          // patient.analyzes = [];
        }
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
        } else if (patients) {
          res.json(patients);
        } else {
          res.status(500).send({ errCode: 1, message: "Пациент с таким _id не найден" });
        }
      });
    });


  router.route("/analysis/object")
    .post(check(), check(["admin", "researcher", "default", "analysis:post", "analysis"]), (req, res) => {
      const { _id, analysis } = req.body;
      console.log(req.body);
      if (analysis.contentType === "file") {
        res.status(500).send({ errCode: 1, message: "Некорректный тип анализа" });
      } else {
        Patient.findOne({ _id }, (err, patient) => {
          console.log(`err: ${err}`);
          console.log(`patient: ${patient}`);
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else if (patient) {
            if ("analyzes" in patient) { patient.analyzes.push(analysis); } else { patient.analyzes = [analysis]; }
            patient.save((saveErr) => {
              console.log(`saveErr: ${saveErr}`);
              if (saveErr) {
                res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
              } else {
                res.status(200).send();
              }
            });
          } else {
            res.status(500).send({ errCode: 1, message: "Пациент с таким id не найден" });
          }
        });
      }
    })
    .put(check(), check(["admin", "researcher", "analysis:put", "analysis"]), (req, res) => {
      const { analysis } = req.body;
      console.log(req.body);
      if (analysis.contentType === "file") {
        res.status(500).send({ errCode: 1, message: "Некорректный тип анализа" });
      } else {
        Patient.findOne({ analyzes: { $elemMatch: { _id: analysis._id } } }, (err, patient) => {
          console.log(`err: ${err}`);
          console.log(analysis._id);
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else if (patient) {
            if ("analyzes" in patient) {
              console.log(`INDEX: ${patient.analyzes.findIndex(x => x._id.toString() === analysis._id.toString())}`);
              patient.analyzes[patient.analyzes.findIndex(x => x._id.toString() === analysis._id.toString())] = analysis;
            } else { patient.analyzes = [analysis]; }
            patient.save((saveErr) => {
              console.log(`saveErr: ${saveErr}`);
              if (saveErr) {
                res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
              } else {
                res.status(200).send();
              }
            });
          } else {
            res.status(500).send({ errCode: 1, message: "Пациент с таким анализом не найден" });
          }
        });
      }
    })
    .delete(check(), check(["admin", "researcher", "analysis:post", "analysis"]), (req, res) => {
      const { _id, analysis } = req.body;
      Patient.findOneAndUpdate({ _id, "analyzes._id": analysis._id }, { "analyzes.$.removed": true }, (err) => {
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
        } else {
          res.status(200).send();
        }
      });
    });

  router.route("/files")
    .get(check(), check(["admin", "researcher", "default", "files:get", "file"]), (req, res) => {
      console.log(req);
      const map = {
        number: 1,
        files: {
          $filter: {
            input: "$files",
            as: "PatientFile",
            cond: { $eq: ["$$PatientFile.removed", false] },
          },
        },
      };
      const map1 = {
        number: 1,
        "files.contentType": 1,
        "files.title": 1,
        "files.description": 1,
        "files.creationDate": 1,
        "files._id": 1,
      };

      if ("user" in req && "roles" in req.user && req.user.roles.includes("personalRead")) {
        map1.personal = 1;
        map.personal = 1;
      }
      Patient.aggregate([
        { $match: { $or: [{ removed: { $exists: false } }, { removed: false }] } },
        { $project: map },
        { $project: map1 },
        { $unwind: "$files" }], (err, patients) => {
        if (err) {
          res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
        } else if (patients) {
          res.json(patients);
        } else {
          res.status(500).send({ errCode: 1, message: "Пациент с таким _id не найден" });
        }
      });
    });

  router.route("/files/object")
    .post(check(), check(["admin", "researcher", "default", "files:post", "file"]), (req, res) => {
      console.log(req);
      if (!req.user && req.auth) {
        res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
      } else {
        const { _id, file } = req.body;
        console.log(req.body);
        Patient.findOne({ _id }, (err, patient) => {
          console.log(`err: ${err}`);
          console.log(`patient: ${patient}`);
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else if (patient) {
            if ("files" in patient) { patient.files.push(file); } else { patient.files = [file]; }
            patient.save((saveErr) => {
              console.log(`saveErr: ${saveErr}`);
              if (saveErr) {
                res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
              } else {
                res.status(200).send();
              }
            });
          } else {
            res.status(500).send({ errCode: 1, message: "Пациент с таким id не найден" });
          }
        });
      }
    })
    .put(check(), check(["admin", "researcher", "files:put", "file"]), (req, res) => {
      if (!req.user && req.auth) {
        res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
      } else {
        const { file } = req.body;
        console.log(req.body);
        Patient.findOne({ files: { $elemMatch: { _id: file._id } } }, (err, patient) => {
          console.log(`err: ${err}`);
          console.log(file._id);
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else if (patient) {
            if ("files" in patient) {
              console.log(`INDEX: ${patient.files.findIndex(x => x._id.toString() === file._id.toString())}`);
              patient.files[patient.files.findIndex(x => x._id.toString() === file._id.toString())] = file;
            } else { patient.files = [file]; }
            patient.save((saveErr) => {
              console.log(`saveErr: ${saveErr}`);
              if (saveErr) {
                res.status(500).send({ errCode: 1, message: "Ошибка при сохранении в БД" });
              } else {
                res.status(200).send();
              }
            });
          } else {
            res.status(500).send({ errCode: 1, message: "Пациент с таким анализом не найден" });
          }
        });
      }
    })
    .delete(check(), check(["admin", "researcher", "files:delete", "file"]), (req, res) => {
      if (!req.user && req.auth) {
        res.status(500).send({ errCode: 2, message: "Пользователь не авторизован" });
      } else {
        const { _id, file } = req.body;
        Patient.findOneAndUpdate({ _id, "files._id": file._id }, { "files.$.removed": true }, (err) => {
          if (err) {
            res.status(500).send({ errCode: 1, message: "Ошибка при чтении из БД", err });
          } else {
            res.status(200).send();
          }
        });
      }
    });
}

