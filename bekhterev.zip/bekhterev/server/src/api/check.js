import { Model as Account } from "../schemes/profile";

export default function (rs) {
  const check = (roles) => {
    if (!roles || roles.length === 0) {
      return (req, res, next) => {
        rs.authenticate({
          scopes: ["bekhterev-api"],
          handleErrors: false,
        })(req, res, async (err) => {
          if (!err) {
            req.user = await Account.findOne({ _id: req.claims.sub }).then(p => p);
            next();
          } else {
            next(err);
          }
        });
      };
    }
    return (req, res, next) => {
      if (!req.user || !req.user) {
        res.sendStatus(401);
        return;
      }
      if (Array.isArray(roles)) {
        for (const nr of roles) {
          for (const r of req.user.roles) {
            if (nr === r) {
              next();
              return;
            }
          }
        }
        res.sendStatus(403);
        return;
      }
      for (const r of req.user.roles) {
        if (roles === r) {
          next();
          return;
        }
      }
      res.sendStatus(403);
      return;
    };
  };

  return check;
}
