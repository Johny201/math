import patient from "./api/patient";

export default function (router, app, check) {
  patient(router, check);
}
