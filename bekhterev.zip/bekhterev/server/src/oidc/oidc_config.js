
import { Model as Account } from "../schemes/profile";

export default function () {
  const configuration = {
    claims: {
      acr: null,
      sid: null,
      auth_time: null,
      iss: null,
      openid: ["sub"],
      "bekhterev-api": ["sub", "roles"],
    },
    // scopes: ['openid', 'offline_access', "bekhterev-api"],
    formats: {
      default: "opaque",
      AccessToken: "jwt",
    },
    // TODO: перечитать, что это за фичи снизу
    features: {
      claimsParameter: true,
      discovery: true,
      encryption: true,
      introspection: true,
      request: true,
      revocation: true,
      sessionManagement: true,
      devInteractions: false,
      jwtIntrospection: true,
      deviceFlow: true,
    },
    ttl: {
      AccessToken: 1 * 60 * 60 * 24,
      AuthorizationCode: 10 * 60,
      IdToken: 1 * 60 * 60 * 24,
      DeviceCode: 10 * 60,
      RefreshToken: 1 * 24 * 60 * 60,
    },
    cookies: {
      long: { signed: true, maxAge: (1 * 24 * 60 * 60) * 1000 }, // 1 day in ms
      short: { signed: true },
      keys: ["some secret bekhterev key", "another bekhterev secret key for cookies", "and one more bekhterev key"],
    },
    async findById(ctx, sub, token) {
      const account = await Account.findOne({ _id: sub });
      ctx.oidc.claims = {
        "bekhterev-api": ["sub", "roles"],
        roles: "allo",
      };
      console.log(ctx.oidc);
      // if (!account) {
      //   ctx.res.status(500).send({ error: "Аккаунт не найден", errCode: 2 })
      //   return;
      // }
      return {
        accountId: sub,
        async claims(use, scope, claims, rejected) {
          const c = { sub };

          if (scope && scope.indexOf("bekhterev-api") > -1) {
            c.roles = account.roles.join(" ");
          }
          return c;
        },
      };
    },
    async interactionUrl(ctx, interaction) {
      return `/oidc/interaction/${ctx.oidc.uuid}`;
    },
    async logoutSource(ctx, form) {
      ctx.body = `
        <!DOCTYPE html>
        <head>
          <meta charset="utf-8">
          <title>Logout Request</title>
          <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
          <meta http-equiv="x-ua-compatible" content="ie=edge">
        </head>
        <body>
            ${form}
            <script>
            var form = document.getElementById('op.logoutForm');
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'logout';
            input.value = 'yes';
            form.appendChild(input);
            form.submit();
            </script>
        </body>
        </html>`;
    },
  };

  return configuration;
}
