const querystring = require('querystring');
const { urlencoded } = require('express'); // eslint-disable-line import/no-unresolved
const path = require('path');

// const Account = require('../support/account');
import { Model as Account } from "../schemes/profile"

const body = urlencoded({ extended: false });

module.exports = (app, provider) => {
  const { constructor: { errors: { SessionNotFound } } } = provider;


  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, 'views'));

  // app.use((req, res, next) => {
  //   const orig = res.render;
  //   // you'll probably want to use a full blown render engine capable of layouts
  //   res.render = (view, locals) => {
  //     app.render(view, locals, (err, html) => {
  //       if (err) throw err;
  //       orig.call(res, '_layout', {
  //         ...locals,
  //         body: html,
  //       });
  //     });
  //   };
  //   next();
  // });

  function setNoCache(req, res, next) {
    res.set('Pragma', 'no-cache');
    res.set('Cache-Control', 'no-cache, no-store');
    next();
  }

  app.get('/oidc/interaction/:grant', setNoCache, async (req, res, next) => {
    try {
      const details = await provider.interactionDetails(req);
      const client = await provider.Client.find(details.params.client_id);
      console.log(details.interaction.error, details.interaction, details)
      if (details.interaction.error === 'login_required') {
        return res.render('login', {
          client,
          details,
          title: 'Sign-in',
          params: querystring.stringify(details.params, ',<br/>', ' = ', {
            encodeURIComponent: value => value,
          }),
          interaction: querystring.stringify(details.interaction, ',<br/>', ' = ', {
            encodeURIComponent: value => value,
          }),
        });
      }
      return res.render('interaction', {
        client,
        details,
        title: 'Authorize',
        params: querystring.stringify(details.params, ',<br/>', ' = ', {
          encodeURIComponent: value => value,
        }),
        interaction: querystring.stringify(details.interaction, ',<br/>', ' = ', {
          encodeURIComponent: value => value,
        }),
      });
    } catch (err) {
      return next(err);
    }
  });

  app.post('/oidc/interaction/:grant/confirm', setNoCache, body, async (req, res, next) => {
    try {
      const result = { consent: {} };
      await provider.interactionFinished(req, res, result);
    } catch (err) {
      next(err);
    }
  });

  app.post('/oidc/interaction/:grant/checkup', setNoCache, body, async (req, res, next) => {
    try {
      console.log(req.body)
      const account = await Account.findOne({ "username": req.body.username });
      if (!account || !account.checkPassword(req.body.password)) {
        res.status(500).send({ error: "Логин или пароль введен неверно", errCode: 1 })
        return;
      }
      res.sendStatus(200);
    }
    catch(err) {
      res.sendStatus(500);
    }
  });

  app.post('/oidc/interaction/:grant/login', setNoCache, body, async (req, res, next) => {
    try {
      console.log(req.body)
      const account = await Account.findOne({ "username": req.body.username });
      // if (!account || !account.checkPassword(req.body.password)) {
      //   res.status(500).send({ error: "Логин или пароль введен неверно", errCode: 1 })
      //   return;
      // }
      const result = {
        login: {
          account: account._id,
          acr: 'urn:mace:incommon:iap:bronze',
          amr: ['pwd'],
          remember: !!req.body.check,
          ts: Math.floor(Date.now() / 1000),
        },
        consent: {},
      };

      await provider.interactionFinished(req, res, result);
    } catch (err) {
      next(err);
    }
  });

  app.use((err, req, res, next) => {
    if (err instanceof SessionNotFound) {
      // handle interaction expired / session not found error
    }
    next(err);
  });
};