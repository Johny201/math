
// const MA = require('./mongo_adapter');
import MA from "./mongo_adapter";
import OIDCConfig from "./oidc_config";

const Provider = require("oidc-provider");
const interaction = require("./interaction");

export default async function (app, config) {
  const configuration = OIDCConfig();
  const clients = config.get("oidc:clients");


  const oidc = new Provider(config.get("oidc:href"), configuration);
  await oidc.initialize({
    adapter: MA(config),
    clients,
    keystore: {
      keys:
        [{
          kty: "RSA",
          kid: "WCu4AAPrY6pYSUAWrN0umTlaG8uv32gA8gqhFtEdXbw",
          use: "sig",
          alg: "RS256",
          e: "AQAB",
          n: "pfNapYDoLK3cBjRfSBFJMbrTCvyrca0MDnxp3sKumWdZAO3K6h9thUUm1B9cIldKSUBffM1He88zjBt_Q-Lcne456GH_UjYG0LPLucRrQqBuxKqr4JexcpvKhLKSjwzTf8XIGDAdhvijVBWVfwyMxhI27UXwDtEb4LK0GEjbkJnEhp-ZKF4_Ts61iKeKTZ0toCecM3WrZtMWtE7mOfSKgatRt79N4_RrUQN3Up8N8EMabcZja6ih0j0j15ZtBogubFIrpVQsD93y4wFJDiAophsG95UOK9Feq6b69uuN98_-E14n7xbvnXwtAnxdy8aidS8Utie2CCdakec-Ry3EVw",
          d: "QneC4fEMjQChtJZ7ZzkNMO7cInVrEZ-2yYKJQOCG4AhlvJqBgF5QFmXJFILu-w4tQcOXuzvZGry1r7M_uOf_Zv4IkYvWoI3lEuhAe8oxD8GEPB8DsnPvbbD6X0XKr6L6fx2vdAipeurROBdhBj73j0myWDx_1t9oJApPWb6sunBHC1u0TAvB9A0jw4I5PPAhXnhVeb4VvxGJqxEaDbNQ25e9ts9AGwMWvXgNbpo2wwJ2pJiE5nAlK8QuDDXyPwCkgC-Ky62EF42z6jB3uiF0uNAIuVZbSaSxyow3Vx0lV4KvqfL3GH7IhDCBpwGLt7tKHHzcvM0FzbV0Qb95QVRq6Q",
          p: "zp8ZDJhz6cVlUxzDbilhauJcT5IZbIa0gtl_tWhyEvh8MHOnK64J4niJCDT-EBpWxwNgqDGlOCDW5aSaoCJVZz1Kq5TSkOYpJUPIEXdzGmhmq2Fq0mj8YZdHVF0wmyRnT-zGye2NbY3HYRSyMxSSIZmco2suKJL5AKisNKLw-oU",
          q: "zZwNLe8DkIN2KZD7HADgSWHMoFFkXWjrJORKj9TmZd_hVsiicDDpPWcTRTilv1F9AuV0vunf4K1qtid5tDUqsqflDcAVAG9QS-lSOVkV6K45csZmu8GVdHXuKzmXt5dIbRz6iuI45EWXCGGVC9rwaUIaXU2SRlfhm22WfTur8Cs",
          dp: "yW6bSgc6QbX6MQuCjtvyp_Pj0IL7HC06v7HwaddYFpx-3fFyEQhLhKjD1udqpCI5ZS0qxu4XR1_kgN53DBRMtCgxqpKcsTxg8n5hBn4wDZeoN_3x2Q0WtsF3fYyYPTdBLM8FgYiAb0RgEonNrDSqvez2ou5zgoS-EeFeeLY9Pc0",
          dq: "TV9J_l0RRFKUJrQuKq2RuUuaS0IVuKkAw9M8079ULEYBcDz0E6_0NW0SbVwR01sA5hQeyLEN1Git3XohbFUNiklwAqqjvJQm7UoR7Q6_Fd5qM-zBQCpq6XZvd8imdSny0Uy0Y4sZyZz-ZuMByYJMMe_0J-RHBT2Q4oJsvRe1bh0",
          qi: "W1wClonbOysU94s-Tv_QSEo--dnMjlhbcwzxaHelwnCRsnzhYF_RfA3ecr0frfsDT2Onhd6AVQwVBq_V3s7jzL2_buw9cYEphseyNrFU8yPIXEYpaA9-mYnfDZi-Sak6PNspjjtGzXKQZZVOnVaCF9NthPt6BGQhe9lc3cHU_dk",
        }],
    },
  });
  interaction(app, oidc);

  app.use("/oidc", oidc.callback);
}
