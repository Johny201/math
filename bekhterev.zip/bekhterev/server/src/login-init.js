"use strict";

var _profile = require("./schemes/profile");

var mongoose = require("mongoose");
var bcrypt = require("bcrypt-nodejs");

var db = mongoose.connection;
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://bekhterev:bekhterev@mongo/bekhterev?authSource=admin");

db.on("error", function (err) {
    console.log("connection error:", err.message);
});

var user1 = new _profile.Model({
    username: "user",
    password: bcrypt.hashSync("x39qatw4", bcrypt.genSaltSync(32), null),
    roles: []
});
var user2 = new _profile.Model({
    username: "admin",
    password: bcrypt.hashSync("qfA2mP9c", bcrypt.genSaltSync(32), null),
    roles: ["personalRead", "admin"]
});

var f1 = false,
    f2 = false;
user1.save(function (err, user) {
    f1 = true;
    if (f1 && f2) disc();
});
user2.save(function (err, user) {
    f2 = true;
    if (f1 && f2) disc();
});
function disc() {
    mongoose.disconnect();
}