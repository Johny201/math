const mongoose = require("mongoose")
const crypto = require("crypto")

const { Schema } = mongoose
const CounterSchema = Schema({
    _id: { type: String, required: true },
    seq: { type: Number, default: 1 },
})
const Counter = mongoose.model("counter", CounterSchema)

Counter.findOne({ _id: "counter" }, (err, c) => {
    if (err) { /* */ } else if ((c != null) && (c.seq != null)) { /* */ } else {

        const cc = new Counter({ _id: "counter" })
        cc.save()
        console.log(cc)
    }
})

const Patient = new Schema({
    analyzes: [{
        removed: { type: Boolean, default: false },
        numOfVisit: {type: Number, default: 1},
        contentType: { type: String, require: true },
        title: { type: String },
        description: { type: String },
        creationDate: { type: Date, default: Date.now },
        date: { type: Date, default: Date.now },
        hiddenData: {},
        data: {},
    }],
    anamnez: {
        removed: { type: Boolean, default: false },
        creationDate: { type: Date, default: Date.now },
        hiddenData: {},
        data: {},
    },
    files: [{
        removed: { type: Boolean, default: false },
        contentType: { type: String, require: true },
        title: { type: String },
        description: { type: String },
        creationDate: { type: Date, default: Date.now },
        hiddenData: {},
        data: {},
    }],
    psyhoTest: {
        date: {type: Date, required: true, default: Date.now},
        express: {
            expressRes: {
                Clock: {type: String},
                resFAB: {type:String},
                resMMSE: {type: String}
            },
            expressTest: {
                testFAB: { type: [{type: String}]},
                testMMSE: { type: [{type: String}]}
            }
        },
        bdi: {
            bdiRes: {type: String},
            bdiTest: {type: [{type: String}]}
        },
        wms: {
            wmsRes: {
                wmsSubRes: { type: [{type: String}]},
                wmsTotalRes: { type: [{type: String}]},
            },
            wmsTest: { type: [{type: String}]}
        },
        itt: {
            ittRes: {
                sittRes: { type: [{type: String}]},
                pittRes: { type: [{type: String}]},
            },
            ittTest: {
                sittTest: { type: [{type: String}]},
                pittTest: { type: [{type: String}]},
            }
        },
        stryp: {
            strypRes: { type: [{type: String}]},
            strypTest: { type: [{type: String}]}
        },
        adk: {
            adkRes: { type: [{type: String}]},
            adkTest: { type: [{type: String}] }
        }
    },
    numOfVisits: {type: Number, default: 1},
    removed: { type: Boolean, default: false },
    hash: { type: String },
    creationDate: { type: Date, default: Date.now },
    group: {type: Number, default: 0},
    personal: {
        firstname: String,
        lastname: String,
        patronymic: String,
        birthday: Date
    },
    number: { type: Number, required: true },
})

Patient.methods.generateHash = (str) => {
    const hash = crypto.createHash("sha256")
    hash.update(str)
    return hash.digest().toString("hex")
}
Patient.methods.generateNumber = (callback) => {
    Counter.findByIdAndUpdate({ _id: "counter" }, { $inc: { seq: 1 } }, (error, counter1) => {
        if (error) { console.log(error) }
        callback(counter1.seq)
    })
}

export const Model = mongoose.model("Patient", Patient)
