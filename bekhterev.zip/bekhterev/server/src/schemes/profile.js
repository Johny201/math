const mongoose = require("mongoose")
const bcrypt = require("bcrypt-nodejs")

const { Schema } = mongoose

const Profile = new Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    name: { type: String },
    patronymic: { type: String },
    surname: { type: String },
    position: { type: String },
    roles: [{ type: String }],
})


Profile.methods.generateHash = function generateHash(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(32), null)
}

Profile.methods.checkPassword = function checkPassword(password) {
    return bcrypt.compareSync(password, this.password)
}

export const Model = mongoose.model("Profile", Profile)
