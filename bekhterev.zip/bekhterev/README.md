[![pipeline status](https://gitlab.com/vladyan18/bekhterev/badges/master/pipeline.svg)](https://gitlab.com/vladyan18/bekhterev/commits/master)
# bekhterev
## Установка
```sh
$ npm install
```
## Сборка сервера
```sh
$ npm run build
```
## Запуск сервера
```sh
$ npm run start
```

